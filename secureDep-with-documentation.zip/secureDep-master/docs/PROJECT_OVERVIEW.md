# SecureDep — Project Overview

## 1. Introduction

SecureDep is a Python-based static-analysis tool that examines software packages from the npm and Python Package Index (PyPI) ecosystems for indicators associated with malicious behaviour. It is intended to help developers and security learners assess dependencies before installing them.

A package can contain harmful code in installation hooks or ordinary source files. SecureDep therefore inspects package contents and reports the behaviours that contributed to its risk assessment.

## 2. Problem statement

Modern applications rely heavily on third-party libraries. A compromised or intentionally malicious dependency can expose credentials, communicate with remote infrastructure, modify a system, or execute unwanted commands. Reviewing every dependency manually is difficult.

SecureDep addresses this problem by automating a pre-installation inspection process and presenting findings in a structured report.

## 3. Objectives

- Retrieve packages from supported public registries or scan local package files.
- Inspect package metadata and installation-related configuration.
- Identify suspicious code patterns in Python and JavaScript.
- Detect selected obfuscation and encoded content patterns.
- Identify package names that may imitate popular packages.
- Aggregate findings into a risk score and explain the evidence.
- Provide text and JSON reports suitable for people and automation.
- Evaluate and calibrate detection logic using labelled datasets.

## 4. Scope

### Included

- npm and PyPI package acquisition.
- Safe archive extraction and local package scanning.
- Static inspection of supported Python and JavaScript content.
- Metadata, install-hook, obfuscation, deobfuscation, and typosquatting analysis.
- Indicator scoring, combination rules, and report generation.

### Outside the current implemented scope

- Guaranteeing that a package is safe.
- Dynamic execution or sandbox detonation of packages.
- Scanning every programming language or package ecosystem.
- Replacing dependency review, endpoint protection, or software composition analysis.
- Fully implemented AI explanation and MCP integration.

## 5. Intended users

- Developers reviewing third-party dependencies.
- Cybersecurity students learning software supply-chain security.
- Security analysts conducting preliminary package triage.
- Researchers evaluating package-risk indicators.

## 6. Expected output

A scan produces a package-level risk band and supporting findings. Depending on the selected command-line options, the output is rendered in the terminal or saved as JSON. The report should be interpreted by reviewing the evidence, not only the final risk label.

## 7. Limitations

Static analysis cannot reliably determine intent in every case. Benign packages may use behaviours that resemble malicious activity, while sophisticated malware may evade pattern-based inspection. Current scoring weights and thresholds are provisional until measured against a representative labelled corpus. These limitations should be stated in project demonstrations and evaluation reports.

## 8. Project outcome

The intended outcome is a reproducible command-line scanner that helps users make more informed dependency decisions by surfacing suspicious behaviours before package installation.
