# SecureDep — User Guide

## 1. Before you begin

Install Python 3.10 or newer. Registry scans require an internet connection. Local scans can be performed without registry access when the package archive or extracted directory is already available.

## 2. Install SecureDep

From the repository root, create a virtual environment.

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

Check the CLI:

```bash
securedep --help
```

## 3. Scan packages

### PyPI

PyPI is the default ecosystem:

```bash
securedep scan requests
```

### npm

```bash
securedep scan cross-env --ecosystem npm
```

### Specific version

```bash
securedep scan requests --package-version 2.31.0
```

### Local package

```bash
securedep scan ./samples/package.tar.gz --local --name package
```

The `--local` option accepts a local archive or extracted directory. The target path must exist.

## 4. Choose report output

Human-readable output:

```bash
securedep scan requests
```

Detailed evidence:

```bash
securedep scan requests --verbose
```

JSON output:

```bash
securedep scan requests --json
```

Save JSON to a file:

```bash
securedep scan requests --json --output reports/requests.json
```

## 5. Inspect the indicator catalogue

```bash
securedep indicators
securedep indicators --json
```

This command lists the configured indicators and combination rules. The weights are configuration values and should not be interpreted as measured probabilities.

## 6. Understand exit codes

| Code | Interpretation |
|---:|---|
| 0 | Low risk |
| 1 | Medium risk |
| 2 | High risk |
| 3 | Critical risk |
| 4 | Error |

For automated use, capture the exit code and retain the report for review. A high score should trigger investigation rather than an automatic assumption about intent.

## 7. Optional explanation feature

The CLI exposes `--explain` as an optional layer. The AI extra can be installed with:

```bash
pip install -e ".[ai]"
```

The explanation feature may also require an API key and implementation that is not yet complete in this project version. It is not required for the core scanner and must never be treated as the source of the risk verdict.

## 8. Troubleshooting

- **`securedep` command not found:** activate the virtual environment and rerun `pip install -e ".[dev]"`.
- **Registry/network error:** check connectivity and try again; registry scans require network access.
- **Local path not found:** verify the path and current working directory.
- **Archive refused:** do not bypass the safety check. Review the error and the safety guide.
- **Import or dependency error:** confirm Python 3.10+ and reinstall project dependencies.

## 9. Safe-use reminder

Do not install a package simply to inspect it. Review `docs/SAFETY.md` before handling real malicious samples. Keep real malware and sensitive corpora out of the repository.
