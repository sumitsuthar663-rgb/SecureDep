# SecureDep — Architecture

## 1. Architectural summary

SecureDep is organised as a pipeline. Package acquisition and extraction provide input to a collection of independent analysis modules. Their findings are passed to the scoring model, and the reporting layer presents the result.

```text
Package name / local path
          |
          v
  Acquisition layer
  (PyPI / npm / local)
          |
          v
   Safe extraction
          |
          v
    Analysis engine
  +-------------------------+
  | Metadata analysis       |
  | Install-script analysis |
  | Python AST analysis     |
  | JavaScript AST analysis |
  | Obfuscation analysis    |
  | Deobfuscation analysis  |
  | Typosquatting analysis  |
  +-------------------------+
          |
          v
  Indicators and combination rules
          |
          v
      Risk scoring
          |
          v
    Reporting layer
     /          \
  Text          JSON
```

## 2. Main components

### Acquisition — `src/securedep/acquisition/`

Responsible for retrieving package metadata and archives from supported registries and preparing local inputs for analysis. The extraction code is designed to reject unsafe archive structures, including path traversal and unsafe links.

### Analysis — `src/securedep/analysis/`

Contains focused analysers:

- `metadata.py`: examines package metadata.
- `install_scripts.py`: inspects installation hooks and setup configuration without running them.
- `ast_python.py` and `ast_js.py`: inspect supported source code using syntax-aware analysis.
- `obfuscation.py`: identifies selected obfuscation signals.
- `deobfuscation.py`: decodes selected representations and sends recovered text back through analysis as data.
- `typosquatting.py`: compares names against popular package-name lists.
- `engine.py`: coordinates the scan and collects findings.

### Scoring — `src/securedep/scoring/`

Defines indicator metadata, weights, contextual rules, and combination logic. Individual analysers report evidence; the scoring layer combines that evidence into a risk assessment.

Combination scope matters: related behaviours may need to occur in the same install hook, file, or package before a combination rule applies.

### Reporting — `src/securedep/reporting/`

Formats scan results as human-readable terminal output or JSON.

### CLI — `src/securedep/cli.py`

Provides the `securedep scan` and `securedep indicators` commands and maps risk bands to process exit codes.

## 3. Design principles

1. **Static-first:** scanned package code is inspected, not installed or executed.
2. **Separation of concerns:** acquisition, analysis, scoring, and reporting are separate responsibilities.
3. **Evidence-based findings:** reports should expose the observations behind a score.
4. **Deterministic verdict:** optional AI explanations must not determine or alter the risk band.
5. **Defensive extraction:** untrusted archives must be validated before their contents are processed.
6. **Honest evaluation:** provisional weights and thresholds must not be described as empirically validated.

## 4. Data flow

The CLI creates a package reference and calls the registry scan or local scan entry point. The engine obtains the package contents, runs the relevant analysers, and gathers indicators. The scoring model evaluates individual indicators and applicable combinations. The reporting layer serialises the final result.

## 5. Extension points

New analysers should follow the existing analysis-unit conventions and return structured findings. New indicators or combination rules belong in the scoring catalogue. New output formats should be implemented in the reporting layer rather than embedded in individual analysers.

## 6. Related design records

See `docs/adr/` for decisions about JavaScript parsing and combination scope.
