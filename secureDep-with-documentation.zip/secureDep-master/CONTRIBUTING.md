# Contributing to SecureDep

Thank you for your interest in improving SecureDep.

## Development setup

```bash
python -m venv .venv
# Activate the environment for your operating system.
pip install -e ".[dev]"
```

## Workflow

1. Create a branch for one focused change.
2. Make the smallest practical implementation change.
3. Add or update tests for changed behaviour.
4. Update user or developer documentation where appropriate.
5. Run the test suite and quality checks.
6. Open a pull request describing the motivation, implementation, tests, and limitations.

## Checks

```bash
pytest
ruff check src/ tests/
ruff format --check src/ tests/
```

## Security-sensitive changes

Never execute untrusted package code as part of static analysis. Treat package archives, filenames, metadata, and source files as untrusted input. Add regression tests for archive handling and parser edge cases. Do not commit real malware samples, secrets, API keys, or private evaluation datasets.

## Reporting issues

Include the operating system, Python version, command used, relevant error output, and a minimal safe reproduction. Remove tokens, credentials, and private package data before posting logs.
