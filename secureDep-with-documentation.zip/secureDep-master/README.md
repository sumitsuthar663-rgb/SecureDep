# SecureDep

**Static analysis for detecting potentially malicious npm and PyPI packages before installation.**

SecureDep inspects package archives and source code for suspicious behaviours, explains the evidence behind its findings, and assigns a risk band. It is designed to help developers review software dependencies before trusting them.

> **Important:** SecureDep downloads and reads packages; it does not install or execute scanned packages. Its findings are indicators for investigation, not proof that a package is malicious.

## Contents

- [Key features](#key-features)
- [How it works](#how-it-works)
- [Technology stack](#technology-stack)
- [Requirements](#requirements)
- [Installation](#installation)
- [Quick start](#quick-start)
- [Command reference](#command-reference)
- [Risk levels and exit codes](#risk-levels-and-exit-codes)
- [Project structure](#project-structure)
- [Testing](#testing)
- [Current implementation status](#current-implementation-status)
- [Security and responsible use](#security-and-responsible-use)
- [Documentation](#documentation)
- [Contributing](#contributing)
- [License](#license)

## Key features

- Scans packages from **PyPI** and **npm**.
- Supports scanning a local archive or extracted package directory.
- Examines package metadata and installation hooks.
- Uses Python and JavaScript syntax-tree analysis to identify suspicious operations.
- Detects obfuscation and attempts limited decoding of common encodings.
- Checks package names for possible typosquatting.
- Combines findings into a risk score with evidence.
- Produces readable terminal output or structured JSON reports.
- Includes a test suite, evaluation utilities, and calibration scripts.

## How it works

The scanner follows a static-analysis pipeline:

1. **Acquisition:** obtains a package archive from its registry, or accepts a local package.
2. **Safe extraction:** validates archive contents and rejects unsafe paths and archive structures.
3. **Analysis:** examines metadata, install scripts, source-code behaviour, obfuscation, decoded strings, and package-name similarity.
4. **Scoring:** combines indicators and contextual rules into a risk band.
5. **Reporting:** prints a human-readable report or JSON output.

The detection verdict is produced by deterministic analysis and scoring logic. Optional AI explanations are separate and must not change the verdict.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for details.

## Technology stack

| Technology | Purpose |
|---|---|
| Python 3.10+ | Main implementation |
| Requests | Registry and package retrieval |
| Tree-sitter | JavaScript syntax-tree parsing |
| pytest | Automated tests |
| Ruff | Linting and formatting |
| pandas / matplotlib | Optional evaluation and analysis tools |

## Requirements

- Python **3.10 or newer**
- pip
- Internet connection for registry scans and optional name-list retrieval
- Windows, macOS, or Linux

## Installation

Clone the repository and enter the project directory:

```bash
git clone https://github.com/<your-username>/secureDep.git
cd secureDep
```

Create and activate a virtual environment.

**Windows PowerShell**
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install the project with development dependencies:

```bash
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

Confirm that the command is available:

```bash
securedep --help
```

## Quick start

Scan a package from PyPI (the default ecosystem):

```bash
securedep scan requests
```

Scan an npm package:

```bash
securedep scan cross-env --ecosystem npm
```

Scan a specific version:

```bash
securedep scan somepackage --package-version 1.2.3
```

Scan a local archive or extracted directory without fetching it from a registry:

```bash
securedep scan ./samples/example.tar.gz --local --name example
```

Generate JSON output:

```bash
securedep scan requests --json
```

Show detailed evidence:

```bash
securedep scan requests --verbose
```

Save a report to a file:

```bash
securedep scan requests --json --output reports/requests.json
```

List the available indicators and their configured weights:

```bash
securedep indicators
securedep indicators --json
```

## Command reference

### `securedep scan`

| Option | Description |
|---|---|
| `TARGET` | Registry package name, or local path when `--local` is used |
| `--ecosystem`, `-e` | `pypi` or `npm`; defaults to `pypi` |
| `--package-version`, `-v` | Select a package version |
| `--local` | Scan a local archive or extracted directory |
| `--name` | Display name for a local scan |
| `--json` | Emit a JSON report |
| `--verbose` | Include detailed evidence and score breakdown |
| `--check-repository` | Make an additional request to verify a declared repository URL |
| `--explain` | Request the optional AI explanation layer |
| `--output`, `-o` | Write the report to a file |

### `securedep indicators`

Lists indicator definitions, categories, weights, and combination rules. Add `--json` for machine-readable output.

## Risk levels and exit codes

The CLI uses exit codes so that scans can be integrated into scripts and CI pipelines.

| Exit code | Meaning |
|---:|---|
| `0` | Low risk |
| `1` | Medium risk |
| `2` | High risk |
| `3` | Critical risk |
| `4` | Scanner or input error |

A non-zero result is not automatically proof of malicious intent. Review the report and the supporting evidence before taking action.

## Project structure

```text
secureDep/
├── .github/
│   └── workflows/          # Continuous integration workflow
├── docs/                   # Setup, safety, calibration, and design docs
│   ├── adr/                # Architecture decision records
│   └── superpowers/        # Project design notes
├── samples/                # Safe sample package guidance
├── scripts/                # Evaluation and calibration utilities
├── src/
│   └── securedep/
│       ├── acquisition/    # Registry access and safe extraction
│       ├── analysis/       # Static analysis modules
│       ├── data/           # Popular package-name reference lists
│       ├── reporting/      # Text and JSON reports
│       └── scoring/        # Indicators, combinations, and risk scoring
├── tests/                  # Automated tests and synthetic fixtures
├── pyproject.toml          # Package and tool configuration
└── README.md
```

## Testing

Install development dependencies, then run:

```bash
pytest
```

Optional code-quality checks:

```bash
ruff check src/ tests/
ruff format --check src/ tests/
```

To apply formatting:

```bash
ruff format src/ tests/
```

## Current implementation status

The repository README and design documents distinguish implemented functionality from planned work.

**Implemented:** package acquisition, hardened extraction, analysis modules, scoring, text/JSON reporting, CLI, tests, and evaluation/calibration tooling.

**Not yet implemented:** the full AI explanation layer and MCP interface. The optional explanation command may report that its dependency or implementation is unavailable.

**Evaluation caveat:** configured indicator weights and risk thresholds are provisional until calibrated against a suitable labelled dataset. Do not present them as measured accuracy or validated production performance. See [docs/CALIBRATION.md](docs/CALIBRATION.md).

## Security and responsible use

- Scan only packages and samples you are authorised to examine.
- Read [docs/SAFETY.md](docs/SAFETY.md) before handling real malicious samples.
- Do not install suspicious packages to test them.
- Keep real malware archives and sensitive evaluation corpora out of Git.
- Treat scan results as decision support; investigate evidence and false positives.
- Do not use SecureDep as the sole control for software supply-chain security.

## Documentation

| Document | Description |
|---|---|
| [Project overview](docs/PROJECT_OVERVIEW.md) | Purpose, objectives, scope, and expected users |
| [Architecture](docs/ARCHITECTURE.md) | Scanner workflow and module responsibilities |
| [User guide](docs/USER_GUIDE.md) | Installation, commands, and interpreting reports |
| [Setup guide](docs/SETUP_GUIDE.md) | Detailed environment setup |
| [Safety guide](docs/SAFETY.md) | Safe handling of suspicious packages |
| [Calibration](docs/CALIBRATION.md) | Evaluation methodology and threshold calibration |
| [Architecture decisions](docs/adr/) | Recorded design decisions |

## Contributing

Contributions are welcome. Before submitting a change:

1. Read the setup and safety documentation.
2. Create a focused branch for your change.
3. Add or update tests for changed behaviour.
4. Run `pytest` and the Ruff checks.
5. Update documentation when commands or behaviour change.

See [CONTRIBUTING.md](CONTRIBUTING.md) for the contribution workflow.

## License

This project declares the MIT License in `pyproject.toml`. Add a `LICENSE` file containing the full MIT License text before distributing the repository as an MIT-licensed project.
