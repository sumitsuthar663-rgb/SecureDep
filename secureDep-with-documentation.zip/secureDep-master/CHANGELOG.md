# Changelog

Notable project changes are recorded here.

## 0.1.0

- Initial documented project version.
- Static scanning workflow for npm and PyPI package inputs.
- Registry acquisition and local archive/directory scanning.
- Metadata, installation-hook, Python/JavaScript AST, obfuscation, deobfuscation, and typosquatting analysis modules.
- Indicator scoring and combination rules.
- Terminal and JSON reporting.
- Command-line interface, tests, and evaluation/calibration utilities.

> This changelog describes the repository's declared initial feature set. It is not a claim of independently validated detection accuracy.
