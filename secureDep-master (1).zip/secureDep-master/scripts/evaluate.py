#!/usr/bin/env python3
"""Phase 5 evaluation harness (section 10).

Scans a labelled dataset and reports the metrics the project is judged on:
precision, recall, F1 and false positive rate, plus the two analyses that show
the weights were derived rather than guessed - per-indicator effectiveness and
a threshold sweep.

    # build a manifest of benign packages from the popular-name lists
    python scripts/evaluate.py build-manifest --benign 200 --out data/manifest.csv

    # download the corpus once (samples/ is gitignored - see docs/SAFETY.md)
    python scripts/evaluate.py fetch --manifest data/manifest.csv --corpus samples/

    # scan and score
    python scripts/evaluate.py run --manifest data/manifest.csv --corpus samples/ \
        --out results/

Manifest columns: name, ecosystem, version, label, source
  label is "malicious" or "benign".

Packages are downloaded and extracted, never installed and never executed.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from securedep.analysis.engine import scan_local  # noqa: E402
from securedep.analysis.typosquatting import load_popular  # noqa: E402
from securedep.models import Ecosystem, PackageRef, RiskBand  # noqa: E402
from securedep.scoring.model import THRESHOLDS  # noqa: E402

BANDS = [RiskBand.LOW, RiskBand.MEDIUM, RiskBand.HIGH, RiskBand.CRITICAL]


@dataclass
class Sample:
    name: str
    ecosystem: Ecosystem
    version: str | None
    label: str
    source: str = ""

    @property
    def is_malicious(self) -> bool:
        return self.label == "malicious"

    @property
    def slug(self) -> str:
        safe = self.name.replace("/", "__").replace("@", "")
        return f"{self.ecosystem.value}_{safe}"


@dataclass
class Outcome:
    sample: Sample
    score: float = 0.0
    band: str = "low"
    indicators: set[str] = field(default_factory=set)
    error: str = ""


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------


def confusion(outcomes: list[Outcome], threshold: float) -> dict[str, int]:
    counts = {"tp": 0, "fp": 0, "tn": 0, "fn": 0}
    for outcome in outcomes:
        if outcome.error:
            continue
        flagged = outcome.score >= threshold
        if outcome.sample.is_malicious:
            counts["tp" if flagged else "fn"] += 1
        else:
            counts["fp" if flagged else "tn"] += 1
    return counts


def metrics(counts: dict[str, int]) -> dict[str, float]:
    tp, fp, tn, fn = counts["tp"], counts["fp"], counts["tn"], counts["fn"]
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    fpr = fp / (fp + tn) if fp + tn else 0.0
    accuracy = (tp + tn) / max(1, tp + tn + fp + fn)
    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "false_positive_rate": fpr,
        "accuracy": accuracy,
    }


def per_indicator(outcomes: list[Outcome]) -> list[dict]:
    """How often each indicator fires on malicious vs benign packages.

    This is what justifies the weights: an indicator that fires on 80% of
    malicious packages and 2% of benign ones is discriminative; one that fires
    equally on both carries no information regardless of how alarming it sounds.
    """
    malicious = [o for o in outcomes if o.sample.is_malicious and not o.error]
    benign = [o for o in outcomes if not o.sample.is_malicious and not o.error]

    seen: set[str] = set()
    for outcome in outcomes:
        seen |= outcome.indicators

    rows = []
    for indicator in sorted(seen):
        m = sum(1 for o in malicious if indicator in o.indicators)
        b = sum(1 for o in benign if indicator in o.indicators)
        m_rate = m / len(malicious) if malicious else 0.0
        b_rate = b / len(benign) if benign else 0.0
        rows.append(
            {
                "indicator": indicator,
                "malicious_hits": m,
                "benign_hits": b,
                "malicious_rate": round(m_rate, 4),
                "benign_rate": round(b_rate, 4),
                # Positive means the indicator favours a malicious verdict.
                "discriminative_power": round(m_rate - b_rate, 4),
            }
        )

    rows.sort(key=lambda r: -r["discriminative_power"])
    return rows


def threshold_sweep(outcomes: list[Outcome], step: float = 0.5, limit: float = 40.0) -> list[dict]:
    rows = []
    value = 0.0
    while value <= limit:
        counts = confusion(outcomes, value)
        rows.append({"threshold": round(value, 2), **counts, **metrics(counts)})
        value += step
    return rows


def score_distribution(outcomes: list[Outcome], label: str) -> dict:
    scores = sorted(o.score for o in outcomes if o.sample.label == label and not o.error)
    if not scores:
        return {}

    def pct(p: float) -> float:
        index = min(len(scores) - 1, int(round((len(scores) - 1) * p)))
        return round(scores[index], 2)

    return {
        "count": len(scores),
        "min": round(scores[0], 2),
        "p50": pct(0.50),
        "p90": pct(0.90),
        "p95": pct(0.95),
        "p99": pct(0.99),
        "max": round(scores[-1], 2),
        "mean": round(sum(scores) / len(scores), 2),
    }


# ---------------------------------------------------------------------------
# Manifest / corpus
# ---------------------------------------------------------------------------


def read_manifest(path: Path) -> list[Sample]:
    samples = []
    with open(path, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if not row.get("name"):
                continue
            samples.append(
                Sample(
                    name=row["name"].strip(),
                    ecosystem=Ecosystem(row.get("ecosystem", "pypi").strip()),
                    version=(row.get("version") or "").strip() or None,
                    label=row.get("label", "benign").strip(),
                    source=row.get("source", "").strip(),
                )
            )
    return samples


def cmd_build_manifest(args: argparse.Namespace) -> int:
    """Draw a benign sample from the popular-name lists.

    Section 10.1 asks for two benign groups: heavily-used packages, which are
    continuously scrutinised, and low-popularity but legitimate ones, which are
    the hardest cases and the main source of false positives. The popular list
    is ordered by downloads, so the tail of it stands in for the second group -
    note in the report that this is an approximation, not a random draw from
    the whole registry.
    """
    random.seed(args.seed)
    rows: list[dict] = []

    for ecosystem in (Ecosystem.PYPI, Ecosystem.NPM):
        if args.ecosystem != "both" and args.ecosystem != ecosystem.value:
            continue
        names = sorted(load_popular(ecosystem))
        if not names:
            print(f"no popular-name list for {ecosystem.value}", file=sys.stderr)
            continue

        head = names[: max(1, len(names) // 2)]
        tail = names[max(1, len(names) // 2) :]
        want = args.benign // (1 if args.ecosystem != "both" else 2)

        chosen = random.sample(head, min(len(head), want // 2))
        chosen += random.sample(tail, min(len(tail), want - len(chosen)))

        for name in chosen:
            rows.append(
                {
                    "name": name,
                    "ecosystem": ecosystem.value,
                    "version": "",
                    "label": "benign",
                    "source": "popular-name list",
                }
            )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["name", "ecosystem", "version", "label", "source"]
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"wrote {len(rows)} benign rows to {args.out}")
    print(
        "\nAdd malicious rows before running the evaluation. Section 10.1 names\n"
        "Backstabber's Knife Collection as the source; label them 'malicious'.\n"
        "Recall cannot be reported from a benign-only manifest."
    )
    return 0


def cmd_fetch(args: argparse.Namespace) -> int:
    """Download and extract the corpus once, so scans are repeatable offline."""
    from securedep.acquisition import acquire

    samples = read_manifest(args.manifest)
    args.corpus.mkdir(parents=True, exist_ok=True)
    ok = failed = skipped = 0

    for index, sample in enumerate(samples, 1):
        target = args.corpus / sample.slug
        if target.exists():
            skipped += 1
            continue

        print(f"[{index}/{len(samples)}] {sample.ecosystem.value}:{sample.name}", file=sys.stderr)
        try:
            acquired = acquire(
                PackageRef(sample.name, sample.ecosystem, sample.version),
                workdir=target,
                keep=True,
            )
            (target / "label").write_text(sample.label, encoding="utf-8")
            del acquired
            ok += 1
        except Exception as exc:
            print(f"    failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            failed += 1

    print(f"\nfetched {ok}, skipped {skipped} already present, {failed} failed")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    samples = read_manifest(args.manifest)
    outcomes: list[Outcome] = []

    for index, sample in enumerate(samples, 1):
        ref = PackageRef(sample.name, sample.ecosystem, sample.version)
        outcome = Outcome(sample=sample)

        extracted = args.corpus / sample.slug / "extracted"
        try:
            if extracted.is_dir():
                result, _ = scan_local(extracted, ref)
            elif args.allow_network:
                from securedep.analysis.engine import scan

                result, _ = scan(ref)
            else:
                raise FileNotFoundError(f"{extracted} not in corpus (run `fetch` first)")

            outcome.score = result.score
            outcome.band = result.band.value
            outcome.indicators = result.indicators
        except Exception as exc:
            outcome.error = f"{type(exc).__name__}: {exc}"

        outcomes.append(outcome)
        if index % 10 == 0 or index == len(samples):
            print(f"  scanned {index}/{len(samples)}", file=sys.stderr)

    args.out.mkdir(parents=True, exist_ok=True)

    sweep = threshold_sweep(outcomes)
    best_f1 = max(sweep, key=lambda r: r["f1"]) if any(r["f1"] for r in sweep) else None

    report = {
        "samples": {
            "total": len(outcomes),
            "malicious": sum(1 for o in outcomes if o.sample.is_malicious),
            "benign": sum(1 for o in outcomes if not o.sample.is_malicious),
            "errors": sum(1 for o in outcomes if o.error),
        },
        "current_thresholds": {b.value: v for b, v in THRESHOLDS.items()},
        "at_current_high_threshold": {
            **confusion(outcomes, THRESHOLDS[RiskBand.HIGH]),
            **metrics(confusion(outcomes, THRESHOLDS[RiskBand.HIGH])),
        },
        "score_distribution": {
            "benign": score_distribution(outcomes, "benign"),
            "malicious": score_distribution(outcomes, "malicious"),
        },
        "best_f1_threshold": best_f1,
        "per_indicator": per_indicator(outcomes),
        "band_counts": {
            label: {
                band.value: sum(
                    1
                    for o in outcomes
                    if not o.error and o.sample.label == label and o.band == band.value
                )
                for band in BANDS
            }
            for label in ("benign", "malicious")
        },
    }

    (args.out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (args.out / "threshold_sweep.json").write_text(json.dumps(sweep, indent=2), encoding="utf-8")

    with open(args.out / "outcomes.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["name", "ecosystem", "label", "score", "band", "indicators", "error"])
        for o in outcomes:
            writer.writerow(
                [
                    o.sample.name,
                    o.sample.ecosystem.value,
                    o.sample.label,
                    round(o.score, 2),
                    o.band,
                    " ".join(sorted(o.indicators)),
                    o.error,
                ]
            )

    _print_summary(report, outcomes)
    return 0


def _print_summary(report: dict, outcomes: list[Outcome]) -> None:
    print("\n" + "=" * 62)
    print("EVALUATION SUMMARY")
    print("=" * 62)

    s = report["samples"]
    print(
        f"\n{s['total']} samples: {s['malicious']} malicious, "
        f"{s['benign']} benign, {s['errors']} errors"
    )

    for label in ("benign", "malicious"):
        dist = report["score_distribution"][label]
        if dist:
            print(
                f"\n{label} scores: min {dist['min']}, median {dist['p50']}, "
                f"p90 {dist['p90']}, p95 {dist['p95']}, max {dist['max']}"
            )

    print("\nband distribution")
    for label, counts in report["band_counts"].items():
        if sum(counts.values()):
            print(f"  {label:10} " + "  ".join(f"{b}={n}" for b, n in counts.items()))

    if s["malicious"] == 0:
        print(
            "\nNo malicious samples in this manifest, so precision, recall and F1\n"
            "are undefined. What this run does give you is the benign score\n"
            "distribution - use the percentiles above to choose thresholds, then\n"
            "re-run with malicious samples to measure recall."
        )
    else:
        current = report["at_current_high_threshold"]
        print(f"\nat the current HIGH threshold ({report['current_thresholds']['high']}):")
        print(
            f"  precision {current['precision']:.3f}  recall {current['recall']:.3f}  "
            f"F1 {current['f1']:.3f}  FPR {current['false_positive_rate']:.3f}"
        )
        best = report["best_f1_threshold"]
        if best:
            print(
                f"\nbest F1 at threshold {best['threshold']}: "
                f"precision {best['precision']:.3f}  "
                f"recall {best['recall']:.3f}  F1 {best['f1']:.3f}"
            )

    print("\ntop discriminative indicators")
    for row in report["per_indicator"][:12]:
        print(
            f"  {row['discriminative_power']:+.3f}  {row['indicator']:<42}"
            f" mal {row['malicious_rate']:.2f}  ben {row['benign_rate']:.2f}"
        )

    worst = [o for o in outcomes if not o.sample.is_malicious and not o.error]
    worst.sort(key=lambda o: -o.score)
    if worst:
        print("\nhighest-scoring benign packages (the false positives to investigate)")
        for o in worst[:10]:
            print(f"  {o.score:6.1f}  {o.sample.ecosystem.value}:{o.sample.name}")

    errors = [o for o in outcomes if o.error]
    if errors:
        print(f"\n{len(errors)} samples errored, e.g.:")
        for o in errors[:5]:
            print(f"  {o.sample.name}: {o.error}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    sub = parser.add_subparsers(dest="command", required=True)

    build = sub.add_parser(
        "build-manifest", help="draw a benign sample from the popular-name lists"
    )
    build.add_argument("--benign", type=int, default=200)
    build.add_argument("--ecosystem", choices=["pypi", "npm", "both"], default="both")
    build.add_argument("--seed", type=int, default=20250728)
    build.add_argument("--out", type=Path, default=Path("data/manifest.csv"))
    build.set_defaults(func=cmd_build_manifest)

    fetch = sub.add_parser("fetch", help="download the corpus described by a manifest")
    fetch.add_argument("--manifest", type=Path, required=True)
    fetch.add_argument("--corpus", type=Path, default=Path("samples"))
    fetch.set_defaults(func=cmd_fetch)

    run = sub.add_parser("run", help="scan the corpus and compute metrics")
    run.add_argument("--manifest", type=Path, required=True)
    run.add_argument("--corpus", type=Path, default=Path("samples"))
    run.add_argument("--out", type=Path, default=Path("results"))
    run.add_argument(
        "--allow-network",
        action="store_true",
        help="fetch samples missing from the corpus instead of erroring",
    )
    run.set_defaults(func=cmd_run)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
