#!/usr/bin/env python3
"""Populate the popular-package name lists used by the typosquatting detector.

The detector compares a candidate name against the most-downloaded package
names in each ecosystem (section 7.7 targets roughly the top 10,000). Those
lists are data, not code, so they are fetched here and committed, rather than
downloaded at scan time - the scanner must work offline and must give the same
answer today and at the demonstration.

    python scripts/fetch_popular_names.py --limit 10000

Sources:
  PyPI - hugovk/top-pypi-packages, derived from the official BigQuery download
         statistics and refreshed monthly.
  npm  - the registry's own download-count rankings via the npm API.
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from datetime import date
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).resolve().parent.parent / "src" / "securedep" / "data"

PYPI_SOURCES = (
    "https://hugovk.github.io/top-pypi-packages/top-pypi-packages.min.json",
    "https://raw.githubusercontent.com/hugovk/top-pypi-packages/main/top-pypi-packages.min.json",
)
NPM_SOURCES = (
    "https://raw.githubusercontent.com/anvaka/npmrank/master/online/npmrank.json",
    "https://raw.githubusercontent.com/nice-registry/all-the-package-repos/master/data/packages.json",
)

USER_AGENT = "SecureDep/0.1 (final year project; name-list builder)"

NETWORK_HINT = (
    "This needs unrestricted outbound HTTPS. If you are behind a proxy that "
    "only allows the registries themselves, run this script from a normal "
    "network connection and commit the resulting file."
)


def _get(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        return response.read()


def _first_working(sources: tuple[str, ...]) -> tuple[str, Any]:
    errors = []
    for url in sources:
        try:
            return url, json.loads(_get(url))
        except Exception as exc:
            errors.append(f"  {url}\n    {exc}")
    raise RuntimeError("all sources failed:\n" + "\n".join(errors) + f"\n\n{NETWORK_HINT}")


def fetch_pypi(limit: int) -> tuple[str, list[str]]:
    url, data = _first_working(PYPI_SOURCES)
    rows = data["rows"] if isinstance(data, dict) else data
    names = []
    for row in rows[:limit]:
        name = row.get("project") or row.get("name") if isinstance(row, dict) else row
        if name:
            names.append(name)
    return url, names


def fetch_npm(limit: int) -> tuple[str, list[str]]:
    """Fetch npm names ranked by download count.

    The registry's own search endpoint is relevance-ranked and caps out at a
    few thousand results, so it cannot produce a top-10,000-by-downloads list.
    A published ranking dataset is used instead.
    """
    url, data = _first_working(NPM_SOURCES)

    if isinstance(data, dict) and "rows" in data:
        rows = sorted(
            data["rows"],
            key=lambda r: (
                r.get("value", {}).get("rank", 0) if isinstance(r.get("value"), dict) else 0
            ),
            reverse=True,
        )
        names = [r["id"] for r in rows[:limit] if r.get("id")]
    elif isinstance(data, dict):
        names = list(data.keys())[:limit]
    else:
        names = [n for n in data[:limit] if isinstance(n, str)]

    return url, names


def write(path: Path, names: list[str], source: str) -> None:
    seen: set[str] = set()
    ordered: list[str] = []
    for name in names:
        key = name.lower()
        if key not in seen:
            seen.add(key)
            ordered.append(name)

    header = [
        f"# Most-downloaded {path.stem.split('_')[1]} package names.",
        f"# Source: {source}",
        f"# Generated: {date.today().isoformat()} ({len(ordered)} names)",
        "# Regenerate with: python scripts/fetch_popular_names.py",
        "",
    ]
    path.write_text("\n".join(header + ordered) + "\n", encoding="utf-8")
    print(f"wrote {len(ordered)} names to {path}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=10000)
    parser.add_argument("--ecosystem", choices=["pypi", "npm", "both"], default="both")
    args = parser.parse_args()

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    failures = 0

    if args.ecosystem in ("pypi", "both"):
        print("fetching PyPI names...")
        try:
            source, names = fetch_pypi(args.limit)
            write(DATA_DIR / "popular_pypi.txt", names, source)
        except Exception as exc:
            print(f"PyPI fetch failed:\n{exc}", file=sys.stderr)
            failures += 1

    if args.ecosystem in ("npm", "both"):
        print("fetching npm names...")
        try:
            source, names = fetch_npm(args.limit)
            write(DATA_DIR / "popular_npm.txt", names, source)
        except Exception as exc:
            print(f"npm fetch failed:\n{exc}", file=sys.stderr)
            failures += 1

    if failures:
        print(
            "\nThe curated seed lists already in src/securedep/data/ are still in place.",
            file=sys.stderr,
        )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
