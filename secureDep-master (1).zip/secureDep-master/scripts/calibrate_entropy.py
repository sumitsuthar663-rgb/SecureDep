#!/usr/bin/env python3
"""Derive the obfuscation thresholds from data (section 7.5).

Section 7.5 requires the entropy cut-off to be "established empirically by
measuring entropy across a large sample of known-benign packages and selecting
a cut-off that separates them from known-malicious samples". This script does
the measuring; the numbers it prints are what should replace the constants in
``securedep/analysis/obfuscation.py``.

    python scripts/calibrate_entropy.py --corpus samples/ --label-file

Without malicious samples it can still report the benign distribution, which
bounds the false positive rate: a threshold at the benign p99 will misfire on
roughly 1% of benign files by construction.
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from securedep.analysis.obfuscation import (  # noqa: E402
    ANALYSED_SUFFIXES,
    file_metrics,
    looks_encoded,
    shannon_entropy,
    string_literals,
)

METRICS = (
    "file_entropy",
    "max_line_length",
    "max_string_entropy",
    "meaningless_ratio",
    "non_alpha_ratio",
)


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, int(round((len(ordered) - 1) * p)))
    return ordered[index]


def summarise(values: list[float]) -> dict[str, float]:
    if not values:
        return {}
    return {
        "n": len(values),
        "min": round(min(values), 3),
        "p50": round(percentile(values, 0.50), 3),
        "p90": round(percentile(values, 0.90), 3),
        "p95": round(percentile(values, 0.95), 3),
        "p99": round(percentile(values, 0.99), 3),
        "p999": round(percentile(values, 0.999), 3),
        "max": round(max(values), 3),
        "mean": round(statistics.fmean(values), 3),
    }


def collect(corpus: Path, label_filter: str | None) -> dict[str, dict[str, list[float]]]:
    buckets: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    literal_entropies: dict[str, list[float]] = defaultdict(list)
    scanned = 0

    for package in sorted(p for p in corpus.iterdir() if p.is_dir()):
        label_file = package / "label"
        label = (
            label_file.read_text(encoding="utf-8").strip() if label_file.is_file() else "unknown"
        )
        if label_filter and label != label_filter:
            continue

        root = package / "extracted"
        if not root.is_dir():
            root = package

        for path in root.rglob("*"):
            if not path.is_file() or path.is_symlink() or path.suffix not in ANALYSED_SUFFIXES:
                continue
            try:
                if path.stat().st_size > 4 * 1024 * 1024:
                    continue
                source = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            if not source.strip():
                continue

            metrics = file_metrics(source)
            for name in METRICS:
                buckets[label][name].append(metrics[name])

            for _, value in string_literals(source):
                if len(value) >= 40 and looks_encoded(value):
                    literal_entropies[label].append(shannon_entropy(value))

            scanned += 1

    for label, values in literal_entropies.items():
        buckets[label]["encoded_literal_entropy"] = values

    print(f"measured {scanned} source files", file=sys.stderr)
    return buckets


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--corpus", type=Path, default=Path("samples"))
    parser.add_argument("--label", help="restrict to one label (benign/malicious)")
    parser.add_argument("--out", type=Path, help="write the full distribution as JSON")
    args = parser.parse_args()

    if not args.corpus.is_dir():
        print(f"{args.corpus} is not a directory", file=sys.stderr)
        return 1

    buckets = collect(args.corpus, args.label)
    report = {
        label: {name: summarise(values) for name, values in metrics.items()}
        for label, metrics in buckets.items()
    }

    for label, metrics in sorted(report.items()):
        print(f"\n=== {label} ===")
        for name, stats in metrics.items():
            if stats:
                print(
                    f"  {name:28} n={stats['n']:<7} p50={stats['p50']:<8} "
                    f"p95={stats['p95']:<8} p99={stats['p99']:<8} max={stats['max']}"
                )

    benign = report.get("benign", {})
    if benign:
        print("\nSuggested thresholds (benign p99 - expect ~1% of benign files above each):")
        mapping = {
            "encoded_literal_entropy": "ENTROPY_THRESHOLD",
            "max_line_length": "LONG_LINE_THRESHOLD",
            "meaningless_ratio": "MEANINGLESS_IDENTIFIER_RATIO",
        }
        for metric, constant in mapping.items():
            stats = benign.get(metric)
            if stats:
                print(f"  {constant:32} = {stats['p99']}")

        if "malicious" in report:
            print(
                "\nCompare against the malicious distribution above and choose the "
                "cut-off that separates them, rather than the benign p99 alone."
            )
        else:
            print(
                "\nNo malicious samples in this corpus, so these bound the false "
                "positive rate but say nothing about recall. Re-run with malicious "
                "samples before quoting a threshold as derived."
            )

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nwrote {args.out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
