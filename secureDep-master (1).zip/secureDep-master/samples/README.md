# samples/

Downloaded package corpora live here. **Everything in this directory except
this file is gitignored, and that must stay true** — it holds live malicious
packages during evaluation.

Read `../docs/SAFETY.md` before putting anything here. The two rules:

1. Never run `pip install` or `npm install` on a sample.
2. Never commit a sample.

Populate it with:

```bash
python scripts/evaluate.py fetch --manifest data/manifest.csv --corpus samples/
```

Each sample lands in `samples/<ecosystem>_<name>/` containing `archive/`, the
downloaded file, `extracted/`, the unpacked tree, and `label`, which the
calibration script reads.
