# SecureDep

Static analysis of npm and PyPI packages for indicators of malicious behaviour.
SecureDep downloads a package and reads it; it never installs or executes it.

> Final year project — BE Cyber Security. See `docs/` for the design decisions
> and `docs/SAFETY.md` before working with real malware samples.

## What it does

Public package registries let anyone publish, and package managers execute
installation scripts automatically. A malicious package therefore runs code on
a developer's machine the moment it is installed — before the developer has
used it at all. SecureDep examines a package *before* it is trusted and reports
whether it looks malicious, with the evidence for each finding.

The pipeline has four stages. Only the first two exist today (see
[Status](#status)):

| Stage | What it does |
|---|---|
| 1. Acquisition | Fetch the archive from the registry and extract it safely |
| 2. Analysis engine | Metadata, install hooks, AST behaviour, obfuscation, deobfuscation, typosquatting → indicators → risk score |
| 3. AI explanation | Describe flagged code in plain language *(not yet built)* |
| 4. MCP interface | Expose the engine as tools for an AI agent *(not yet built)* |

**The detection decision is made entirely in Stage 2 by deterministic,
hand-written logic.** Stages 3 and 4 add explanation and usability. If the AI
components were removed, the tool would still function as a complete scanner.
That separation is deliberate: language models are inconsistent and will
confidently describe behaviour that is not present, which is unacceptable in a
security verdict. Restricting a model to *explaining* findings uses its genuine
strength while keeping the verdict reproducible.

## Install

Requires Python 3.10+.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

## Use

```bash
# scan a package from PyPI (default) or npm
securedep scan requests
securedep scan cross-env --ecosystem npm
securedep scan somepackage --package-version 1.2.3

# analyse a local archive or directory without touching the network
securedep scan ./samples/suspicious.tar.gz --local --name suspicious

# structured output for tooling, full evidence for reading
securedep scan somepackage --json
securedep scan somepackage --verbose

# the indicator catalogue and every weight
securedep indicators
```

Exit codes make it usable as a gate: `0` low, `1` medium, `2` high,
`3` critical, `4` error.

## How detection works

Each analyser reports *behaviour*; none of them decides a verdict. Scoring runs
once at the end over the complete set of findings.

- **Metadata** (`analysis/metadata.py`) — age, version count, repository,
  licence, how much real code the package contains.
- **Install hooks** (`analysis/install_scripts.py`) — npm `pre/post/install`
  scripts, and `setup.py` logic including `cmdclass` overrides. `setup.py` is
  *parsed*, never run. This is the strongest single indicator: legitimate pure
  Python and JavaScript packages rarely need to execute anything at install
  time, while most malicious packages depend on it.
- **AST analysis** (`analysis/ast_python.py`, `analysis/ast_js.py`) — dynamic
  execution, network activity, credential access, system reconnaissance,
  persistence, and encoding. Structural rather than textual, so
  `getattr(os, 'sys' + 'tem')` and `"ev" + "al"` do not hide anything. Import
  aliases and module-level string constants are resolved.
- **Obfuscation** (`analysis/obfuscation.py`) — Shannon entropy over string
  literals, long lines, meaningless identifiers, character-code arrays.
- **Deobfuscation** (`analysis/deobfuscation.py`) — reverses base64, hex and
  escape encodings and re-runs the analysers on what it recovers. Decoded
  content is treated purely as data and is never executed.
- **Typosquatting** (`analysis/typosquatting.py`) — Levenshtein distance
  (implemented here, not imported), keyboard adjacency, structural variations,
  and Unicode homoglyphs, against a list of popular names.

### Combination logic

Individual operations are usually harmless. Reading environment variables is
normal. Making a network request is normal. Doing both *from an install hook*
is credential theft. The engine therefore scores **combinations**, and each
combination rule declares the scope in which its behaviours must co-occur —
`install`, `file`, or `package`.

That scope is not a detail. Matching indicators anywhere in the archive
reported `setuptools`, `requests` and `PyYAML` as critical, because a large
package contains a `setup.py` and, in unrelated modules, code that reads the
environment and opens connections. See
[ADR 0002](docs/adr/0002-combination-scope.md).

Findings whose evidence comes only from test, documentation, example or
vendored directories are marked auxiliary: they score at reduced weight and
cannot satisfy a combination rule. Such code is shipped in the archive but is
not what runs when the package is used.

## Status

Built and tested:

- Stage 1 acquisition, with hardened extraction (path traversal, symlinks,
  decompression bombs) — `tests/test_extract.py`
- Stage 2 analysis engine, all six analysers, for PyPI and npm
- Risk scoring, JSON and terminal reports, CLI
- Evaluation harness and threshold calibration tooling

Not built yet:

- **Stage 3 (AI explanation)** and **Stage 4 (MCP server)**. The project
  document recommends completing the measured evaluation before adding these,
  so that the project is defensible even if the later phases run short of time.
  `securedep scan --explain` is wired up and will report that the layer is
  missing.
- **The measured evaluation itself.** See below — this is the most important
  outstanding work.

## Before you quote any numbers

Two things in this repository are deliberately marked as **provisional
estimates, not results**:

1. **Indicator weights** (`scoring/indicators.py`) — starting values chosen by
   judgement. Section 7.8 requires them to be set from measured discriminative
   power. `scripts/evaluate.py run` reports exactly that, per indicator.
2. **Risk band thresholds** (`scoring/model.py`) and **entropy cut-offs**
   (`analysis/obfuscation.py`) — `scripts/calibrate_entropy.py` and the
   threshold sweep in `scripts/evaluate.py` produce the distributions needed to
   choose them from data.

Neither has been calibrated against a labelled malicious corpus yet, because
that corpus is not in this repository. Presenting the current numbers as
empirically derived would be false.

### Running the evaluation

```bash
# 1. get the full popular-name lists (needs unrestricted network)
python scripts/fetch_popular_names.py --limit 10000

# 2. draw a benign sample, then add malicious rows to the manifest by hand
python scripts/evaluate.py build-manifest --benign 200 --out data/manifest.csv

# 3. download the corpus once (samples/ is gitignored — read docs/SAFETY.md)
python scripts/evaluate.py fetch --manifest data/manifest.csv --corpus samples/

# 4. scan and score
python scripts/evaluate.py run --manifest data/manifest.csv --corpus samples/ --out results/
python scripts/calibrate_entropy.py --corpus samples/
```

The harness reports precision, recall, F1 and false positive rate, a threshold
sweep, per-indicator effectiveness, and the highest-scoring benign packages so
false positives can be investigated individually.

Malicious samples should come from **Backstabber's Knife Collection** (Ohm et
al., DIMVA 2020) and published registry advisories. Record provenance in the
manifest's `source` column.

## On false positives

The tool will produce them. Some legitimate packages do use install scripts,
some do minify their code, some do have unusual names. This is expected and
unavoidable for behaviour-based detection.

The correct response is to measure the rate, tune the model to reduce it, and
report it honestly. A project reporting a 12% false positive rate with an
analysis of its causes demonstrates more competence than one claiming perfect
accuracy, which no examiner will believe.

## Development

```bash
pytest              # test suite
ruff check src/     # lint
ruff format src/    # format
```

Test fixtures in `tests/fixtures/` are synthetic packages written for this test
suite — they imitate the structure of a credential stealer but are inert and
were never published. Real samples never go in version control.

## References

1. Ohm, M., Plate, H., Sykosch, A., & Meier, M. (2020). *Backstabber's Knife
   Collection: A Review of Open Source Software Supply Chain Attacks.* DIMVA.
2. Zahan, N. et al. (2022). *What are Weak Links in the npm Supply Chain?*
   ICSE-SEIP.
3. Vu, D. L. et al. (2020). *Typosquatting and Combosquatting Attacks on the
   Python Ecosystem.* IEEE EuroS&PW.
4. OWASP Top 10 — A06:2021, *Vulnerable and Outdated Components.*
5. Shannon, C. E. (1948). *A Mathematical Theory of Communication.*
