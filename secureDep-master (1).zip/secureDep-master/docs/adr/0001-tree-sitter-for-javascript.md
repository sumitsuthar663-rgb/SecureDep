# ADR 0001 - Use tree-sitter instead of esprima-python for JavaScript parsing

**Status:** accepted
**Date:** 2026-07-28

## Context

The project document (section 8) specifies `esprima-python` for JavaScript AST
analysis. The AST analyser is the core of the detection engine, so the parser
choice directly bounds what the tool can detect.

`esprima-python` is a Python port of Esprima 4, which targets roughly ES2017.
It is effectively unmaintained, and - more importantly - it raises on syntax it
does not recognise, producing no tree at all.

Malicious npm packages are disproportionately minified, obfuscated, or written
against newer syntax. Those are exactly the packages the tool most needs to
analyse. A parser that fails on them fails silently in the worst direction:
zero indicators fire, and the package is reported as clean.

## Decision

Use `tree-sitter` with the `tree-sitter-javascript` grammar.

## Consequences

**Good**

- tree-sitter is error-tolerant. It produces a usable syntax tree even for
  input it cannot fully parse, so a partially-broken or obfuscated file still
  yields findings rather than nothing.
- It is actively maintained and tracks current JavaScript syntax.
- The same grammar family covers TypeScript and JSX if the project later
  extends to them.
- It is fast enough that whole-package scans stay interactive.

**Bad**

- It is a compiled dependency, so installation needs a wheel for the platform.
  Wheels are published for Linux, macOS and Windows on CPython 3.10+, so this
  is not a practical barrier.
- Its API is lower-level than esprima's: there are no typed AST node classes,
  only generic nodes with string type names and named fields. The analyser has
  to do slightly more work to resolve member expressions and `require` bindings
  (`analysis/ast_js.py`).
- It deviates from the written specification, which must be explained.

## How to defend this

The specification named a tool; the objective was recall on obfuscated
JavaScript. Choosing a parser that survives obfuscated input serves the
objective, and the deviation is documented rather than hidden. Where a file
still cannot be fully parsed, the scanner records a warning on the result, so a
clean verdict is never silently based on unanalysed code.
