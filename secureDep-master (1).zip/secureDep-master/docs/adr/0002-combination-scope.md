# ADR 0002 - Combination rules require a co-occurrence scope

**Status:** accepted
**Date:** 2026-07-28

## Context

Section 7.4 of the project document identifies combination logic as the
intellectual core of the engine: individual operations are usually harmless,
but specific combinations are not. The canonical example is a package that
reads environment variables *and then* sends them over the network *from an
installation script*.

The first implementation matched combination rules against the set of all
indicators that fired anywhere in the package. Measured against real packages,
this was badly wrong:

| Package | Verdict | Why |
|---|---|---|
| `setuptools` | CRITICAL | has a `setup.py`, and separately, in unrelated modules, reads the environment and opens connections |
| `requests` | CRITICAL | reports the platform in its User-Agent and makes HTTP requests - it is an HTTP library |
| `PyYAML` | CRITICAL | decodes `!!binary` and evaluates Python object tags, both in `constructor.py` |

In each case the individual indicators were correct. The combination was not:
the behaviours were never connected to each other.

## Decision

Every `ComboRule` declares a `scope` stating where its required behaviours must
co-occur:

- **`install`** - all required behaviours must appear in code that runs at
  install time. Used for the rules that carry the largest bonuses, because this
  is the project's actual thesis: installation executes code automatically, so
  behaviour there runs without the developer ever calling it.
- **`file`** - all required behaviours must appear in one file. A weaker but
  still meaningful notion of "connected".
- **`package`** - anywhere. Used only for rules involving package-level facts,
  such as the package's own name in the typosquatting rule.

Additionally, indicators whose evidence comes only from test, documentation,
example or vendored directories are marked auxiliary. They contribute a reduced
weight and cannot satisfy a combination rule, because such code is shipped in
the archive but is not what runs when the package is used - and it legitimately
opens sockets, spawns processes and hardcodes addresses.

## Consequences

**Good**

- Removed every combination false positive in the benign sample measured so
  far, without weakening detection on the malicious fixtures.
- Makes "combination" mean something defensible under questioning. "Both appear
  somewhere in the archive" is not evidence of a connection; "both run during
  installation" is.

**Bad**

- `install` scope will miss a payload that runs at import time rather than
  install time. This is a deliberate trade: the runtime case is partly covered
  by `obfuscation.decoded_payload_suspicious`, which fires only when a recovered
  payload is itself suspicious.
- `file` scope is still an approximation of connectedness. Proving that a
  decoded value actually reaches an `eval` needs dataflow analysis, which is out
  of scope for this project and is listed as future work.

## Note for the evaluation

These scopes are a detection design decision, not a tuning knob to be adjusted
until the numbers look good. If Phase 5 shows `install` scope costs significant
recall on the Backstabber's corpus, the honest response is to report that
trade-off, not to quietly widen the scopes.
