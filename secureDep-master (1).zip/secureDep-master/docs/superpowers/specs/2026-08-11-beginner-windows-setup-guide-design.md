# Beginner Windows Setup Guide Design

## Purpose

Create a standalone handover guide for a Windows user with no programming
experience. It must let them install SecureDep, run a package scan, understand
the outcome, and recover from common setup problems without needing the source
code or separate technical documentation.

## Audience and Assumptions

- The reader uses a Windows 10 or Windows 11 computer.
- The reader has not used Python, PowerShell, Git, or command-line tools.
- The reader receives a copy of the SecureDep project folder.
- The reader can download software from official websites and open PowerShell.

## Deliverable

Add `docs/SETUP_GUIDE.md`. The guide will use plain language, numbered steps,
copy-and-paste commands, and short explanations of what each step does. It
will be Windows-first and will refer to the project folder as the location the
reader received.

## Guide Structure

1. A short explanation of SecureDep and its safety boundary: it reads packages
   without installing or executing them.
2. Prerequisites: Windows, internet access for registry scans, and Python
   3.10 or newer, including an official Python download link and the required
   installer checkbox for adding Python to PATH.
3. Project-folder preparation and opening PowerShell in that folder.
4. Setup commands: create and activate an isolated Python environment, then
   install SecureDep and its development dependencies.
5. A first scan using a known package, followed by npm and local-archive
   examples.
6. A plain-language explanation of low, medium, high, critical, and error
   results, including the fact that results are risk signals rather than proof.
7. Common-problem troubleshooting for Python not found, PowerShell script
   activation blocked, command not found, network errors, and updating the
   project.
8. Safe-use notes: do not install a package merely because it scored low, and
   do not use unknown real malware samples outside a suitable controlled
   environment.

## Accuracy Rules

- Commands must match the CLI documented in `README.md` and the package script
  in `pyproject.toml`.
- The guide will state that the current risk thresholds are provisional, as the
  project has not yet completed calibration against a labelled malicious corpus.
- It will not suggest running malicious code or treating any scan as a guarantee.
- It will link readers to `docs/SAFETY.md` for work involving real malware
  samples.

## Verification

Review the final guide for a zero-knowledge reader: every required action has
a named Windows application, a clear location, a copyable command where needed,
and a recovery path for expected errors. Check all command examples against the
existing README and CLI behavior.
