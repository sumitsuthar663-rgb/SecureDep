# SecureDep Presentation Document Design

## Purpose

Create a standalone, presentation-ready PDF that explains SecureDep to college
examiners, classmates, and non-technical stakeholders. It must communicate the
problem, solution, prototype workflow, technical credibility, limits, and next
steps without requiring the reader to run the software.

## Deliverables

- An editable source document in `docs/`.
- A polished PDF export stored alongside its source document.
- The beginner Windows setup guide remains a separate deliverable and is not
  duplicated in the presentation document.

## Audience

- Final-year-project examiners and faculty.
- Classmates and other non-specialist presentation viewers.
- The project owner, who may use the document as a presentation script.

## Document Shape

The PDF will be approximately 8 to 10 pages, using short sections and clear
diagrams rather than report-length prose. Its narrative will progress from the
software-supply-chain problem to SecureDep's static analysis approach, then to
the user-facing prototype flow and an honest statement of the project's
current status.

## Page Outline

1. Title page: SecureDep, a short subtitle, and project context.
2. The problem: third-party package risk and installation-time execution.
3. The solution: what SecureDep does, and its important safety boundary.
4. System workflow: acquisition, static-analysis engine, findings, and risk
   score; identify planned AI explanation and MCP stages as future work.
5. Prototype user journey: enter a package, select PyPI/npm, run a scan, and
   inspect a risk result and evidence.
6. Detection approach: metadata, install hooks, AST analysis, obfuscation,
   deobfuscation, and typosquatting.
7. Example findings and interpretation: distinguish risk signals from proof.
8. Technical design and safeguards: safe extraction, no code execution,
   deterministic scoring, and reduced weight for auxiliary content.
9. Current status and limitations: implemented Stage 1 and Stage 2, planned
   AI/MCP work, and uncalibrated provisional thresholds.
10. Closing page: contribution, future work, and a concise demonstration
    script for a live presentation.

## Content Rules

- Use facts already documented in `README.md` and `docs/` only; do not claim
  measured accuracy, calibrated thresholds, or completed AI/MCP functionality.
- Explain technical concepts in plain language on first use.
- State that SecureDep downloads and reads packages but never installs or
  executes them.
- Frame results as indicators to investigate, not a guarantee that a package
  is safe or malicious.
- Include `docs/SAFETY.md` as the reference for handling real malware samples.

## Visuals

- A simple system-flow diagram showing the scanner's implemented stages and
  clearly separated future stages.
- A low-fidelity user-interface prototype illustrating the package scan flow.
- A compact risk-level key showing Low, Medium, High, Critical, and Error.
- Visuals use synthetic illustrative data only and must not depict real malware
  code or claim a real scan result.

## Verification

Render the PDF and inspect every page for readable text, intact diagrams,
correct page order, and non-overlapping content. Check claims and command
labels against `README.md`, `pyproject.toml`, and `docs/SAFETY.md`.
