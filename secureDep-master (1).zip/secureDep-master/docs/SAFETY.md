# Handling malicious samples safely

The evaluation in Phase 5 requires downloading confirmed-malicious packages.
These are safe to handle **provided they are never installed or executed**.

## The two rules

1. **Never run `npm install` or `pip install` on a sample under evaluation.**
   Download and extract the archive directly. SecureDep's acquisition module
   does exactly this and nothing more.

2. **Keep every sample in `samples/`**, which is excluded from version control
   by `.gitignore` and from all automated tooling. Never commit a sample.

## Why the architecture makes this safe

SecureDep is static-only. It reads files; it never imports, evaluates or
executes any part of a package it analyses. Specifically:

- `setup.py` is **parsed**, never run. Running it is how installation
  compromises a machine, so the install-script detector reads its AST instead
  (`analysis/install_scripts.py`).
- Content recovered by the deobfuscation module is treated purely as data. It
  is decoded in memory, analysed as text, and never written somewhere
  importable or passed to `eval` (`analysis/deobfuscation.py`).
- Archives are extracted with path traversal, symlink, and decompression-bomb
  guards, because extraction is the one step where an attacker-controlled
  archive could act on the analysing machine (`acquisition/extract.py`).
  Extracted files have their permission bits stripped to `0600`, so nothing
  arrives executable.

This is a genuine safety property of the design and is worth stating explicitly
in the report and the defence.

## Practical precautions

- Run evaluations in a VM or container if your institution requires it. It is
  not strictly necessary given the above, but it costs nothing.
- Do not open sample files in an editor that executes project code
  (auto-formatters, language servers, and Jupyter can all import a file).
  Add `samples/` to your editor's ignore list.
- Do not point antivirus-integrated backup or sync tools at `samples/` -
  quarantine mid-scan will produce confusing failures.
- Prefer sdists over wheels for PyPI: a wheel is already built and cannot
  contain an install hook, so it is strictly less informative.

## Where samples come from

- **Backstabber's Knife Collection** (Ohm et al., DIMVA 2020) - the academic
  dataset of confirmed malicious npm and PyPI packages, curated for exactly
  this kind of research.
- Published advisories from npm, PyPI, and the GitHub Advisory Database.

Record the provenance of every sample in the manifest's `source` column. An
evaluation whose dataset cannot be traced is not reproducible.
