# Calibration status

**Read this before quoting any number from this tool.**

## Summary

| Parameter | Status | Source |
|---|---|---|
| Risk band thresholds | **benign-calibrated only** | 120 PyPI packages, run below |
| Indicator weights | **not calibrated** — judgement | `scoring/indicators.py` |
| Combination bonuses | **not calibrated** — judgement | `scoring/indicators.py` |
| Entropy cut-off | **not calibrated** — judgement | `analysis/obfuscation.py` |

Precision, recall and F1 **have not been measured**, because no labelled
malicious corpus was available at the time of this run. What has been measured
is the benign score distribution, which bounds the false positive rate and
nothing else.

## The run

- **Date:** 2026-07-28
- **Corpus:** 120 packages drawn from `src/securedep/data/popular_pypi.txt`
  with `scripts/evaluate.py build-manifest --benign 120 --ecosystem pypi`,
  seed `20250728`. Half from the more-downloaded half of the list, half from
  the tail. 118 downloaded successfully; 2 failed to fetch.
- **Assumption:** these packages are benign. They are widely used and
  continuously scrutinised, which is the justification section 10.1 gives, but
  it is an assumption, not a verified label.
- **Command:**
  ```bash
  python scripts/evaluate.py build-manifest --benign 120 --ecosystem pypi --out data/manifest.csv
  python scripts/evaluate.py fetch --manifest data/manifest.csv --corpus samples/
  python scripts/evaluate.py run --manifest data/manifest.csv --corpus samples/ --out results/
  ```

### Measured benign score distribution

| Percentile | Score |
|---|---|
| min | 0.0 |
| p50 | 6.0 |
| p75 | 11.6 |
| p80 | 13.0 |
| p90 | 16.7 |
| p95 | 22.4 |
| p99 | 32.4 |
| max | 51.1 |

### Thresholds chosen from it

| Band | Threshold | Target | Benign packages measured at or above it |
|---|---|---|---|
| MEDIUM | 13.0 | p80 | 26/120 = **21.7%** |
| HIGH | 22.5 | p95 | 6/120 = **5.0%** |
| CRITICAL | 32.5 | p99 | 1/120 = **0.8%** |

The rule was "put each band at a percentile of the benign distribution", chosen
before looking at which packages fell where. That is deliberate: tuning until
particular named packages come out low would be overfitting to a 120-sample set.

The measured column is what the thresholds actually do, not what the percentile
targets imply — they differ slightly because scores are discrete and cluster.
Quote the measured figures, not the targets.

**Reproduced** against the committed code (commit `2164a33`): re-running the
command above yields this distribution exactly. The distribution is also
unchanged from a run made before the analyser performance fix, which confirms
that fix was behaviour-neutral.

## What this does not tell us

A threshold that flags 5% of benign packages might catch 95% of malware or 5% of
it. **Recall is completely unmeasured.** Setting thresholds from benign data
alone systematically risks setting them too high, because it optimises only one
side of the trade-off.

Phase 5 must:

1. Add malicious rows to the manifest from Backstabber's Knife Collection and
   registry advisories (see `docs/SAFETY.md`).
2. Re-run `scripts/evaluate.py run`, which reports the full threshold sweep and
   per-indicator discriminative power.
3. Reset the weights in `scoring/indicators.py` from measured discriminative
   power rather than judgement, then re-run.
4. Reset the entropy cut-off using `scripts/calibrate_entropy.py`.
5. Update this document and the comments in the source.

## Highest-scoring benign packages

These are the false positives to investigate, and they belong in the failure
analysis section of the report.

| Score | Package | Why it scores high |
|---|---|---|
| 51.1 | `ansible` | Its purpose *is* remote command execution. Thousands of modules spawn processes, read credentials and open connections. Genuinely hard: the behaviour is real, only the intent differs. |
| 32.4 | `notebook` | Executes user-supplied code by design. |
| 30.8 | `moto` | Mocks AWS, so it handles credential-shaped data throughout. |
| 27.8 | `pipenv` | A package manager: it runs installers and subprocesses. |
| 27.5 | `pillow` | Large C-extension build with substantial setup logic. |
| 22.7 | `django` | Very large; accumulates many contextual indicators. |

The pattern is clear and worth stating in the defence: **packages whose
legitimate purpose is executing code, managing credentials, or building native
components are irreducibly hard for behaviour-based static analysis.** They are
not bugs in the analysers — the behaviours detected are really there. This is
the concrete form of the limitation the project document names in section 13.4.

An allowlist would hide the problem rather than solve it, and would not
generalise to the obscure legitimate packages that section 10.1 identifies as
the real difficulty.

## False positives already fixed

These were found by running against real packages during development, and each
one is now covered by a regression test in `tests/test_analysis_units.py`:

| Symptom | Cause | Fix |
|---|---|---|
| `requests` critical | "extract the cookies from the response" in a docstring matched a credential path | docstrings excluded; generic words require a path separator |
| `six` medium | emoji in a test file scored high Shannon entropy | `looks_encoded()` requires the restricted-alphabet shape first |
| `urllib3` high | `ABCDEFG...0123456789._-~` charset constant scored as encoded | charset definitions excluded (nearly all characters distinct) |
| `urllib3` high | `process.env[...]` matched the `.env` credential file | lookbehind excludes attribute access |
| `numpy` critical | vendored copy of meson writes to `.bashrc` | vendored directories marked auxiliary |
| `setuptools` critical | `setup.py` matched against unrelated modules' network calls | combination rules gained a co-occurrence scope (ADR 0002) |
| `PyYAML` critical | decodes `!!binary` and evals object tags in one file | decode→exec combination anchored to install time |
