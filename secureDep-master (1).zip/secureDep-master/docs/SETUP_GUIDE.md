# SecureDep: Windows Setup and First Use Guide

This guide is for someone using a Windows PC who has little or no coding
experience. Follow the steps in order. You only need to set up SecureDep once
on each computer.

## Before You Start

SecureDep is a security tool for checking software packages from PyPI (Python)
and npm (JavaScript) before you install them. It downloads a package and reads
its files. It does **not** install or run the package it scans.

You should have received a folder named `secureDep`. Keep this folder in a
location that is easy to find, such as Documents or Desktop. Do not rename or
delete its `src`, `docs`, or `samples` folders.

## What You Need

- A Windows 10 or Windows 11 computer.
- Internet access when scanning packages from PyPI or npm.
- The SecureDep project folder.
- Python 3.10 or newer. Python is a free program that SecureDep needs in order
  to run.

You do not need to install npm, Node.js, Git, or any other programming tool to
run the SecureDep scanner.

## Install Python

Skip this section only if you already know that Python 3.10 or newer is
installed on the computer.

1. Open the official [Python downloads for Windows](https://www.python.org/downloads/windows/) page.
2. Download a current Python 3 release for Windows. Python 3.12 is a good
   choice for this project.
3. Open the downloaded installer.
4. On the first installer screen, tick the box labelled **Add Python to PATH**.
   This is important: it lets PowerShell find Python later.
5. Select **Install Now** and wait until the installer says it has completed.
6. Close the installer.

To check that it worked, open the Start menu, type `PowerShell`, and open
**Windows PowerShell**. Type the following command, then press Enter:

```powershell
py --version
```

You should see a result such as `Python 3.12.x`. You can close PowerShell
after this check.

## Open PowerShell in the Project Folder

PowerShell is the Windows application used to enter the commands below. A
command is a short instruction you type or paste, then run by pressing Enter.

1. Open File Explorer and find the `secureDep` folder you received.
2. Click once in the folder address bar at the top of File Explorer.
3. Type `powershell` and press Enter.

A blue or black PowerShell window opens. Its last line should end with the
project folder name, similar to this:

```text
PS C:\Users\YourName\Documents\secureDep>
```

Keep this PowerShell window open for the remaining setup steps.

## Set Up SecureDep

The following steps create a private Python area inside the project folder and
install SecureDep there. This keeps SecureDep separate from other programs on
the computer.

1. Copy and paste this command into PowerShell, then press Enter:

```powershell
py -m venv .venv
```

OR

```powershell
python -m venv .venv
```

Wait for the command to finish. It normally produces no message.

2. Copy and paste this command, then press Enter:

```powershell
.\.venv\Scripts\Activate.ps1
```

When it works, `(.venv)` appears at the beginning of the PowerShell line.
For example:

```text
(.venv) PS C:\Users\YourName\Documents\secureDep>
```

3. Copy and paste these commands one at a time, pressing Enter after each one:

```powershell
python -m pip install --upgrade pip
```

```powershell
python -m pip install -e ".[dev]"
```

The second command may take a few minutes because it downloads SecureDep's
required components. Setup is complete when the text stops moving and there is
no red error message.

## Run Your First Scan

Make sure the PowerShell line still begins with `(.venv)`. Then copy and paste:

```powershell
securedep scan requests
```

This checks the well-known Python package named `requests`. SecureDep downloads
the package archive, reads it safely, and prints a risk report. It does not
install `requests` on your computer.

Near the end of the report, look for the risk result and the list of findings.
With the current provisional scoring rules, even a legitimate package such as
`requests` may receive a Medium result because it contains normal networking,
environment-reading, and test code. This is an example of a false positive,
not proof that `requests` is unsafe. Read the evidence before making a
decision.

For a more detailed report with the supporting evidence, run:

```powershell
securedep scan requests --verbose
```

## Scan Other Packages or Local Files

Use one of the examples below after setup is complete. Replace the package name
with the name you want to check.

### Check a Python package from PyPI

PyPI is the main public registry for Python packages.

```powershell
securedep scan package-name
```

Example:

```powershell
securedep scan flask
```

### Check a JavaScript package from npm

npm is the main public registry for JavaScript packages. You do not need npm
installed to scan an npm package with SecureDep.

```powershell
securedep scan package-name --ecosystem npm
```

Example:

```powershell
securedep scan cross-env --ecosystem npm
```

### Check one specific version

```powershell
securedep scan package-name --package-version 1.2.3
```

### Check a package archive or folder you already have

Use `--local` when the package is already saved on the computer. This does not
use the internet.

```powershell
securedep scan .\path\to\package-file.tar.gz --local --name package-name
```

Example using the project's sample location:

```powershell
securedep scan .\samples\suspicious.tar.gz --local --name suspicious
```

Only scan files you are permitted to handle. Never install or run an unknown
package just because you want to inspect it.

### Save or reuse a report

For a structured report that another program can read, run:

```powershell
securedep scan package-name --json
```

To see SecureDep's full catalogue of checks and their weights, run:

```powershell
securedep indicators
```

## Understand the Result

SecureDep combines multiple warning signs into a risk score. A result is a
signal to investigate, not proof that a package is safe or malicious.

| Result | What it means | What you should do |
|---|---|---|
| Low | Few or no concerning signs were found. | Continue normal review before installing the package. |
| Medium | Some warning signs were found. | Read the findings and check the package's source, publisher, and reputation. |
| High | Strong warning signs were found. | Do not install it until someone experienced has reviewed the evidence. |
| Critical | Multiple serious signs were found together. | Do not install or run it. Treat it as potentially unsafe and investigate in a controlled environment. |
| Error | SecureDep could not complete the scan. | Read the error text, check the troubleshooting section, and try again. |

SecureDep checks package details, installation scripts, code behaviour,
obfuscation, encoded content, and names that may imitate popular packages.

Important: the scanner's current score weights and risk thresholds are
**provisional**. They have not yet been calibrated using a labelled collection
of real malicious packages. Do not quote the result as a measured accuracy
percentage, and never treat a low-risk result as a guarantee of safety.

## Common Problems and Fixes

### `py` is not recognized

Python is not installed correctly, or PowerShell was opened before Python was
installed.

1. Close PowerShell.
2. Restart the computer, or install Python again from the official Python
   website.
3. During installation, make sure **Add Python to PATH** is selected.
4. Open a new PowerShell window and run `py --version` again.

If `py` still does not work but `python --version` does, replace `py` with
`python` in the setup commands. For example:

```powershell
python -m venv .venv
```

### PowerShell says running scripts is disabled

This can happen when you run the activation command. In the same PowerShell
window, run this command once:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then run the activation command again:

```powershell
.\.venv\Scripts\Activate.ps1
```

This change applies only to the PowerShell window you currently have open. It
does not permanently change the computer's security settings.

### `securedep` is not recognized

The private Python environment may not be active, or installation may not have
finished.

1. Confirm that `(.venv)` appears at the start of the PowerShell line.
2. If it does not, run:

```powershell
.\.venv\Scripts\Activate.ps1
```

3. Install SecureDep again:

```powershell
python -m pip install -e ".[dev]"
```

4. Try `securedep scan requests` again.

### A scan says it cannot connect or cannot find a package

Check that the computer is connected to the internet and that the package name
is correct. PyPI package names are scanned by default; add `--ecosystem npm`
for an npm package. Try again after a few minutes if the package registry is
temporarily unavailable.

### A local file says it does not exist

Check the file name and location. The easiest option is to move the archive
into the `secureDep` folder, then use a command such as:

```powershell
securedep scan .\my-package.tar.gz --local --name my-package
```

### You want to start over

Close PowerShell, open it again in the `secureDep` folder, and activate the
existing environment:

```powershell
.\.venv\Scripts\Activate.ps1
```

You do not need to repeat installation unless the project files have changed.

## Safe Use

- A low-risk result does not mean a package is guaranteed safe. Always check
  the package's publisher, source repository, update history, and purpose.
- Do not use `pip install` or `npm install` on a package merely to inspect it.
  Scan it with SecureDep first.
- Do not run unknown package files, installation scripts, or code samples.
- Real malware samples need extra care. Read [SAFETY.md](SAFETY.md) before
  handling them, keep them in `samples/`, and never add them to version control.

## Everyday Use

Each time you want to use SecureDep after the first setup:

1. Open PowerShell in the `secureDep` folder.
2. Activate SecureDep:

```powershell
.\.venv\Scripts\Activate.ps1
```

3. Run a scan:

```powershell
securedep scan package-name
```

4. When finished, close PowerShell or type the following command:

```powershell
deactivate
```

## Update SecureDep

If you receive an updated copy of the project, replace the old project folder
with the updated folder, then repeat the **Set Up SecureDep** section. This
ensures the scanner and its required components match the new project files.
