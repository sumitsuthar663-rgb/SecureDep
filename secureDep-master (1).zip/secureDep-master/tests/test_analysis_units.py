"""Unit tests for individual analysers.

These pin the behaviours that were wrong at some point during development, so
the regressions do not come back.
"""

from pathlib import Path

import pytest

from securedep.analysis.ast_python import analyse_python_source
from securedep.analysis.base import AnalysisContext, is_auxiliary
from securedep.analysis.deobfuscation import decode_chain
from securedep.analysis.obfuscation import looks_encoded, shannon_entropy, string_literals
from securedep.analysis.patterns import SENSITIVE_PATHS, classify_destination
from securedep.models import Ecosystem, ExtractedPackage, PackageRef


def _ctx(tmp_path: Path) -> AnalysisContext:
    return AnalysisContext(
        ExtractedPackage(
            ref=PackageRef(name="x", ecosystem=Ecosystem.PYPI),
            root=tmp_path,
        )
    )


def _analyse(tmp_path: Path, source: str, install_time: bool = False) -> AnalysisContext:
    ctx = _ctx(tmp_path)
    analyse_python_source(ctx, tmp_path / "mod.py", source, install_time=install_time)
    return ctx


# ---------------------------------------------------------------------------
# Import alias resolution
# ---------------------------------------------------------------------------


def test_dotted_import_resolves(tmp_path):
    """`import urllib.request` binds `urllib`, not `urllib.request`."""
    ctx = _analyse(tmp_path, "import urllib.request\nurllib.request.urlopen('http://x')\n")
    assert ctx.fired("network.outbound_request")


def test_aliased_import_resolves(tmp_path):
    ctx = _analyse(tmp_path, "import subprocess as sp\nsp.run(['ls'])\n")
    assert ctx.fired("exec.subprocess")


def test_from_import_resolves(tmp_path):
    ctx = _analyse(tmp_path, "from os import system\nsystem('ls')\n")
    assert ctx.fired("exec.subprocess")


def test_shell_true_detected(tmp_path):
    ctx = _analyse(tmp_path, "import subprocess\nsubprocess.run('ls', shell=True)\n")
    assert ctx.fired("exec.shell_true")


# ---------------------------------------------------------------------------
# Static string resolution
# ---------------------------------------------------------------------------


def test_split_string_does_not_hide_call(tmp_path):
    """Textual search is defeated by concatenation; the AST is not."""
    ctx = _analyse(tmp_path, "import os\ngetattr(os, 'sys' + 'tem')('ls')\n")
    assert ctx.fired("exec.subprocess")


def test_hoisted_constant_is_resolved(tmp_path):
    """`PAYLOAD = "..."` then `b64decode(PAYLOAD)` must still yield the literal.

    Reading only the decode call's arguments sees a bare Name and recovers
    nothing, which is exactly why hoisting is a common concealment pattern.
    """
    source = "import base64\nPAYLOAD = 'aW1wb3J0IG9z'\nbase64.b64decode(PAYLOAD)\n"
    ctx = _ctx(tmp_path)
    literals = analyse_python_source(ctx, tmp_path / "mod.py", source)

    assert ctx.fired("encoding.base64_decode")
    assert [value for _, value in literals] == ["aW1wb3J0IG9z"]


def test_docstrings_are_not_scanned_as_data(tmp_path):
    """Prose about cookies is not credential access."""
    source = '''
def get(response):
    """Extract the cookies from the response into a CookieJar."""
    return response
'''
    ctx = _analyse(tmp_path, source)
    assert not ctx.fired("credentials.sensitive_path")


def test_real_credential_path_still_detected(tmp_path):
    ctx = _analyse(tmp_path, "open('/home/u/.aws/credentials').read()\n")
    assert ctx.fired("credentials.sensitive_path")


# ---------------------------------------------------------------------------
# Pattern precision
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "text,expected",
    [
        ("~/.aws/credentials", True),
        ("~/.ssh/id_rsa", True),
        ("/home/u/.npmrc", True),
        ("Chrome/User Data/Default/Login Data", True),
        # Attribute access, not a filename.
        ("process.env['NODE_TLS_REJECT_UNAUTHORIZED']", False),
        ("os.environ.get('HOME')", False),
        ("the cookies returned by the server", False),
        ("credentials are validated upstream", False),
    ],
)
def test_sensitive_path_precision(text, expected):
    assert bool(SENSITIVE_PATHS.search(text)) is expected


def test_documentation_ips_are_not_flagged():
    """RFC 5737 ranges exist for examples and are not exfiltration targets."""
    assert classify_destination("http://198.51.100.44/c") == set()
    assert classify_destination("http://127.0.0.1:8080/") == set()
    assert classify_destination("http://45.83.12.9/beacon") == {"network.hardcoded_ip"}


def test_suspicious_hosts_detected():
    assert "network.suspicious_host" in classify_destination("https://webhook.site/abc")
    assert "network.suspicious_host" in classify_destination("https://pastebin.com/raw/x")
    assert classify_destination("https://api.github.com/repos") == set()


# ---------------------------------------------------------------------------
# Obfuscation heuristics
# ---------------------------------------------------------------------------


def test_entropy_ordering():
    assert shannon_entropy("aaaaaaaaaa") < shannon_entropy("hello world here")
    assert shannon_entropy("hello world here") < shannon_entropy("aW1wb3J0IG9zCnN5c3Rl")


def test_looks_encoded_accepts_base64():
    assert looks_encoded("aW1wb3J0IG9zLCB1cmxsaWIucmVxdWVzdApkYXRhID0gc3Ry")


def test_looks_encoded_rejects_prose_with_emoji():
    """Natural text scores high on entropy but is not encoded data."""
    assert not looks_encoded("the grinning face emoji is 😀 and it is fine")


def test_looks_encoded_rejects_charset_definitions():
    """A charset constant is maximally high-entropy but is not a payload."""
    charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-~"
    assert not looks_encoded(charset)


def test_string_literals_report_line_numbers():
    source = 'a = "one"\nb = "two"\nc = "three"\n'
    assert string_literals(source) == [(1, "one"), (2, "two"), (3, "three")]


# ---------------------------------------------------------------------------
# Deobfuscation
# ---------------------------------------------------------------------------


def test_decode_chain_handles_base64():
    import base64

    payload = "import os; os.system('id')"
    encoded = base64.b64encode(payload.encode()).decode()

    result = decode_chain(encoded)
    assert result is not None
    content, chain = result
    assert content == payload
    assert chain == ["base64"]


def test_decode_chain_handles_layered_encoding():
    import base64

    payload = "import os, urllib.request; urllib.request.urlopen('http://x')"
    once = base64.b64encode(payload.encode()).decode()
    twice = base64.b64encode(once.encode()).decode()

    result = decode_chain(twice)
    assert result is not None
    content, chain = result
    assert content == payload
    assert chain == ["base64", "base64"]


def test_decode_chain_ignores_plain_text():
    assert decode_chain("this is just a normal sentence in a docstring") is None


def test_decode_chain_ignores_binary_looking_output():
    """Something that decodes to non-printable bytes is not a hidden script."""
    assert decode_chain("////////////////////////") is None


# ---------------------------------------------------------------------------
# Auxiliary path classification
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "path,expected",
    [
        ("src/requests/api.py", False),
        ("setup.py", False),
        ("test/test_socks.py", True),
        ("tests/helpers.py", True),
        ("docs/conf.py", True),
        ("examples/demo.py", True),
        ("dummyserver/server.py", True),
        ("vendored-meson/meson/mdevenv.py", True),
        ("src/_vendor/urllib3/util.py", True),
        ("node_modules/foo/index.js", True),
        ("conftest.py", True),
        ("src/pkg/test_helpers.py", True),
    ],
)
def test_auxiliary_classification(path, expected):
    assert is_auxiliary(path) is expected
