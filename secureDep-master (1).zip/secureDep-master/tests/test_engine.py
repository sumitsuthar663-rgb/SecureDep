"""End-to-end engine behaviour over the synthetic fixtures.

The fixtures are described in tests/fixtures/README.md. They are written for
this test suite, are never executed, and contain no real malware.
"""

import pytest

from securedep.analysis.engine import scan_local
from securedep.models import Ecosystem, PackageRef, RiskBand


def _scan(fixtures, name, ecosystem, package_name=None):
    ref = PackageRef(name=package_name or name, ecosystem=ecosystem, version="1.0.0")
    return scan_local(fixtures / name, ref)


@pytest.fixture
def malicious_pypi(fixtures):
    return _scan(fixtures, "malicious_pypi", Ecosystem.PYPI, package_name="reqeusts")


@pytest.fixture
def benign_pypi(fixtures):
    return _scan(fixtures, "benign_pypi", Ecosystem.PYPI, package_name="tidy-slug")


@pytest.fixture
def malicious_npm(fixtures):
    return _scan(fixtures, "malicious_npm", Ecosystem.NPM, package_name="crossenv")


@pytest.fixture
def benign_npm(fixtures):
    return _scan(fixtures, "benign_npm", Ecosystem.NPM, package_name="kebab-title")


# ---------------------------------------------------------------------------
# Malicious PyPI fixture
# ---------------------------------------------------------------------------


def test_detects_setup_py_install_hook(malicious_pypi):
    result, _ = malicious_pypi
    assert result.has("install.hook_present")
    assert result.has("install.custom_command_class")


def test_detects_credential_and_network_behaviour(malicious_pypi):
    result, _ = malicious_pypi
    assert result.has("credentials.environment_read")
    assert result.has("credentials.sensitive_path")
    assert result.has("network.outbound_request")
    assert result.has("recon.system_fingerprint")


def test_detects_dynamic_execution_and_encoding(malicious_pypi):
    result, _ = malicious_pypi
    assert result.has("exec.dynamic_evaluation")
    assert result.has("encoding.base64_decode")


def test_deobfuscation_recovers_hidden_payload(malicious_pypi):
    result, _ = malicious_pypi
    assert result.has("obfuscation.decoded_payload_suspicious")

    finding = next(
        f for f in result.findings if f.indicator == "obfuscation.decoded_payload_suspicious"
    )
    assert "base64" in finding.context["chain"]

    # The behaviour inside the encoded blob must be attributed, not just noted.
    assert "network.outbound_request" in finding.context["triggered"]

    # And it must be marked as recovered rather than read from the source, so a
    # reader can tell the difference.
    decoded_evidence = [e for f in result.findings for e in f.evidence if e.decoded]
    assert decoded_evidence


def test_typosquatting_detected(malicious_pypi):
    result, _ = malicious_pypi
    assert result.has("typosquat.near_popular_name")
    finding = next(f for f in result.findings if f.indicator == "typosquat.near_popular_name")
    assert finding.context["imitates"] == "requests"


def test_combination_rules_fire(malicious_pypi):
    result, _ = malicious_pypi
    assert result.has("combo.install_exfiltration")
    assert result.has("combo.typosquat_with_payload")


def test_malicious_pypi_is_critical(malicious_pypi):
    result, _ = malicious_pypi
    assert result.band is RiskBand.CRITICAL


# ---------------------------------------------------------------------------
# Malicious npm fixture
# ---------------------------------------------------------------------------


def test_npm_postinstall_detected(malicious_npm):
    result, _ = malicious_npm
    assert result.has("install.hook_present")
    assert result.has("install.hook_runs_external_command")


def test_npm_behaviour_detected(malicious_npm):
    result, _ = malicious_npm
    assert result.has("credentials.environment_read")
    assert result.has("credentials.sensitive_path")
    assert result.has("network.suspicious_host")
    assert result.has("recon.system_fingerprint")
    assert result.has("persistence.startup_modification")
    assert result.has("exec.subprocess")


def test_npm_obfuscation_detected(malicious_npm):
    result, _ = malicious_npm
    assert result.has("obfuscation.charcode_array")


def test_npm_structural_typosquat(malicious_npm):
    """'crossenv' imitates 'cross-env' by dropping the separator."""
    result, _ = malicious_npm
    assert result.has("typosquat.structural_variation")

    finding = next(f for f in result.findings if f.indicator == "typosquat.structural_variation")
    assert finding.context["imitates"] == "cross-env"

    # One imitation must not be counted twice.
    assert not result.has("typosquat.near_popular_name")


def test_malicious_npm_is_critical(malicious_npm):
    result, _ = malicious_npm
    assert result.band is RiskBand.CRITICAL


# ---------------------------------------------------------------------------
# Benign fixtures - false positives are the thing to guard against
# ---------------------------------------------------------------------------


def test_benign_pypi_has_no_behavioural_indicators(benign_pypi):
    result, _ = benign_pypi
    behavioural = {
        i
        for i in result.indicators
        if not i.startswith(("metadata.", "typosquat.", "obfuscation.long"))
    }
    assert behavioural == set(), f"unexpected indicators: {behavioural}"


def test_benign_pypi_is_low_risk(benign_pypi):
    result, _ = benign_pypi
    assert result.band is RiskBand.LOW


def test_benign_npm_has_no_behavioural_indicators(benign_npm):
    result, _ = benign_npm
    behavioural = {
        i
        for i in result.indicators
        if not i.startswith(("metadata.", "typosquat.", "obfuscation.long"))
    }
    assert behavioural == set(), f"unexpected indicators: {behavioural}"


def test_benign_npm_is_low_risk(benign_npm):
    result, _ = benign_npm
    assert result.band is RiskBand.LOW


def test_benign_scores_far_below_malicious(benign_pypi, malicious_pypi):
    benign, _ = benign_pypi
    malicious, _ = malicious_pypi
    assert malicious.score > benign.score * 4


# ---------------------------------------------------------------------------
# Result plumbing
# ---------------------------------------------------------------------------


def test_every_finding_is_in_the_catalogue(malicious_pypi, malicious_npm):
    from securedep.scoring.indicators import ALL_IDS

    for result, _ in (malicious_pypi, malicious_npm):
        unknown = result.indicators - ALL_IDS
        assert unknown == set(), f"findings not in the catalogue: {unknown}"


def test_every_indicator_finding_carries_evidence(malicious_pypi):
    from securedep.scoring.indicators import COMBINATIONS

    combo_ids = {rule.id for rule in COMBINATIONS}
    result, _ = malicious_pypi
    for finding in result.findings:
        if finding.indicator in combo_ids:
            continue
        assert finding.evidence, f"{finding.indicator} fired without evidence"


def test_breakdown_sums_to_score(malicious_pypi):
    result, breakdown = malicious_pypi
    assert sum(b.contribution for b in breakdown) == pytest.approx(result.score)


def test_json_report_round_trips(malicious_pypi):
    import json

    from securedep.reporting import to_json

    result, breakdown = malicious_pypi
    payload = json.loads(to_json(result, breakdown))

    assert payload["package"]["name"] == "reqeusts"
    assert payload["verdict"]["band"] == "critical"
    assert payload["findings"]
    assert all("title" in f and "description" in f for f in payload["findings"])


def test_text_report_renders(malicious_pypi):
    from securedep.reporting import render_text

    result, breakdown = malicious_pypi
    text = render_text(result, breakdown, verbose=True)

    assert "CRITICAL" in text
    assert "install.hook_present" in text
    assert "Score breakdown" in text


def test_scan_is_deterministic(fixtures):
    """The same package must always produce the same verdict."""
    first, _ = _scan(fixtures, "malicious_pypi", Ecosystem.PYPI, package_name="reqeusts")
    second, _ = _scan(fixtures, "malicious_pypi", Ecosystem.PYPI, package_name="reqeusts")

    assert first.score == second.score
    assert first.indicators == second.indicators
