import pytest

from securedep.analysis.typosquatting import (
    are_adjacent,
    find_homoglyphs,
    levenshtein,
    normalise,
    structural_variants,
)
from securedep.models import Ecosystem


@pytest.mark.parametrize(
    "a,b,expected",
    [
        ("requests", "requests", 0),
        ("reqeusts", "requests", 2),
        ("request", "requests", 1),
        ("urllib3", "urllib3", 0),
        ("", "abc", 3),
        ("abc", "", 3),
        ("kitten", "sitting", 3),
    ],
)
def test_levenshtein(a, b, expected):
    assert levenshtein(a, b) == expected


def test_levenshtein_early_exit_reports_over_budget():
    # Beyond the budget the exact distance is not computed - only that it is
    # greater than the caller cares about.
    assert levenshtein("abcdefgh", "zyxwvuts", max_distance=2) == 3
    assert levenshtein("requests", "reqeusts", max_distance=2) == 2


def test_levenshtein_length_shortcut():
    assert levenshtein("ab", "abcdefghij", max_distance=2) == 3


def test_keyboard_adjacency():
    assert are_adjacent("e", "r")
    assert are_adjacent("a", "s")
    assert not are_adjacent("q", "p")


def test_pypi_normalisation_follows_pep503():
    assert normalise("Python_Dateutil", Ecosystem.PYPI) == "python-dateutil"
    assert normalise("zope.interface", Ecosystem.PYPI) == "zope-interface"


def test_npm_scope_is_stripped():
    assert normalise("@babel/core", Ecosystem.NPM) == "core"


def test_structural_variants():
    assert "cross-env" in structural_variants("cross-env-js")
    assert "dateutil" in structural_variants("python-dateutil")
    assert "crossenv" in structural_variants("cross-env")


def test_digit_letter_substitution():
    assert "lodash" in structural_variants("l0dash")


def test_homoglyph_detection():
    # Cyrillic 'а' (U+0430) renders identically to ASCII 'a'.
    found = find_homoglyphs("pаndas")
    assert found == [("а", "a")]
    assert find_homoglyphs("pandas") == []
