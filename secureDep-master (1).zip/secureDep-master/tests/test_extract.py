"""Extraction safety tests.

Extracting an attacker-controlled archive is the one place where the scanner
itself can be exploited, so these are the tests that matter most.
"""

import io
import tarfile
import zipfile

import pytest

from securedep.acquisition.extract import UnsafeArchiveError, extract, extract_tar, extract_zip


def _tar_with(tmp_path, entries, links=()):
    archive = tmp_path / "payload.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        for name, content in entries:
            data = content.encode()
            info = tarfile.TarInfo(name=name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        for name, target, kind in links:
            info = tarfile.TarInfo(name=name)
            info.type = tarfile.SYMTYPE if kind == "sym" else tarfile.LNKTYPE
            info.linkname = target
            tar.addfile(info)
    return archive


def test_rejects_relative_traversal(tmp_path):
    archive = _tar_with(tmp_path, [("../../escaped.txt", "owned"), ("safe.txt", "ok")])
    destination = tmp_path / "out"

    report = extract_tar(archive, destination)

    assert not (tmp_path.parent / "escaped.txt").exists()
    assert (destination / "safe.txt").read_text() == "ok"
    assert report.had_traversal_attempt
    assert ("../../escaped.txt", "path traversal") in report.skipped


def test_rejects_absolute_paths(tmp_path):
    archive = _tar_with(tmp_path, [("/etc/passwd", "owned")])

    report = extract_tar(archive, tmp_path / "out")

    assert report.extracted == 0
    assert report.had_traversal_attempt
    assert ("/etc/passwd", "absolute path") in report.skipped


def test_skips_symlinks_and_hardlinks(tmp_path):
    archive = _tar_with(
        tmp_path,
        [("real.txt", "data")],
        links=[("link.txt", "/etc/passwd", "sym"), ("hard.txt", "real.txt", "hard")],
    )

    report = extract_tar(archive, tmp_path / "out")

    assert report.extracted == 1
    assert not (tmp_path / "out" / "link.txt").exists()
    assert {r for _, r in report.skipped} == {"link entry"}


def test_rejects_nested_traversal(tmp_path):
    """A traversal that only escapes partway through the path."""
    archive = _tar_with(tmp_path, [("pkg/../../outside.txt", "owned")])

    report = extract_tar(archive, tmp_path / "out")

    assert report.had_traversal_attempt
    assert not (tmp_path / "outside.txt").exists()


def test_enforces_entry_limit(tmp_path):
    import securedep.acquisition.extract as extract_module

    archive = _tar_with(tmp_path, [(f"f{i}.txt", "x") for i in range(50)])
    original = extract_module.MAX_ENTRIES
    extract_module.MAX_ENTRIES = 10
    try:
        with pytest.raises(UnsafeArchiveError, match="entries"):
            extract_tar(archive, tmp_path / "out")
    finally:
        extract_module.MAX_ENTRIES = original


def test_enforces_total_size_limit(tmp_path):
    import securedep.acquisition.extract as extract_module

    archive = _tar_with(tmp_path, [("big.txt", "x" * 5000)])
    original = extract_module.MAX_TOTAL_BYTES
    extract_module.MAX_TOTAL_BYTES = 1000
    try:
        with pytest.raises(UnsafeArchiveError, match="size limit"):
            extract_tar(archive, tmp_path / "out")
    finally:
        extract_module.MAX_TOTAL_BYTES = original


def test_zip_traversal_rejected(tmp_path):
    archive = tmp_path / "payload.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("../../escaped.txt", "owned")
        zf.writestr("safe.txt", "ok")

    report = extract_zip(archive, tmp_path / "out")

    assert report.had_traversal_attempt
    assert (tmp_path / "out" / "safe.txt").read_text() == "ok"


def test_zip_symlink_rejected(tmp_path):
    archive = tmp_path / "payload.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        info = zipfile.ZipInfo("link.txt")
        info.external_attr = (0xA1FF) << 16  # symlink mode bits
        zf.writestr(info, "/etc/passwd")

    report = extract_zip(archive, tmp_path / "out")

    assert report.extracted == 0
    assert ("link.txt", "link entry") in report.skipped


def test_extract_dispatches_by_content(tmp_path):
    tar_archive = _tar_with(tmp_path, [("a.txt", "1")])
    zip_archive = tmp_path / "b.zip"
    with zipfile.ZipFile(zip_archive, "w") as zf:
        zf.writestr("b.txt", "2")

    assert extract(tar_archive, tmp_path / "t").extracted == 1
    assert extract(zip_archive, tmp_path / "z").extracted == 1


def test_rejects_unknown_format(tmp_path):
    bogus = tmp_path / "not-an-archive.bin"
    bogus.write_bytes(b"\x00\x01\x02not an archive")

    with pytest.raises(UnsafeArchiveError, match="not a recognised"):
        extract(bogus, tmp_path / "out")


def test_extracted_files_are_not_executable(tmp_path):
    """An executable bit from an untrusted archive has no legitimate purpose."""
    archive = tmp_path / "payload.tar"
    with tarfile.open(archive, "w") as tar:
        data = b"#!/bin/sh\necho hi\n"
        info = tarfile.TarInfo(name="run.sh")
        info.size = len(data)
        info.mode = 0o777
        tar.addfile(info, io.BytesIO(data))

    extract_tar(archive, tmp_path / "out")

    mode = (tmp_path / "out" / "run.sh").stat().st_mode
    assert not mode & 0o111
