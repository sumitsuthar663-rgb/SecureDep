# Test fixtures

These are **synthetic packages written for this project's test suite**. They
are not real malware and were never published to any registry.

`malicious_pypi/` and `malicious_npm/` imitate the *structure* of a
credential-stealing package - an install hook that reads secrets and posts them
to a remote host, with an obfuscated payload - so that the analysers can be
tested without keeping live samples in version control.

They are inert:

* the "exfiltration" endpoints are RFC 2606 reserved domains that resolve
  nowhere (`example.com`) or documentation-range addresses,
* nothing in the test suite executes them - the analysers only read the files.

Real malicious samples belong in `samples/`, which is gitignored. See
`docs/SAFETY.md`.
