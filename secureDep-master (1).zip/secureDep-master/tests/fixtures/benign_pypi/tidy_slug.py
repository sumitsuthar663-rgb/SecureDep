"""Turn arbitrary text into URL-safe slugs.

Deliberately ordinary code: it reads no secrets, opens no sockets and runs
nothing at install time. Used to check the engine does not flag normal work.
"""

import re
import unicodedata

_NON_WORD = re.compile(r"[^\w\s-]")
_WHITESPACE = re.compile(r"[-\s]+")

DEFAULT_MAX_LENGTH = 80


def slugify(text, max_length=DEFAULT_MAX_LENGTH, separator="-"):
    """Return a lowercase, URL-safe form of ``text``."""
    normalised = unicodedata.normalize("NFKD", str(text))
    ascii_only = normalised.encode("ascii", "ignore").decode("ascii")
    cleaned = _NON_WORD.sub("", ascii_only).strip().lower()
    slug = _WHITESPACE.sub(separator, cleaned)

    if max_length and len(slug) > max_length:
        slug = slug[:max_length].rsplit(separator, 1)[0]

    return slug


def is_slug(value):
    """True if ``value`` is already a well-formed slug."""
    return bool(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", value or ""))


def unique_slug(text, existing, max_length=DEFAULT_MAX_LENGTH):
    """Append a numeric suffix until the slug is not already in ``existing``."""
    base = slugify(text, max_length=max_length)
    if base not in existing:
        return base

    for suffix in range(2, 1000):
        candidate = f"{base}-{suffix}"
        if candidate not in existing:
            return candidate

    raise ValueError("could not generate a unique slug")
