from setuptools import find_packages, setup

setup(
    name="tidy-slug",
    version="1.4.2",
    description="Turn arbitrary text into URL-safe slugs",
    author="A Maintainer",
    url="https://github.com/example/tidy-slug",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
