// Ordinary library code: no install hook, no network, no secrets.
// Used to check the engine does not flag normal work.

'use strict';

const SEPARATOR = '-';

function toTitleCase(input) {
  return String(input)
    .split(SEPARATOR)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

function toKebabCase(input) {
  return String(input)
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, SEPARATOR)
    .replace(/^-+|-+$/g, '');
}

function isKebabCase(value) {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value || '');
}

module.exports = { toTitleCase, toKebabCase, isKebabCase };
