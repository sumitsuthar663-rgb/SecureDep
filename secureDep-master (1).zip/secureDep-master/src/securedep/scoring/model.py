"""Weighted risk scoring (section 7.8).

The score is a plain weighted sum over triggered indicators, plus a bonus for
each satisfied combination rule. It is deliberately simple and fully traceable:
every point in the final score can be attributed to a named indicator, which is
the stated reason for choosing a rule-based model over a classifier.
"""

from __future__ import annotations

from dataclasses import dataclass

from securedep.models import Finding, RiskBand, ScanResult
from securedep.scoring.indicators import COMBINATIONS, INDICATORS

#: Score at which a package enters each band.
#:
#: CALIBRATION STATUS: benign-only. These are set from the measured score
#: distribution of 120 randomly sampled popular PyPI packages (see
#: docs/CALIBRATION.md), choosing each band at a percentile of that
#: distribution:
#:
#:     MEDIUM   13.0  ~ benign p80   (20% of benign packages reach it)
#:     HIGH     22.5  ~ benign p95   ( 5% of benign packages reach it)
#:     CRITICAL 32.5  ~ benign p99   ( 1% of benign packages reach it)
#:
#: This bounds the false positive rate but says NOTHING about recall, because
#: no malicious samples were available when it was measured. Phase 5 must
#: re-run `scripts/evaluate.py run` with the Backstabber's corpus included and
#: choose thresholds from the full precision/recall trade-off. Until then these
#: are a principled starting point, not a result - do not quote them as tuned.
THRESHOLDS: dict[RiskBand, float] = {
    RiskBand.CRITICAL: 32.5,
    RiskBand.HIGH: 22.5,
    RiskBand.MEDIUM: 13.0,
    RiskBand.LOW: 0.0,
}

#: Repeated evidence for the same indicator increases confidence, but with
#: sharply diminishing returns - twenty eval() calls are not twenty times more
#: suspicious than one. Capped multiplier applied per indicator.
MAX_EVIDENCE_MULTIPLIER = 1.5

#: Weight retained by an indicator whose evidence comes only from test,
#: documentation or example files. Such code is shipped in the archive but is
#: not what runs when the package is used, and it legitimately does things -
#: opening sockets, spawning processes, hardcoding addresses - that would be
#: suspicious in library code. It is reduced rather than discarded because
#: malicious payloads are sometimes placed in test directories precisely
#: because reviewers skim them.
AUXILIARY_WEIGHT_FACTOR = 0.25

#: Ceiling on the combined contribution of every `contextual` indicator.
#:
#: Contextual indicators are defined as ones that are common in benign packages
#: and only meaningful in combination. Without a ceiling they defeat their own
#: definition: a large legitimate package accumulates one of nearly everything -
#: it reads the environment, reports its platform, opens a connection, has no
#: licence field - and the sum alone reaches a high band. Capping them means a
#: serious verdict has to come from a strong indicator or a combination rule,
#: which is the behaviour the scoring model is supposed to have.
MAX_CONTEXTUAL_CONTRIBUTION = 4.0


@dataclass
class ScoreBreakdown:
    """Per-indicator contribution, so a report can show the arithmetic."""

    indicator: str
    title: str
    weight: float
    evidence_count: int
    contribution: float
    #: "runtime", "mixed", "auxiliary", or "" for combination bonuses.
    scope: str = ""


def is_auxiliary_only(finding: Finding) -> bool:
    return finding.context.get("evidence_scope") == "auxiliary"


def runtime_indicators(findings: list[Finding]) -> set[str]:
    """Indicators backed by at least one finding in the package's real code.

    Combination rules match against this set rather than every fired
    indicator, so a test suite that opens a socket cannot combine with a
    docstring mentioning credentials to manufacture a critical verdict.
    """
    return {f.indicator for f in findings if not is_auxiliary_only(f)}


def install_time_indicators(findings: list[Finding]) -> set[str]:
    """Indicators backed by evidence in code that runs at install time."""
    return {
        f.indicator for f in findings if f.context.get("install_time") and not is_auxiliary_only(f)
    }


def _files_of(finding: Finding) -> set[str]:
    # Decoded evidence is labelled "<path> [decoded: ...]"; attribute it back to
    # the file the payload was hidden in.
    return {e.path.split(" [decoded", 1)[0] for e in finding.evidence}


def indicators_by_file(findings: list[Finding]) -> dict[str, set[str]]:
    """Which indicators fired in each file."""
    per_file: dict[str, set[str]] = {}
    for finding in findings:
        if is_auxiliary_only(finding):
            continue
        for path in _files_of(finding):
            per_file.setdefault(path, set()).add(finding.indicator)
    return per_file


def combination_matches(rule, findings: list[Finding]) -> set[str] | None:
    """Check a rule at its declared scope.

    Returns the indicators that justified it, or None if it does not apply.
    """
    package_level = runtime_indicators(findings)
    if not rule.matches(package_level):
        return None

    if rule.scope == "package":
        return rule.satisfied_by(package_level)

    if rule.scope == "install":
        install_level = install_time_indicators(findings)
        # Install-hook indicators describe the hook itself; they are inherently
        # install-time even though they are reported against the manifest.
        install_level |= {i for i in package_level if i.startswith("install.")}
        return rule.satisfied_by(install_level) if rule.matches(install_level) else None

    if rule.scope == "file":
        for indicators in indicators_by_file(findings).values():
            if rule.matches(indicators):
                return rule.satisfied_by(indicators)
        return None

    raise ValueError(f"unknown combination scope {rule.scope!r} on {rule.id}")


def _evidence_multiplier(count: int) -> float:
    if count <= 1:
        return 1.0
    # 2 hits -> 1.17, 5 -> 1.35, 20+ -> capped at 1.5
    import math

    return min(MAX_EVIDENCE_MULTIPLIER, 1.0 + math.log(count, 10) / 4)


def score_findings(findings: list[Finding]) -> tuple[float, list[ScoreBreakdown]]:
    total = 0.0
    contextual_total = 0.0
    breakdown: list[ScoreBreakdown] = []

    for finding in findings:
        s = INDICATORS.get(finding.indicator)
        if s is None:
            # A combination finding, or an indicator that is not in the
            # catalogue. Combinations are scored separately below.
            continue
        multiplier = _evidence_multiplier(len(finding.evidence))
        scope = finding.context.get("evidence_scope", "")
        if scope == "auxiliary":
            multiplier *= AUXILIARY_WEIGHT_FACTOR

        contribution = s.weight * multiplier

        if s.contextual:
            headroom = max(0.0, MAX_CONTEXTUAL_CONTRIBUTION - contextual_total)
            contribution = min(contribution, headroom)
            contextual_total += contribution

        total += contribution
        breakdown.append(
            ScoreBreakdown(
                indicator=s.id,
                title=s.title,
                weight=s.weight,
                evidence_count=len(finding.evidence),
                contribution=contribution,
                scope=scope,
            )
        )

    return total, breakdown


def apply_combinations(result: ScanResult) -> tuple[float, list[ScoreBreakdown]]:
    """Add combination bonuses and record them as findings on the result."""
    total = 0.0
    breakdown: list[ScoreBreakdown] = []

    for rule in COMBINATIONS:
        justification = combination_matches(rule, result.findings)
        if justification is None:
            continue

        total += rule.bonus
        breakdown.append(
            ScoreBreakdown(
                indicator=rule.id,
                title=rule.title,
                weight=rule.bonus,
                evidence_count=0,
                contribution=rule.bonus,
            )
        )
        result.findings.append(
            Finding(
                indicator=rule.id,
                context={
                    "kind": "combination",
                    "title": rule.title,
                    "description": rule.description,
                    "scope": rule.scope,
                    "triggered_by": sorted(justification),
                },
            )
        )

    return total, breakdown


def band_for(score: float) -> RiskBand:
    for band in (RiskBand.CRITICAL, RiskBand.HIGH, RiskBand.MEDIUM):
        if score >= THRESHOLDS[band]:
            return band
    return RiskBand.LOW


def finalise(result: ScanResult) -> list[ScoreBreakdown]:
    """Score a result in place. Returns the full breakdown for reporting."""
    base, breakdown = score_findings(result.findings)
    bonus, combo_breakdown = apply_combinations(result)

    result.score = base + bonus
    result.band = band_for(result.score)

    full = breakdown + combo_breakdown
    full.sort(key=lambda b: b.contribution, reverse=True)
    return full
