"""The indicator catalogue: every signal the engine can raise, in one place.

Weights are declared here and nowhere else. Phase 5 of the implementation plan
tunes them against the labelled dataset by editing this file only - measuring
per-indicator discriminative power and setting `weight` from the result rather
than from intuition (section 7.8).

Until that measurement has been done, every weight below is a documented
STARTING ESTIMATE, not a result. Do not present these numbers as derived.
"""

from __future__ import annotations

from dataclasses import dataclass

from securedep.models import Category


@dataclass(frozen=True)
class IndicatorSpec:
    id: str
    category: Category
    title: str
    description: str
    #: Contribution to the cumulative risk score when this indicator fires.
    weight: float
    #: Set for indicators that are common in benign packages and are only
    #: meaningful in combination. They are still reported, but contribute
    #: little on their own.
    contextual: bool = False


@dataclass(frozen=True)
class ComboRule:
    """An additional weight applied when a set of behaviours co-occur.

    This is the intellectual core of the project (section 7.4): individual
    operations are usually harmless, but specific combinations are not. A
    package that reads environment variables is normal. A package that reads
    environment variables *and* sends them over the network *from an install
    hook* is stealing credentials.

    SCOPE is what makes the rule mean anything. "Co-occur" cannot mean "both
    appear somewhere in the archive": setuptools contains a setup.py and, in an
    unrelated module, code that reads the environment and opens a connection.
    Matching those against each other reported setuptools as critical. A
    combination is only evidence when the behaviours are actually connected -
    running in the same install hook, or written in the same file.
    """

    id: str
    title: str
    description: str
    requires: frozenset[str]
    bonus: float
    #: Optional - any one of these must also be present.
    requires_any: frozenset[str] = frozenset()
    #: "install" - every required behaviour must occur in code that runs at
    #:             install time
    #: "file"    - every required behaviour must occur in one single file
    #: "package" - anywhere in the package (use only for package-level facts
    #:             such as the package's name)
    scope: str = "install"

    def matches(self, fired: set[str]) -> bool:
        if not self.requires <= fired:
            return False
        if self.requires_any and not (self.requires_any & fired):
            return False
        return True

    def satisfied_by(self, fired: set[str]) -> set[str]:
        """The indicators that actually justified this rule."""
        return self.requires | (self.requires_any & fired)


def _spec(*args, **kwargs) -> tuple[str, IndicatorSpec]:
    s = IndicatorSpec(*args, **kwargs)
    return s.id, s


INDICATORS: dict[str, IndicatorSpec] = dict(
    [
        # ---------------------------------------------------------------
        # Metadata (7.2)
        # ---------------------------------------------------------------
        _spec(
            "metadata.no_repository",
            Category.METADATA,
            "No source repository declared",
            "The package declares no repository or homepage URL, so its source "
            "cannot be independently inspected.",
            weight=1.0,
            contextual=True,
        ),
        _spec(
            "metadata.single_version",
            Category.METADATA,
            "Only one published version",
            "The package has exactly one release. Malicious packages are "
            "typically published once and removed shortly afterwards.",
            weight=1.0,
            contextual=True,
        ),
        _spec(
            "metadata.recently_published",
            Category.METADATA,
            "Published very recently",
            "First publication was within the last 30 days.",
            weight=1.0,
            contextual=True,
        ),
        _spec(
            "metadata.no_license",
            Category.METADATA,
            "No licence declared",
            "Legitimate packages almost always declare a licence.",
            weight=0.5,
            contextual=True,
        ),
        _spec(
            "metadata.trivial_codebase",
            Category.METADATA,
            "Almost no real functionality",
            "The package contains very little code relative to what it claims "
            "to provide - common in packages that exist only to carry a payload.",
            weight=2.0,
        ),
        _spec(
            "archive.path_traversal",
            Category.METADATA,
            "Archive tries to write outside its own directory",
            "The package archive contains entries with traversal or absolute "
            "paths, which would overwrite files elsewhere on the system during "
            "extraction. There is no benign reason for this.",
            weight=8.0,
        ),
        # ---------------------------------------------------------------
        # Install hooks (7.3) - the strongest single indicator
        # ---------------------------------------------------------------
        _spec(
            "install.hook_present",
            Category.INSTALL_HOOK,
            "Code runs automatically at install time",
            "The package defines an installation hook (npm pre/post/install "
            "scripts, or executable logic in setup.py) that runs with the "
            "developer's own permissions the moment the package is installed.",
            weight=4.0,
        ),
        _spec(
            "install.hook_runs_external_command",
            Category.INSTALL_HOOK,
            "Install hook shells out to another command",
            "The install hook invokes an external interpreter or shell command "
            "rather than performing a build step in-process.",
            weight=3.0,
        ),
        _spec(
            "install.custom_command_class",
            Category.INSTALL_HOOK,
            "setup.py overrides install behaviour",
            "A custom setuptools command class overrides install/develop/"
            "egg_info to run attacker-controlled code during installation.",
            weight=4.0,
        ),
        # ---------------------------------------------------------------
        # AST behaviours (7.4)
        # ---------------------------------------------------------------
        _spec(
            "exec.dynamic_evaluation",
            Category.DYNAMIC_EXECUTION,
            "Evaluates code built at runtime",
            "Uses eval/exec/Function/compile to run code that is constructed "
            "while the program is running, so the real behaviour is not visible "
            "in the source.",
            weight=3.0,
        ),
        _spec(
            "exec.subprocess",
            Category.DYNAMIC_EXECUTION,
            "Spawns operating system processes",
            "Runs external commands via subprocess/os.system/child_process.",
            weight=2.0,
        ),
        _spec(
            "exec.shell_true",
            Category.DYNAMIC_EXECUTION,
            "Runs a command through the shell",
            "Executes a command string through a shell, which allows chaining "
            "and redirection and is rarely necessary in library code.",
            weight=2.0,
        ),
        _spec(
            "network.outbound_request",
            Category.NETWORK,
            "Makes outbound network requests",
            "Contains code that sends data to a remote host.",
            weight=1.5,
            contextual=True,
        ),
        _spec(
            "network.hardcoded_ip",
            Category.NETWORK,
            "Connects to a hardcoded IP address",
            "A literal IP address appears as a network destination. Legitimate "
            "packages address services by domain name.",
            weight=3.0,
        ),
        _spec(
            "network.suspicious_host",
            Category.NETWORK,
            "Contacts a request-capture or paste service",
            "The destination is a known exfiltration-friendly service such as a "
            "request bin, paste site, webhook catcher or dynamic-DNS host.",
            weight=4.0,
        ),
        _spec(
            "network.raw_socket",
            Category.NETWORK,
            "Opens a raw network socket",
            "Uses low-level socket APIs rather than an HTTP client.",
            weight=2.0,
        ),
        _spec(
            "credentials.environment_read",
            Category.CREDENTIAL_ACCESS,
            "Reads environment variables",
            "Reads the process environment, which commonly holds API keys, "
            "tokens and cloud credentials.",
            weight=1.0,
            contextual=True,
        ),
        _spec(
            "credentials.sensitive_path",
            Category.CREDENTIAL_ACCESS,
            "Reads credential files or wallets",
            "Accesses paths that hold secrets - ~/.aws, ~/.ssh, .npmrc, .env, "
            "browser profiles, or cryptocurrency wallet directories.",
            weight=4.0,
        ),
        _spec(
            "credentials.keychain_access",
            Category.CREDENTIAL_ACCESS,
            "Queries an OS credential store",
            "Reads the system keychain, credential manager or secret service.",
            weight=4.0,
        ),
        _spec(
            "recon.system_fingerprint",
            Category.RECONNAISSANCE,
            "Collects system and user identity",
            "Gathers hostname, username, operating system details, working "
            "directory or network configuration.",
            weight=1.5,
            contextual=True,
        ),
        _spec(
            "persistence.startup_modification",
            Category.PERSISTENCE,
            "Modifies startup or scheduled execution",
            "Writes to shell startup files, cron, scheduled tasks, systemd "
            "units or registry run keys so code survives a reboot.",
            weight=4.0,
        ),
        _spec(
            "persistence.file_write_outside_package",
            Category.PERSISTENCE,
            "Writes files outside its own directory",
            "Creates or modifies files elsewhere on the filesystem.",
            weight=2.0,
        ),
        _spec(
            "encoding.base64_decode",
            Category.ENCODING,
            "Decodes base64 data",
            "Decodes base64 content at runtime, commonly used to hide a payload "
            "from casual inspection.",
            weight=2.0,
        ),
        _spec(
            "encoding.hex_or_charcode",
            Category.ENCODING,
            "Reconstructs strings from character codes",
            "Builds strings from hexadecimal escapes or numeric character "
            "codes instead of writing them literally.",
            weight=2.0,
        ),
        # ---------------------------------------------------------------
        # Obfuscation (7.5)
        # ---------------------------------------------------------------
        _spec(
            "obfuscation.high_entropy_string",
            Category.OBFUSCATION,
            "Contains high-entropy string literals",
            "String literals whose character distribution approaches random "
            "data, indicating encoded or encrypted content.",
            weight=2.5,
        ),
        _spec(
            "obfuscation.long_single_line",
            Category.OBFUSCATION,
            "Contains very long single lines",
            "Extremely long lines, characteristic of minified or generated "
            "code being used to hide logic.",
            weight=1.0,
            contextual=True,
        ),
        _spec(
            "obfuscation.meaningless_identifiers",
            Category.OBFUSCATION,
            "Uses meaningless identifier names",
            "A high proportion of identifiers are non-words such as _0x4f2a.",
            weight=2.0,
        ),
        _spec(
            "obfuscation.charcode_array",
            Category.OBFUSCATION,
            "Contains large arrays of character codes",
            "A long numeric array that decodes to text.",
            weight=2.5,
        ),
        _spec(
            "obfuscation.decoded_payload_suspicious",
            Category.OBFUSCATION,
            "Hidden payload is itself suspicious",
            "Content recovered by the deobfuscation module triggered further "
            "behavioural indicators on a second analysis pass.",
            weight=5.0,
        ),
        # ---------------------------------------------------------------
        # Typosquatting (7.7)
        # ---------------------------------------------------------------
        _spec(
            "typosquat.near_popular_name",
            Category.TYPOSQUATTING,
            "Name is one or two edits from a popular package",
            "The package name is a very small edit distance from a widely used "
            "package, consistent with targeting typing mistakes.",
            weight=4.0,
        ),
        _spec(
            "typosquat.keyboard_adjacent",
            Category.TYPOSQUATTING,
            "Differs by an adjacent-key substitution",
            "The differing character is physically adjacent on a QWERTY "
            "keyboard, which is how genuine typing errors occur.",
            weight=1.5,
        ),
        _spec(
            "typosquat.structural_variation",
            Category.TYPOSQUATTING,
            "Structural variation of a popular name",
            "Differs from a popular package only by hyphen/underscore "
            "substitution or an added prefix or suffix such as -js or python-.",
            weight=3.0,
        ),
        _spec(
            "typosquat.homoglyph",
            Category.TYPOSQUATTING,
            "Contains look-alike Unicode characters",
            "Uses characters that are visually identical to ASCII letters but "
            "drawn from a different Unicode range.",
            weight=5.0,
        ),
    ]
)


COMBINATIONS: list[ComboRule] = [
    ComboRule(
        id="combo.install_exfiltration",
        title="Install hook exfiltrates local secrets",
        description=(
            "The package reads credentials or environment data and sends it to "
            "a remote host, from code that runs automatically at install time. "
            "This is the canonical credential-stealing supply chain payload."
        ),
        requires=frozenset({"install.hook_present", "network.outbound_request"}),
        requires_any=frozenset(
            {
                "credentials.environment_read",
                "credentials.sensitive_path",
                "credentials.keychain_access",
                "recon.system_fingerprint",
            }
        ),
        bonus=8.0,
        scope="install",
    ),
    ComboRule(
        id="combo.install_dynamic_exec",
        title="Install hook evaluates code built at runtime",
        description=(
            "Code that runs at install time constructs and evaluates further "
            "code, so what actually executes on the developer's machine is not "
            "present in the published source."
        ),
        requires=frozenset({"install.hook_present", "exec.dynamic_evaluation"}),
        bonus=6.0,
        scope="install",
    ),
    ComboRule(
        id="combo.encoded_payload_executed",
        title="Encoded content is decoded and then executed",
        description=(
            "The package decodes hidden data and passes the result to an "
            "evaluation or process-execution call. There is no legitimate "
            "reason for a library to do this."
        ),
        requires=frozenset({"exec.dynamic_evaluation"}),
        requires_any=frozenset({"encoding.base64_decode", "encoding.hex_or_charcode"}),
        bonus=6.0,
        # Anchored to install time. Decoding and evaluating in the same file is
        # not by itself proof of anything: PyYAML's constructor decodes !!binary
        # and evaluates Python object tags in one module, which is its documented
        # (if dangerous) purpose. Proving the decoded value actually reaches the
        # eval would need dataflow analysis, which is out of scope; requiring it
        # to happen during installation is the sound approximation.
        # The runtime case is covered by obfuscation.decoded_payload_suspicious,
        # which fires only when the recovered payload is itself suspicious.
        scope="install",
    ),
    ComboRule(
        id="combo.recon_exfiltration",
        title="System fingerprint sent to a remote host",
        description=(
            "The package collects identifying details about the machine and "
            "transmits them, which is beaconing behaviour rather than library "
            "functionality."
        ),
        requires=frozenset({"recon.system_fingerprint", "network.outbound_request"}),
        bonus=4.0,
        # Every HTTP client fingerprints the platform to build a User-Agent.
        # It is only beaconing when it happens as a side effect of installing.
        scope="install",
    ),
    ComboRule(
        id="combo.typosquat_with_payload",
        title="Look-alike name combined with active behaviour",
        description=(
            "The package imitates the name of a popular package and also "
            "executes code at install time - impersonation plus a payload."
        ),
        requires=frozenset({"install.hook_present"}),
        requires_any=frozenset(
            {
                "typosquat.near_popular_name",
                "typosquat.structural_variation",
                "typosquat.homoglyph",
            }
        ),
        bonus=6.0,
        # The name is a property of the package, not of any one file.
        scope="package",
    ),
    ComboRule(
        id="combo.obfuscated_and_networked",
        title="Obfuscated code that contacts the network",
        description=(
            "The package hides its logic and also communicates with a remote "
            "host. Concealment plus connectivity is a strong pairing."
        ),
        requires=frozenset({"network.outbound_request"}),
        requires_any=frozenset(
            {
                "obfuscation.high_entropy_string",
                "obfuscation.charcode_array",
                "obfuscation.meaningless_identifiers",
            }
        ),
        bonus=4.0,
        scope="file",
    ),
    ComboRule(
        id="combo.persistence_installed",
        title="Install hook establishes persistence",
        description=(
            "Installing the package causes code to be registered for automatic "
            "execution later, surviving beyond the install itself."
        ),
        requires=frozenset({"install.hook_present", "persistence.startup_modification"}),
        bonus=8.0,
        scope="install",
    ),
]


def spec(indicator_id: str) -> IndicatorSpec:
    try:
        return INDICATORS[indicator_id]
    except KeyError:
        raise KeyError(f"unknown indicator {indicator_id!r}") from None


def combo(combo_id: str) -> ComboRule:
    for rule in COMBINATIONS:
        if rule.id == combo_id:
            return rule
    raise KeyError(f"unknown combination rule {combo_id!r}")


#: Every id the engine can emit, for validation in tests.
ALL_IDS: frozenset[str] = frozenset(INDICATORS) | frozenset(r.id for r in COMBINATIONS)
