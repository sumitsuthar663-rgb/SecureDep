"""Risk scoring (section 7.8).

``indicators`` holds the catalogue and every weight in the system.
``model`` turns a set of findings into a score and a risk band.
"""

from securedep.scoring.indicators import ALL_IDS, COMBINATIONS, INDICATORS, ComboRule, IndicatorSpec
from securedep.scoring.model import THRESHOLDS, ScoreBreakdown, band_for, finalise

__all__ = [
    "ALL_IDS",
    "COMBINATIONS",
    "INDICATORS",
    "THRESHOLDS",
    "ComboRule",
    "IndicatorSpec",
    "ScoreBreakdown",
    "band_for",
    "finalise",
]
