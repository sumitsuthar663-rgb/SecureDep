"""SecureDep - an AI-assisted detector for malicious software packages.

The detection decision is made entirely by the deterministic static analysis
engine in :mod:`securedep.analysis`. The optional AI layer explains findings in
plain language and the optional MCP server exposes the engine to an agent;
neither influences a verdict. Removing both leaves a complete scanner.
"""

__version__ = "0.1.0"

from securedep.models import Ecosystem, PackageRef, RiskBand, ScanResult

__all__ = ["Ecosystem", "PackageRef", "RiskBand", "ScanResult", "__version__"]
