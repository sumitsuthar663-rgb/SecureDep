"""Command-line interface.

    securedep scan requests --ecosystem pypi
    securedep scan ./samples/evil-1.0.tar.gz --local --name evil
    securedep indicators

Exit codes are chosen so the tool can be used as a gate in a script:
0 = low risk, 1 = medium, 2 = high, 3 = critical, 4 = error.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from securedep.acquisition.extract import UnsafeArchiveError
from securedep.acquisition.registry import RegistryError
from securedep.analysis.engine import scan, scan_local
from securedep.models import Ecosystem, PackageRef, RiskBand
from securedep.reporting import render_text, to_json
from securedep.scoring.indicators import COMBINATIONS, INDICATORS

EXIT_CODES = {
    RiskBand.LOW: 0,
    RiskBand.MEDIUM: 1,
    RiskBand.HIGH: 2,
    RiskBand.CRITICAL: 3,
}
EXIT_ERROR = 4


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="securedep",
        description="Static analysis of npm and PyPI packages for malicious behaviour indicators. "
        "Packages are downloaded and read, never installed or executed.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    scan_cmd = sub.add_parser("scan", help="scan a package")
    scan_cmd.add_argument("target", help="package name, or path when --local is given")
    scan_cmd.add_argument(
        "-e",
        "--ecosystem",
        choices=[e.value for e in Ecosystem],
        default=Ecosystem.PYPI.value,
    )
    scan_cmd.add_argument("-v", "--package-version", help="specific version (default: latest)")
    scan_cmd.add_argument(
        "--local",
        action="store_true",
        help="analyse a local archive or extracted directory instead of fetching",
    )
    scan_cmd.add_argument("--name", help="package name to report when using --local")
    scan_cmd.add_argument("--json", action="store_true", help="emit the structured JSON report")
    scan_cmd.add_argument(
        "--verbose", action="store_true", help="show all evidence and the score breakdown"
    )
    scan_cmd.add_argument(
        "--check-repository",
        action="store_true",
        help="verify that a declared repository URL actually resolves (one extra request)",
    )
    scan_cmd.add_argument(
        "--explain",
        action="store_true",
        help="add an AI-generated plain-language explanation (Stage 3; needs "
        "ANTHROPIC_API_KEY). The explanation never changes the verdict.",
    )
    scan_cmd.add_argument("-o", "--output", type=Path, help="write the report to a file")

    indicators_cmd = sub.add_parser("indicators", help="list the indicator catalogue and weights")
    indicators_cmd.add_argument("--json", action="store_true")

    return parser


def _list_indicators(as_json: bool) -> int:
    if as_json:
        import json

        payload = {
            "indicators": [
                {
                    "id": s.id,
                    "category": s.category.value,
                    "title": s.title,
                    "description": s.description,
                    "weight": s.weight,
                    "contextual": s.contextual,
                }
                for s in INDICATORS.values()
            ],
            "combinations": [
                {
                    "id": r.id,
                    "title": r.title,
                    "description": r.description,
                    "requires": sorted(r.requires),
                    "requires_any": sorted(r.requires_any),
                    "bonus": r.bonus,
                }
                for r in COMBINATIONS
            ],
        }
        print(json.dumps(payload, indent=2))
        return 0

    by_category: dict[str, list] = {}
    for s in INDICATORS.values():
        by_category.setdefault(s.category.value, []).append(s)

    for category in sorted(by_category):
        print(f"\n{category}")
        for s in sorted(by_category[category], key=lambda x: -x.weight):
            tag = " (contextual)" if s.contextual else ""
            print(f"  {s.weight:5.1f}  {s.id}{tag}")
            print(f"         {s.title}")

    print("\ncombination rules")
    for rule in sorted(COMBINATIONS, key=lambda r: -r.bonus):
        print(f"  {rule.bonus:5.1f}  {rule.id}")
        print(f"         {rule.title}")
    print()
    return 0


def _run_scan(args: argparse.Namespace) -> int:
    ecosystem = Ecosystem(args.ecosystem)

    try:
        if args.local:
            path = Path(args.target)
            if not path.exists():
                print(f"securedep: {path} does not exist", file=sys.stderr)
                return EXIT_ERROR
            name = args.name or path.stem
            ref = PackageRef(name=name, ecosystem=ecosystem, version=args.package_version)
            result, breakdown = scan_local(path, ref, check_repository=args.check_repository)
        else:
            ref = PackageRef(name=args.target, ecosystem=ecosystem, version=args.package_version)
            result, breakdown = scan(ref, check_repository=args.check_repository)
    except RegistryError as exc:
        print(f"securedep: {exc}", file=sys.stderr)
        return EXIT_ERROR
    except UnsafeArchiveError as exc:
        # Refusing to extract is itself a security result, not a crash.
        print(f"securedep: refused to extract archive - {exc}", file=sys.stderr)
        return EXIT_CODES[RiskBand.HIGH]
    except OSError as exc:
        print(f"securedep: {exc}", file=sys.stderr)
        return EXIT_ERROR

    if args.explain:
        try:
            from securedep.explain import explain

            result.explanation = explain(result)
        except ImportError:
            print(
                "securedep: the explanation layer needs the 'ai' extra (pip install -e '.[ai]')",
                file=sys.stderr,
            )
        except Exception as exc:
            print(f"securedep: explanation unavailable ({exc})", file=sys.stderr)

    output = (
        to_json(result, breakdown)
        if args.json
        else render_text(result, breakdown, verbose=args.verbose)
    )

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output + "\n", encoding="utf-8")
        print(f"report written to {args.output}", file=sys.stderr)
    else:
        print(output)

    return EXIT_CODES[result.band]


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "indicators":
        return _list_indicators(args.json)
    return _run_scan(args)


if __name__ == "__main__":
    raise SystemExit(main())
