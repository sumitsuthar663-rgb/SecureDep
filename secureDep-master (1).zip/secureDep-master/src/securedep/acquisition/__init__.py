"""Stage 1 - acquisition.

Fetches a package archive from its registry and unpacks it into an isolated
directory. The package is never installed and never executed; every later
stage reads files from disk only.
"""

from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path
from typing import Any

from securedep.acquisition.extract import ExtractionReport
from securedep.acquisition.extract import extract as extract_archive
from securedep.acquisition.registry import ReleaseInfo, download, release_info
from securedep.models import Ecosystem, ExtractedPackage, PackageRef


class AcquiredPackage:
    """An extracted package plus the acquisition-time facts about it."""

    def __init__(
        self,
        package: ExtractedPackage,
        release: ReleaseInfo | None,
        extraction: ExtractionReport,
        workdir: Path,
        owns_workdir: bool,
    ) -> None:
        self.package = package
        self.release = release
        self.extraction = extraction
        self._workdir = workdir
        self._owns_workdir = owns_workdir

    def cleanup(self) -> None:
        if self._owns_workdir:
            shutil.rmtree(self._workdir, ignore_errors=True)

    def __enter__(self) -> AcquiredPackage:
        return self

    def __exit__(self, *exc: object) -> None:
        self.cleanup()


def _find_package_root(extracted: Path, ecosystem: Ecosystem) -> Path:
    """Descend into the single wrapper directory archives usually contain.

    npm tarballs wrap everything in ``package/``; PyPI sdists wrap in
    ``name-version/``. Analysing from the wrapper would make every relative
    path in the report noisier than it needs to be.
    """
    if ecosystem is Ecosystem.NPM:
        candidate = extracted / "package"
        if candidate.is_dir():
            return candidate

    entries = [p for p in extracted.iterdir() if not p.name.startswith(".")]
    if len(entries) == 1 and entries[0].is_dir():
        return entries[0]
    return extracted


def _read_manifest(root: Path, ecosystem: Ecosystem) -> dict[str, Any]:
    """Read the package manifest without executing it.

    For npm this is package.json. For PyPI, setup.py is *code* and must never
    be run, so the declarative sources (PKG-INFO, pyproject.toml, setup.cfg)
    are read instead; setup.py is analysed as source in Stage 2.
    """
    if ecosystem is Ecosystem.NPM:
        manifest_path = root / "package.json"
        if manifest_path.is_file():
            try:
                return json.loads(manifest_path.read_text(encoding="utf-8", errors="replace"))
            except json.JSONDecodeError:
                return {}
        return {}

    manifest: dict[str, Any] = {}

    pkg_info = next(iter(root.glob("*.egg-info/PKG-INFO")), None) or root / "PKG-INFO"
    if pkg_info.is_file():
        for line in pkg_info.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line or line.startswith(" ") or ":" not in line:
                continue
            key, _, value = line.partition(":")
            manifest.setdefault(key.strip().lower().replace("-", "_"), value.strip())

    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        try:
            import tomllib
        except ModuleNotFoundError:  # pragma: no cover - Python 3.10
            tomllib = None  # type: ignore[assignment]
        if tomllib is not None:
            try:
                data = tomllib.loads(pyproject.read_text(encoding="utf-8", errors="replace"))
                manifest["pyproject"] = data
            except Exception:
                pass

    return manifest


def acquire(
    ref: PackageRef,
    workdir: Path | None = None,
    keep: bool = False,
) -> AcquiredPackage:
    """Download and safely extract ``ref``.

    Raises RegistryError/PackageNotFound on lookup failure and
    UnsafeArchiveError if the archive tries to escape the extraction directory.
    """
    owns = workdir is None
    base = workdir or Path(tempfile.mkdtemp(prefix="securedep-"))
    base.mkdir(parents=True, exist_ok=True)

    release = release_info(ref)
    archive = download(release, into=base / "archive")
    extracted_to = base / "extracted"
    report = extract_archive(archive, extracted_to)

    root = _find_package_root(extracted_to, ref.ecosystem)
    package = ExtractedPackage(
        ref=release.ref,
        root=root,
        registry_metadata=release.raw,
        manifest=_read_manifest(root, ref.ecosystem),
    )
    return AcquiredPackage(package, release, report, base, owns and not keep)


def acquire_local(path: Path, ref: PackageRef) -> AcquiredPackage:
    """Analyse an already-extracted directory or a local archive.

    Used by the evaluation harness, which works from a downloaded corpus rather
    than hitting the registries once per run.
    """
    if path.is_dir():
        root = _find_package_root(path, ref.ecosystem)
        package = ExtractedPackage(ref=ref, root=root, manifest=_read_manifest(root, ref.ecosystem))
        return AcquiredPackage(package, None, ExtractionReport(), path, False)

    base = Path(tempfile.mkdtemp(prefix="securedep-"))
    report = extract_archive(path, base / "extracted")
    root = _find_package_root(base / "extracted", ref.ecosystem)
    package = ExtractedPackage(ref=ref, root=root, manifest=_read_manifest(root, ref.ecosystem))
    return AcquiredPackage(package, None, report, base, True)


__all__ = ["AcquiredPackage", "acquire", "acquire_local"]
