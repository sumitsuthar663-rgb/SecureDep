"""Registry clients for PyPI and npm (section 7.1).

Only metadata endpoints and archive downloads are used. No package manager is
invoked, so nothing in a fetched package is ever installed or executed.
"""

from __future__ import annotations

import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests

from securedep.models import Ecosystem, PackageRef

PYPI_API = "https://pypi.org/pypi"
NPM_API = "https://registry.npmjs.org"

USER_AGENT = "SecureDep/0.1 (static analysis research tool)"
TIMEOUT = 30
#: Refuse to download anything larger than this before it reaches disk.
MAX_DOWNLOAD_BYTES = 256 * 1024 * 1024


class RegistryError(Exception):
    pass


class PackageNotFound(RegistryError):
    pass


@dataclass
class ReleaseInfo:
    """Normalised view of a release, so analysers do not care which registry."""

    ref: PackageRef
    archive_url: str
    filename: str
    #: Publication time of this specific release.
    published: datetime | None
    #: Publication time of the package's very first release.
    first_published: datetime | None
    version_count: int
    raw: dict[str, Any]


def _session() -> requests.Session:
    s = requests.Session()
    s.headers["User-Agent"] = USER_AGENT
    return s


def _parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    text = value.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


# ---------------------------------------------------------------------------
# PyPI
# ---------------------------------------------------------------------------


def fetch_pypi_metadata(name: str, version: str | None = None) -> dict[str, Any]:
    url = f"{PYPI_API}/{name}/json" if version is None else f"{PYPI_API}/{name}/{version}/json"
    response = _session().get(url, timeout=TIMEOUT)
    if response.status_code == 404:
        raise PackageNotFound(f"pypi:{name} not found")
    response.raise_for_status()
    return response.json()


def pypi_release(name: str, version: str | None = None) -> ReleaseInfo:
    # Always fetch the full document: it carries the complete release history,
    # which the metadata analyser needs for age and version count.
    full = fetch_pypi_metadata(name)
    resolved = version or full["info"]["version"]

    files = full.get("releases", {}).get(resolved) or []
    if not files:
        # Yanked or unlisted versions are absent from `releases` on some
        # responses; fall back to the version-specific document.
        files = fetch_pypi_metadata(name, resolved).get("urls", [])
    if not files:
        raise PackageNotFound(f"pypi:{name}=={resolved} has no downloadable files")

    # An sdist carries setup.py, which is where install-time execution lives.
    # A wheel has already been built and cannot contain an install hook, so it
    # is strictly worse for this analysis - prefer the sdist.
    chosen = next((f for f in files if f.get("packagetype") == "sdist"), files[0])

    release_times = [
        _parse_time(f.get("upload_time_iso_8601") or f.get("upload_time"))
        for versions in full.get("releases", {}).values()
        for f in versions
    ]
    known = sorted(t for t in release_times if t is not None)

    return ReleaseInfo(
        ref=PackageRef(name=name, ecosystem=Ecosystem.PYPI, version=resolved),
        archive_url=chosen["url"],
        filename=chosen["filename"],
        published=_parse_time(chosen.get("upload_time_iso_8601") or chosen.get("upload_time")),
        first_published=known[0] if known else None,
        version_count=len(full.get("releases", {})),
        raw=full,
    )


# ---------------------------------------------------------------------------
# npm
# ---------------------------------------------------------------------------


def fetch_npm_metadata(name: str) -> dict[str, Any]:
    response = _session().get(f"{NPM_API}/{name}", timeout=TIMEOUT)
    if response.status_code == 404:
        raise PackageNotFound(f"npm:{name} not found")
    response.raise_for_status()
    return response.json()


def npm_release(name: str, version: str | None = None) -> ReleaseInfo:
    full = fetch_npm_metadata(name)
    resolved = version or full.get("dist-tags", {}).get("latest")
    if resolved is None:
        raise PackageNotFound(f"npm:{name} has no latest version")

    versions = full.get("versions", {})
    if resolved not in versions:
        raise PackageNotFound(f"npm:{name}@{resolved} not found")

    document = versions[resolved]
    tarball = document.get("dist", {}).get("tarball")
    if not tarball:
        raise PackageNotFound(f"npm:{name}@{resolved} has no tarball")

    times = full.get("time", {})
    published = _parse_time(times.get(resolved))
    created = _parse_time(times.get("created"))

    return ReleaseInfo(
        ref=PackageRef(name=name, ecosystem=Ecosystem.NPM, version=resolved),
        archive_url=tarball,
        filename=tarball.rsplit("/", 1)[-1],
        published=published,
        first_published=created,
        version_count=len(versions),
        raw=full,
    )


def release_info(ref: PackageRef) -> ReleaseInfo:
    if ref.ecosystem is Ecosystem.PYPI:
        return pypi_release(ref.name, ref.version)
    return npm_release(ref.name, ref.version)


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------


def download(release: ReleaseInfo, into: Path | None = None) -> Path:
    """Stream the archive to disk. The archive is never opened or executed here."""
    directory = into or Path(tempfile.mkdtemp(prefix="securedep-"))
    directory.mkdir(parents=True, exist_ok=True)

    # The filename comes from the registry, i.e. from the package author.
    # Strip it to a bare basename so it cannot direct the write elsewhere.
    target = directory / Path(release.filename).name

    with _session().get(release.archive_url, stream=True, timeout=TIMEOUT) as response:
        response.raise_for_status()
        written = 0
        with open(target, "wb") as out:
            for chunk in response.iter_content(chunk_size=1 << 16):
                written += len(chunk)
                if written > MAX_DOWNLOAD_BYTES:
                    out.close()
                    target.unlink(missing_ok=True)
                    raise RegistryError(f"{release.filename} exceeds the download size limit")
                out.write(chunk)

    return target


def repository_exists(url: str) -> bool:
    """Check whether a declared repository URL actually resolves (section 7.2)."""
    if not url.startswith(("http://", "https://")):
        return False
    try:
        response = _session().head(url, timeout=TIMEOUT, allow_redirects=True)
        if response.status_code >= 400:
            response = _session().get(url, timeout=TIMEOUT, stream=True)
        return response.status_code < 400
    except requests.RequestException:
        return False
