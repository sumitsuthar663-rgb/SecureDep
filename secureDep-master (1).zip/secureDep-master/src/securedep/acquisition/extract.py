"""Safe archive extraction (section 7.1).

A package archive is attacker-controlled input. Extracting one naively is
itself a vulnerability, so this module refuses anything that could write
outside the target directory or exhaust local resources:

  * Path traversal / Zip Slip - entries such as ``../../etc/passwd`` or
    absolute paths. Every destination is resolved and checked to still be
    inside the target directory.
  * Symlink and hardlink escapes - a symlink pointing at ``/`` followed by a
    write through it lands outside the target. Links are skipped entirely;
    the analyser has no use for them.
  * Device/FIFO entries - never present in a legitimate package.
  * Decompression bombs - total uncompressed size and entry count are capped.

Nothing here executes any part of the archive.
"""

from __future__ import annotations

import tarfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

#: Refuse archives that expand beyond this. Legitimate packages are far
#: smaller; anything larger is either a bomb or out of scope for analysis.
MAX_TOTAL_BYTES = 512 * 1024 * 1024
MAX_ENTRIES = 20_000
MAX_SINGLE_FILE_BYTES = 64 * 1024 * 1024


class UnsafeArchiveError(Exception):
    """Raised when an archive tries to escape the extraction directory."""


@dataclass
class ExtractionReport:
    """What happened during extraction.

    Skipped entries are not merely a hygiene detail - an archive containing a
    traversal path is itself strong evidence of malicious intent, so the
    reasons are surfaced to the caller rather than swallowed.
    """

    extracted: int = 0
    total_bytes: int = 0
    skipped: list[tuple[str, str]] = field(default_factory=list)

    def skip(self, name: str, reason: str) -> None:
        self.skipped.append((name, reason))

    @property
    def had_traversal_attempt(self) -> bool:
        return any(r in ("path traversal", "absolute path") for _, r in self.skipped)


def _is_within(base: Path, target: Path) -> bool:
    """True if ``target`` resolves to a location inside ``base``."""
    try:
        target.resolve().relative_to(base.resolve())
    except ValueError:
        return False
    return True


def _safe_destination(base: Path, name: str, report: ExtractionReport) -> Path | None:
    if name.startswith("/") or (len(name) > 1 and name[1] == ":"):
        report.skip(name, "absolute path")
        return None

    destination = base / name
    if not _is_within(base, destination):
        report.skip(name, "path traversal")
        return None

    # A parent component that is already an existing symlink would redirect the
    # write even though the joined path looks contained.
    for parent in list(destination.parents):
        if parent == base:
            break
        if parent.is_symlink():
            report.skip(name, "symlinked parent directory")
            return None

    return destination


def extract_tar(archive: Path, destination: Path) -> ExtractionReport:
    destination.mkdir(parents=True, exist_ok=True)
    report = ExtractionReport()

    with tarfile.open(archive, mode="r:*") as tar:
        for member in tar:
            if report.extracted >= MAX_ENTRIES:
                raise UnsafeArchiveError(f"archive exceeds {MAX_ENTRIES} entries")

            if member.issym() or member.islnk():
                report.skip(member.name, "link entry")
                continue
            if member.isdev() or member.isfifo():
                report.skip(member.name, "device or fifo entry")
                continue
            if not (member.isfile() or member.isdir()):
                report.skip(member.name, "unsupported entry type")
                continue

            target = _safe_destination(destination, member.name, report)
            if target is None:
                continue

            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue

            if member.size > MAX_SINGLE_FILE_BYTES:
                report.skip(member.name, "file too large")
                continue
            if report.total_bytes + member.size > MAX_TOTAL_BYTES:
                raise UnsafeArchiveError("archive expands beyond the size limit")

            source = tar.extractfile(member)
            if source is None:
                report.skip(member.name, "unreadable entry")
                continue

            target.parent.mkdir(parents=True, exist_ok=True)
            with source, open(target, "wb") as out:
                written = 0
                while chunk := source.read(1 << 16):
                    written += len(chunk)
                    if written > MAX_SINGLE_FILE_BYTES:
                        raise UnsafeArchiveError(f"{member.name} exceeds the file size limit")
                    out.write(chunk)

            # Never preserve archive permissions: an executable bit from an
            # untrusted archive has no legitimate purpose here.
            target.chmod(0o600)
            report.extracted += 1
            report.total_bytes += written

    return report


def extract_zip(archive: Path, destination: Path) -> ExtractionReport:
    destination.mkdir(parents=True, exist_ok=True)
    report = ExtractionReport()

    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            if report.extracted >= MAX_ENTRIES:
                raise UnsafeArchiveError(f"archive exceeds {MAX_ENTRIES} entries")

            # Unix mode is in the top 16 bits of external_attr; 0xA000 is a
            # symlink. zipfile will happily write the link target as content.
            mode = info.external_attr >> 16
            if mode and (mode & 0xF000) == 0xA000:
                report.skip(info.filename, "link entry")
                continue

            target = _safe_destination(destination, info.filename, report)
            if target is None:
                continue

            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue

            if info.file_size > MAX_SINGLE_FILE_BYTES:
                report.skip(info.filename, "file too large")
                continue
            if report.total_bytes + info.file_size > MAX_TOTAL_BYTES:
                raise UnsafeArchiveError("archive expands beyond the size limit")

            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as source, open(target, "wb") as out:
                written = 0
                while chunk := source.read(1 << 16):
                    written += len(chunk)
                    if written > MAX_SINGLE_FILE_BYTES:
                        raise UnsafeArchiveError(f"{info.filename} exceeds the file size limit")
                    out.write(chunk)

            target.chmod(0o600)
            report.extracted += 1
            report.total_bytes += written

    return report


def extract(archive: Path, destination: Path) -> ExtractionReport:
    """Extract ``archive`` into ``destination``, choosing the format by content."""
    if zipfile.is_zipfile(archive):
        return extract_zip(archive, destination)
    if tarfile.is_tarfile(archive):
        return extract_tar(archive, destination)
    raise UnsafeArchiveError(f"{archive.name} is not a recognised tar or zip archive")
