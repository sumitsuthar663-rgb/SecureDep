"""Core data types shared by every stage of the pipeline.

These types are the contract between the acquisition layer, the analysis
engine, the scoring model and the reporting layer. Keeping them free of any
analysis logic is what allows Stage 3 (AI explanation) and Stage 4 (MCP) to be
bolted on later without touching the detection code.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class Ecosystem(str, Enum):
    PYPI = "pypi"
    NPM = "npm"


class RiskBand(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Category(str, Enum):
    """Behavioural categories from section 7.4 of the project document."""

    METADATA = "metadata"
    INSTALL_HOOK = "install_hook"
    DYNAMIC_EXECUTION = "dynamic_execution"
    NETWORK = "network"
    CREDENTIAL_ACCESS = "credential_access"
    RECONNAISSANCE = "reconnaissance"
    PERSISTENCE = "persistence"
    ENCODING = "encoding"
    OBFUSCATION = "obfuscation"
    TYPOSQUATTING = "typosquatting"
    COMBINATION = "combination"


@dataclass(frozen=True)
class Evidence:
    """A concrete pointer to the code that caused an indicator to fire.

    Every finding must carry evidence. A risk score without traceable evidence
    is not actionable, and interpretability is a stated objective of the
    project (section 7.8).
    """

    path: str
    line: int | None = None
    snippet: str = ""
    #: Set when the evidence was recovered by the deobfuscation module rather
    #: than read directly from the package source.
    decoded: bool = False

    def __str__(self) -> str:
        where = f"{self.path}:{self.line}" if self.line else self.path
        tag = " (decoded)" if self.decoded else ""
        return f"{where}{tag} {self.snippet}".rstrip()


@dataclass
class Finding:
    """One triggered indicator, with the evidence that triggered it."""

    indicator: str
    evidence: list[Evidence] = field(default_factory=list)
    #: Free-form extra context an analyser wants to expose to the report
    #: (entropy values, edit distances, the matched popular package name...).
    context: dict[str, Any] = field(default_factory=dict)

    def add(self, evidence: Evidence) -> None:
        self.evidence.append(evidence)


@dataclass(frozen=True)
class PackageRef:
    name: str
    ecosystem: Ecosystem
    version: str | None = None

    def __str__(self) -> str:
        v = f"@{self.version}" if self.version else ""
        return f"{self.ecosystem.value}:{self.name}{v}"


@dataclass
class ExtractedPackage:
    """A package archive that has been downloaded and safely unpacked.

    The package is never installed and never executed - only read from disk.
    """

    ref: PackageRef
    root: Path
    #: Raw registry metadata (PyPI JSON API / npm registry document).
    registry_metadata: dict[str, Any] = field(default_factory=dict)
    #: Parsed package manifest (setup.py/PKG-INFO fields, or package.json).
    manifest: dict[str, Any] = field(default_factory=dict)

    def source_files(self, suffixes: tuple[str, ...]) -> list[Path]:
        return sorted(
            p
            for p in self.root.rglob("*")
            if p.is_file() and not p.is_symlink() and p.suffix in suffixes
        )

    def relpath(self, path: Path) -> str:
        try:
            return str(path.relative_to(self.root))
        except ValueError:
            return str(path)


@dataclass
class ScanResult:
    ref: PackageRef
    findings: list[Finding] = field(default_factory=list)
    score: float = 0.0
    band: RiskBand = RiskBand.LOW
    #: Non-fatal problems (a file that would not parse, a metadata lookup that
    #: failed). Surfaced in the report so a clean-looking result is not
    #: silently based on incomplete analysis.
    warnings: list[str] = field(default_factory=list)
    #: Populated by the optional Stage 3 explanation layer.
    explanation: str | None = None

    def has(self, indicator: str) -> bool:
        return any(f.indicator == indicator for f in self.findings)

    @property
    def indicators(self) -> set[str]:
        return {f.indicator for f in self.findings}

    def to_dict(self) -> dict[str, Any]:
        return {
            "package": {
                "name": self.ref.name,
                "ecosystem": self.ref.ecosystem.value,
                "version": self.ref.version,
            },
            "score": round(self.score, 2),
            "band": self.band.value,
            "findings": [asdict(f) for f in self.findings],
            "warnings": self.warnings,
            "explanation": self.explanation,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)
