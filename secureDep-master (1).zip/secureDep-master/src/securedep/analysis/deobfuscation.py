"""Deobfuscation and second-pass analysis (section 7.6).

Where encoding is detected, this module reverses it - base64, hexadecimal,
escape sequences, character-code arrays - and feeds the recovered content back
through the AST analysers. Malicious packages frequently hide a highly
suspicious payload inside an innocuous-looking wrapper, so a single pass over
the visible source systematically under-reports.

Decoded content is treated purely as data. It is decoded in memory, analysed
as text, and never written to an importable location or executed.
"""

from __future__ import annotations

import base64
import binascii
import re
from dataclasses import dataclass
from pathlib import Path

from securedep.analysis.ast_python import analyse_python_source
from securedep.analysis.base import AnalysisContext

#: Bound the decode chain - layered encodings are common, infinite ones are a
#: denial-of-service vector against the scanner.
MAX_DECODE_ROUNDS = 4
MIN_DECODED_LENGTH = 16

BASE64_CANDIDATE = re.compile(r"^[A-Za-z0-9+/=\s]{20,}$")
HEX_CANDIDATE = re.compile(r"^(?:0x)?[0-9a-fA-F\s]{32,}$")
HEX_ESCAPES = re.compile(r"(?:\\x[0-9a-fA-F]{2}){6,}")
UNICODE_ESCAPES = re.compile(r"(?:\\u[0-9a-fA-F]{4}){6,}")

#: Tokens that mark decoded content as worth a full second pass.
CODE_MARKERS = re.compile(
    r"\b(?:import|require|eval|exec|subprocess|os\.system|child_process|"
    r"process\.env|os\.environ|fetch|urlopen|https?://|function|lambda|def )\b"
)


@dataclass
class Decoded:
    source_path: str
    source_line: int
    content: str
    #: Which decoders were applied, outermost first.
    chain: list[str]


def _printable_ratio(data: bytes) -> float:
    if not data:
        return 0.0
    printable = sum(1 for b in data if 32 <= b <= 126 or b in (9, 10, 13))
    return printable / len(data)


def _try_base64(value: str) -> str | None:
    compact = "".join(value.split())
    if not BASE64_CANDIDATE.match(value) or len(compact) % 4:
        return None
    try:
        raw = base64.b64decode(compact, validate=True)
    except (binascii.Error, ValueError):
        return None
    if len(raw) < MIN_DECODED_LENGTH or _printable_ratio(raw) < 0.85:
        return None
    return raw.decode("utf-8", errors="replace")


def _try_hex(value: str) -> str | None:
    compact = "".join(value.split()).removeprefix("0x")
    if not HEX_CANDIDATE.match(value) or len(compact) % 2:
        return None
    try:
        raw = binascii.unhexlify(compact)
    except (binascii.Error, ValueError):
        return None
    if len(raw) < MIN_DECODED_LENGTH or _printable_ratio(raw) < 0.85:
        return None
    return raw.decode("utf-8", errors="replace")


def _try_escapes(value: str) -> str | None:
    if not (HEX_ESCAPES.search(value) or UNICODE_ESCAPES.search(value)):
        return None
    try:
        decoded = value.encode("latin-1", errors="ignore").decode("unicode_escape")
    except (UnicodeDecodeError, UnicodeEncodeError):
        return None
    if len(decoded) < MIN_DECODED_LENGTH or decoded == value:
        return None
    return decoded


DECODERS = (
    ("base64", _try_base64),
    ("hex", _try_hex),
    ("escape", _try_escapes),
)


def decode_chain(value: str) -> tuple[str, list[str]] | None:
    """Repeatedly decode ``value`` until nothing further applies.

    Returns the final content and the list of decoders applied, or None if
    nothing could be decoded.
    """
    current = value
    chain: list[str] = []

    for _ in range(MAX_DECODE_ROUNDS):
        for name, decoder in DECODERS:
            decoded = decoder(current)
            if decoded is not None and decoded != current:
                chain.append(name)
                current = decoded
                break
        else:
            break

    return (current, chain) if chain else None


def _second_pass(ctx: AnalysisContext, item: Decoded) -> bool:
    """Re-analyse decoded content. Returns True if it triggered indicators."""
    if not CODE_MARKERS.search(item.content):
        return False

    sub = AnalysisContext(ctx.package)
    sub.shared["install_time_files"] = ctx.shared.get("install_time_files", set())
    analyse_python_source(
        sub,
        Path(item.source_path),
        item.content,
        install_time=item.source_path in sub.shared["install_time_files"],
    )

    # Fall back to pattern matching when the payload is not valid Python -
    # a decoded JavaScript or shell payload still deserves to be reported.
    from securedep.analysis import patterns

    extra: list[tuple[str, str]] = []
    if patterns.SENSITIVE_PATHS.search(item.content):
        extra.append(("credentials.sensitive_path", "credential path in decoded payload"))
    if patterns.PERSISTENCE_TARGETS.search(item.content):
        extra.append(("persistence.startup_modification", "persistence target in decoded payload"))
    for indicator in patterns.classify_destination(item.content):
        extra.append((indicator, "network destination in decoded payload"))

    findings = sub.findings
    if not findings and not extra:
        return False

    label = f"{item.source_path} [decoded: {' -> '.join(item.chain)}]"

    for finding in findings:
        ctx.flag(
            finding.indicator,
            path=label,
            line=item.source_line,
            snippet=finding.evidence[0].snippet if finding.evidence else "",
            decoded=True,
            recovered_from=item.source_path,
        )

    for indicator, note in extra:
        ctx.flag(
            indicator,
            path=label,
            line=item.source_line,
            snippet=note,
            decoded=True,
            recovered_from=item.source_path,
        )

    summary = ctx.flag(
        "obfuscation.decoded_payload_suspicious",
        path=label,
        line=item.source_line,
        snippet=item.content[:160],
        decoded=True,
    )

    # A package may hide several payloads. The indicator fires once, but its
    # context must accumulate across all of them rather than being overwritten
    # by whichever happened to be decoded last.
    triggered = {f.indicator for f in findings} | {i for i, _ in extra}
    summary.context["triggered"] = sorted(set(summary.context.get("triggered", [])) | triggered)
    summary.context["chain"] = sorted(set(summary.context.get("chain", [])) | set(item.chain))
    summary.context["payloads"] = summary.context.get("payloads", 0) + 1

    return True


class DeobfuscationAnalyzer:
    """Runs after the AST and obfuscation analysers, over what they collected."""

    name = "deobfuscation"

    def run(self, ctx: AnalysisContext) -> None:
        collected: list[tuple[str, int, str]] = ctx.shared.get("encoded_literals", [])
        seen: set[str] = set()
        recovered: list[Decoded] = []

        for path, line, value in collected:
            if value in seen:
                continue
            seen.add(value)

            result = decode_chain(value)
            if result is None:
                # Character-code arrays are already plain text by the time they
                # reach here; analyse them directly.
                if CODE_MARKERS.search(value):
                    recovered.append(Decoded(path, line, value, ["charcode"]))
                continue

            content, chain = result
            recovered.append(Decoded(path, line, content, chain))

        for item in recovered:
            _second_pass(ctx, item)

        ctx.shared["decoded"] = recovered
