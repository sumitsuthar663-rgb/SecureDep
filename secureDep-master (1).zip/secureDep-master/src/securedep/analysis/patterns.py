"""Language-independent pattern tables.

The AST analysers decide *structurally* whether a call is a network call or a
file read. These tables answer the orthogonal question of whether the string
data involved is sensitive - a credential path, an exfiltration host, a
persistence location. Keeping them here means the Python and JavaScript
analysers agree on what "reading a credential" means.
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Credential and wallet locations (7.4 - credential access)
# ---------------------------------------------------------------------------

#: Names that identify a credential store on their own. These are distinctive
#: enough that an occurrence in prose is still worth reporting.
#: The leading lookbehind stops attribute access from matching a filename:
#: ``process.env["X"]`` is reading an environment variable, not opening a
#: ``.env`` file, and ``boto3.session`` is not ``~/.ssh``.
_DISTINCTIVE_CREDENTIALS = r"""
    (?<![A-Za-z0-9_])
    (?:
        \.aws\b | \.ssh\b
      | \.npmrc\b | \.pypirc\b | \.netrc\b | _netrc\b | \.git-credentials\b
      | \.docker[/\\]config\.json
      | \.kube[/\\]config
      | \.env(?:\.[a-z]+)?\b
      | id_rsa\b | id_ed25519\b | id_ecdsa\b | authorized_keys\b
      # cryptocurrency wallets
      | wallet\.dat | \.electrum\b | Ethereum[/\\]keystore
      | nkbihfbeogaeaoehlefnkodbefgpgknn
      # cloud metadata service - used for SSRF-style credential theft
      | 169\.254\.169\.254
    )
"""

#: Words that only indicate a credential store when they appear as a path
#: component. Without the separator requirement these match ordinary prose -
#: "extract the cookies from the response" in a docstring is not credential
#: access, and treating it as such produced false positives on requests itself.
_PATH_SCOPED_CREDENTIALS = r"""
    [/\\]
    (?:
        credentials(?:\.json)?
      | Login\ Data(?:\ For\ Account)?
      | Cookies
      | Local\ State
      | Web\ Data
      | keystore
      | shadow
    )
    (?:["'\s/\\,)\]]|$)
"""

SENSITIVE_PATHS = re.compile(
    f"(?:{_DISTINCTIVE_CREDENTIALS})|(?:{_PATH_SCOPED_CREDENTIALS})",
    re.VERBOSE | re.IGNORECASE,
)

KEYCHAIN_TOKENS = re.compile(
    r"\b(?:security\s+find-generic-password|SecKeychain|CredEnumerate|"
    r"CredRead|libsecret|gnome-keyring|keyring\.get_password|DPAPI|CryptUnprotectData)\b",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Exfiltration-friendly destinations (7.4 - network)
# ---------------------------------------------------------------------------

SUSPICIOUS_HOSTS = re.compile(
    r"""
    (?:
        # request/webhook capture services
        (?:[a-z0-9-]+\.)? (?:requestbin\.\w+|pipedream\.net|webhook\.site
                            |requestcatcher\.com|interact\.sh|oast\.\w+
                            |burpcollaborator\.net|canarytokens\.com
                            |ngrok\.(?:io|app|dev)|localtunnel\.me|trycloudflare\.com)
        # paste and anonymous file hosts
      | (?:pastebin\.com|paste\.ee|hastebin\.com|ghostbin\.\w+|transfer\.sh
          |anonfiles\.com|file\.io|0x0\.st|termbin\.com|controlc\.com)
        # chat webhooks commonly used as drop points
      | (?:discord(?:app)?\.com/api/webhooks|hooks\.slack\.com|api\.telegram\.org)
        # dynamic DNS
      | [a-z0-9-]+\.(?:duckdns\.org|no-ip\.\w+|hopto\.org|ddns\.net|serveo\.net)
        # DNS-exfiltration helpers
      | [a-z0-9-]+\.(?:dnslog\.cn|ceye\.io)
    )
    """,
    re.VERBOSE | re.IGNORECASE,
)

#: A literal IPv4 address used as a destination. Loopback, link-local and the
#: RFC 5737 documentation ranges are excluded - a package talking to 127.0.0.1
#: is doing something local, not exfiltrating.
HARDCODED_IP = re.compile(
    r"""
    (?<![\w.])
    (?!127\.|0\.|255\.|169\.254\.|192\.0\.2\.|198\.51\.100\.|203\.0\.113\.)
    (?:
        (?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d) \.
    ){3}
    (?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)
    (?![\w.])
    """,
    re.VERBOSE,
)

URL_LITERAL = re.compile(r"https?://[^\s'\"<>`]+", re.IGNORECASE)

# ---------------------------------------------------------------------------
# System reconnaissance (7.4)
# ---------------------------------------------------------------------------

RECON_TOKENS = re.compile(
    r"\b(?:"
    r"gethostname|hostname|getfqdn|os\.uname|platform\.(?:node|system|release|machine|platform)"
    r"|getpass\.getuser|os\.getlogin|userInfo|homedir|networkInterfaces"
    r"|ifconfig|ipconfig|whoami|systeminfo|uname\s+-a"
    r"|getuid|geteuid|getgroups"
    r")\b",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Persistence (7.4)
# ---------------------------------------------------------------------------

PERSISTENCE_TARGETS = re.compile(
    r"""
    (?:
        \.bashrc | \.bash_profile | \.zshrc | \.profile | \.zprofile
      | /etc/(?:profile|rc\.local|cron\.[a-z]+|systemd/system)
      | crontab | /var/spool/cron
      | LaunchAgents | LaunchDaemons | \.plist (?:["']|$)
      | schtasks | at\.exe
      | Start\ Menu[\\/]Programs[\\/]Startup
      | (?:HKCU|HKLM|HKEY_CURRENT_USER|HKEY_LOCAL_MACHINE)
        .{0,80}?
        (?:CurrentVersion[\\/]+Run|Run(?:Once)?\b)
    )
    """,
    re.VERBOSE | re.IGNORECASE,
)


def classify_destination(text: str) -> set[str]:
    """Return the network indicators a string literal justifies."""
    hits: set[str] = set()
    if SUSPICIOUS_HOSTS.search(text):
        hits.add("network.suspicious_host")
    for url in URL_LITERAL.findall(text):
        host = url.split("//", 1)[-1].split("/", 1)[0].split("@")[-1].split(":")[0]
        if HARDCODED_IP.fullmatch(host):
            hits.add("network.hardcoded_ip")
    return hits
