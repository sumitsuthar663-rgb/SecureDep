"""Obfuscation detection (section 7.5).

Attackers make code unreadable so a reviewer glancing at the package sees
nothing meaningful. That concealment is detectable statistically: ordinary
source has recognisable words, repeated identifiers and predictable structure,
giving moderate Shannon entropy, while encoded payloads approach the
statistical properties of random data.

CALIBRATION NOTE
----------------
The thresholds below are starting values, not results. Phase 5 must replace
them with values measured across the benign corpus - see
``scripts/calibrate_entropy.py``, which reports the distribution of these
metrics over a directory of packages so a cut-off can be chosen from data.
Presenting an uncalibrated threshold as empirically derived would be false.
"""

from __future__ import annotations

import bisect
import math
import re
from collections import Counter
from pathlib import Path

from securedep.analysis.base import AnalysisContext

#: Shannon entropy in bits per character. Base64 of random bytes sits near
#: 6.0; English prose and normal identifiers sit near 4.0-4.5.
ENTROPY_THRESHOLD = 4.8
#: Ignore short strings - entropy is meaningless on a handful of characters.
MIN_ENTROPY_STRING_LENGTH = 40

LONG_LINE_THRESHOLD = 1000
MIN_LONG_LINES = 1

#: Proportion of identifiers that must look machine-generated before flagging.
MEANINGLESS_IDENTIFIER_RATIO = 0.25
MIN_IDENTIFIERS = 20

STRING_LITERAL = re.compile(
    r"""(?:"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)'|`((?:[^`\\]|\\.)*)`)""",
    re.DOTALL,
)

IDENTIFIER = re.compile(r"\b[A-Za-z_$][A-Za-z0-9_$]{2,}\b")

#: _0x4f2a, a1b2c3, $_$_ - names carrying no semantic content.
MEANINGLESS_IDENTIFIER = re.compile(
    r"""^(?:
        _*0x[0-9a-fA-F]{2,}_*
      | [a-zA-Z]?[0-9a-fA-F]{6,}
      | (?:[a-zA-Z][0-9]){3,}[a-zA-Z]?
      | [_$]{3,}
      | [OolI1]{5,}
    )$""",
    re.VERBOSE,
)

CHARCODE_ARRAY = re.compile(r"\[\s*(?:\d{1,3}\s*,\s*){11,}\d{1,3}\s*,?\s*\]")

#: Characters that make up base64, hex, and url-safe encoded blobs.
ENCODED_ALPHABET = re.compile(r"[A-Za-z0-9+/=_\-]")
#: Fraction of a literal that must come from that alphabet before entropy is
#: even considered.
ENCODED_ALPHABET_RATIO = 0.95


def looks_encoded(text: str) -> bool:
    """True if a literal has the *shape* of encoded data.

    Entropy alone is not enough. Natural-language text containing emoji,
    accented characters or CJK scores as high as base64 does, which produced
    false positives on ordinary packages (six's test suite, for example).
    Encoded payloads are additionally characterised by having no whitespace and
    being drawn almost entirely from a restricted alphabet - requiring that
    first removes the false positives without weakening detection of the
    encoded blobs the module actually exists to find.
    """
    if not text or any(c.isspace() for c in text):
        return False

    matched = len(ENCODED_ALPHABET.findall(text))
    if matched / len(text) < ENCODED_ALPHABET_RATIO:
        return False

    # A charset definition - "ABCDEFGHIJ...0123456789._-~" in a URL encoder,
    # for instance - is maximally high-entropy but is not encoded data. It is
    # distinguishable because almost every character appears exactly once,
    # whereas an encoded payload of any length reuses its alphabet heavily.
    return len(set(text)) / len(text) < 0.9


ANALYSED_SUFFIXES = (".py", ".pyw", ".js", ".cjs", ".mjs", ".ts", ".jsx", ".tsx", ".json")


def shannon_entropy(text: str) -> float:
    """Bits of entropy per character."""
    if not text:
        return 0.0
    counts = Counter(text)
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


def _line_index(source: str) -> list[int]:
    """Byte offsets of each newline, for O(log n) offset-to-line lookups.

    Counting newlines from the start for every match made this quadratic in
    files with many literals.
    """
    offsets: list[int] = []
    start = source.find("\n")
    while start != -1:
        offsets.append(start)
        start = source.find("\n", start + 1)
    return offsets


def _line_at(index: list[int], offset: int) -> int:
    return bisect.bisect_right(index, offset - 1) + 1


def string_literals(source: str) -> list[tuple[int, str]]:
    """Extract quoted literals with their line numbers.

    Deliberately regex-based rather than AST-based: this runs over both Python
    and JavaScript, including files that failed to parse, which are exactly the
    files most likely to be obfuscated.
    """
    index = _line_index(source)
    out: list[tuple[int, str]] = []
    for match in STRING_LITERAL.finditer(source):
        value = next((g for g in match.groups() if g is not None), "")
        if value:
            out.append((_line_at(index, match.start()), value))
    return out


def file_metrics(source: str) -> dict[str, float]:
    """Metrics used both for detection and for threshold calibration."""
    lines = source.splitlines() or [""]
    literals = string_literals(source)
    identifiers = IDENTIFIER.findall(source)
    meaningless = [i for i in identifiers if MEANINGLESS_IDENTIFIER.match(i)]
    long_literals = [
        v for _, v in literals if len(v) >= MIN_ENTROPY_STRING_LENGTH and looks_encoded(v)
    ]

    return {
        "file_entropy": shannon_entropy(source),
        "max_line_length": float(max(len(line) for line in lines)),
        "max_string_entropy": max((shannon_entropy(v) for v in long_literals), default=0.0),
        "identifier_count": float(len(identifiers)),
        "meaningless_ratio": len(meaningless) / len(identifiers) if identifiers else 0.0,
        "non_alpha_ratio": (
            sum(1 for c in source if not c.isalnum() and not c.isspace()) / len(source)
            if source
            else 0.0
        ),
    }


def _analyse_file(ctx: AnalysisContext, path: Path, source: str) -> list[tuple[int, str]]:
    rel = ctx.relpath(path)
    candidates: list[tuple[int, str]] = []

    for line, value in string_literals(source):
        if len(value) < MIN_ENTROPY_STRING_LENGTH or not looks_encoded(value):
            continue
        entropy = shannon_entropy(value)
        if entropy >= ENTROPY_THRESHOLD:
            ctx.flag(
                "obfuscation.high_entropy_string",
                path=rel,
                line=line,
                snippet=value[:80],
                entropy=round(entropy, 2),
                length=len(value),
            )
            candidates.append((line, value))

    long_lines = [
        i + 1 for i, line in enumerate(source.splitlines()) if len(line) > LONG_LINE_THRESHOLD
    ]
    if len(long_lines) >= MIN_LONG_LINES:
        ctx.flag(
            "obfuscation.long_single_line",
            path=rel,
            line=long_lines[0],
            snippet=f"{len(long_lines)} line(s) longer than {LONG_LINE_THRESHOLD} characters",
            count=len(long_lines),
        )

    identifiers = IDENTIFIER.findall(source)
    if len(identifiers) >= MIN_IDENTIFIERS:
        meaningless = [i for i in identifiers if MEANINGLESS_IDENTIFIER.match(i)]
        ratio = len(meaningless) / len(identifiers)
        if ratio >= MEANINGLESS_IDENTIFIER_RATIO:
            ctx.flag(
                "obfuscation.meaningless_identifiers",
                path=rel,
                snippet=f"{len(meaningless)} of {len(identifiers)} identifiers, e.g. "
                + ", ".join(sorted(set(meaningless))[:4]),
                ratio=round(ratio, 3),
            )

    index = _line_index(source)
    for match in CHARCODE_ARRAY.finditer(source):
        line = _line_at(index, match.start())
        codes = [int(n) for n in re.findall(r"\d{1,3}", match.group(0))]
        printable = sum(1 for c in codes if 32 <= c <= 126)
        if printable / len(codes) > 0.9:
            ctx.flag(
                "obfuscation.charcode_array",
                path=rel,
                line=line,
                snippet=match.group(0)[:80],
                length=len(codes),
            )
            candidates.append((line, "".join(chr(c) for c in codes)))

    return candidates


class ObfuscationAnalyzer:
    name = "obfuscation"

    def run(self, ctx: AnalysisContext) -> None:
        collected: list[tuple[str, int, str]] = []

        for path in ctx.package.source_files(ANALYSED_SUFFIXES):
            source = ctx.read_text(path)
            if source is None:
                continue
            rel = ctx.relpath(path)
            collected.extend((rel, line, value) for line, value in _analyse_file(ctx, path, source))

        # Handed to the deobfuscation module for the second-pass analysis.
        ctx.shared.setdefault("encoded_literals", []).extend(collected)
