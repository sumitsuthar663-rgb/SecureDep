"""Analyser orchestration and the public scanning entry points.

Order matters and is not incidental:

  1. install scripts   - records which files run at install time, which every
                         later analyser uses to weight what it finds
  2. metadata          - registry-level context
  3. Python / JS AST   - behavioural indicators, collecting encoded literals
  4. obfuscation       - statistical indicators, collecting more literals
  5. deobfuscation     - decodes what 3 and 4 collected and re-analyses it
  6. typosquatting     - name comparison, independent of file contents

Scoring runs once at the end over the complete finding set, because the
combination rules can only be evaluated when every analyser has finished.
"""

from __future__ import annotations

from pathlib import Path

from securedep.acquisition import AcquiredPackage, acquire, acquire_local
from securedep.analysis.ast_js import JavaScriptAstAnalyzer
from securedep.analysis.ast_python import PythonAstAnalyzer
from securedep.analysis.base import AnalysisContext, Analyzer
from securedep.analysis.deobfuscation import DeobfuscationAnalyzer
from securedep.analysis.install_scripts import InstallScriptAnalyzer
from securedep.analysis.metadata import MetadataAnalyzer
from securedep.analysis.obfuscation import ObfuscationAnalyzer
from securedep.analysis.typosquatting import TyposquattingAnalyzer
from securedep.models import PackageRef, ScanResult
from securedep.scoring.model import ScoreBreakdown, finalise


def DEFAULT_ANALYZERS(check_repository: bool = False) -> list[Analyzer]:
    return [
        InstallScriptAnalyzer(),
        MetadataAnalyzer(check_repository=check_repository),
        PythonAstAnalyzer(),
        JavaScriptAstAnalyzer(),
        ObfuscationAnalyzer(),
        DeobfuscationAnalyzer(),
        TyposquattingAnalyzer(),
    ]


class Engine:
    def __init__(self, analyzers: list[Analyzer] | None = None) -> None:
        self.analyzers = analyzers if analyzers is not None else DEFAULT_ANALYZERS()

    def analyse(self, acquired: AcquiredPackage) -> tuple[ScanResult, list[ScoreBreakdown]]:
        ctx = AnalysisContext(acquired.package)
        ctx.shared["release"] = acquired.release

        # An archive that tried to write outside its extraction directory is
        # not a parsing curiosity - it is an attack on whoever unpacks it.
        if acquired.extraction.had_traversal_attempt:
            for name, reason in acquired.extraction.skipped:
                if reason in ("path traversal", "absolute path"):
                    ctx.flag(
                        "archive.path_traversal",
                        path="<archive>",
                        snippet=f"{name} ({reason})",
                        entry=name,
                        reason=reason,
                    )

        for analyzer in self.analyzers:
            try:
                analyzer.run(ctx)
            except Exception as exc:  # keep one broken analyser from voiding the scan
                ctx.warn(f"analyser {analyzer.name!r} failed: {type(exc).__name__}: {exc}")

        result = ScanResult(
            ref=acquired.package.ref,
            findings=ctx.findings,
            warnings=ctx.warnings,
        )
        breakdown = finalise(result)
        return result, breakdown


def scan(
    ref: PackageRef,
    *,
    check_repository: bool = False,
    keep_files: Path | None = None,
) -> tuple[ScanResult, list[ScoreBreakdown]]:
    """Fetch, extract and analyse a package from its registry."""
    engine = Engine(DEFAULT_ANALYZERS(check_repository=check_repository))
    acquired = acquire(ref, workdir=keep_files, keep=keep_files is not None)
    try:
        return engine.analyse(acquired)
    finally:
        acquired.cleanup()


def scan_local(
    path: Path,
    ref: PackageRef,
    *,
    check_repository: bool = False,
) -> tuple[ScanResult, list[ScoreBreakdown]]:
    """Analyse an already-downloaded archive or extracted directory."""
    engine = Engine(DEFAULT_ANALYZERS(check_repository=check_repository))
    acquired = acquire_local(path, ref)
    try:
        return engine.analyse(acquired)
    finally:
        acquired.cleanup()
