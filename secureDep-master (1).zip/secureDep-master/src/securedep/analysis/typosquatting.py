"""Typosquatting detection (section 7.7).

Compares a candidate package name against a locally stored list of popular
package names using four complementary techniques:

  * Levenshtein distance - the minimum number of single-character insertions,
    deletions or substitutions needed to turn one name into the other.
  * Keyboard adjacency weighting - a substitution between physically adjacent
    keys is far more likely to be a genuine typing error than a distant one.
  * Structural variations - hyphen/underscore swaps and added or removed
    prefixes and suffixes such as ``-js``, ``python-`` or ``node-``.
  * Homoglyph detection - characters that are visually identical to ASCII
    letters but drawn from a different Unicode range.

Levenshtein is implemented here rather than pulled from a library. It is a
core algorithm of the project and its behaviour needs to be explainable in the
defence; the band-limited variant below also lets the search abandon
comparisons early, which is what makes scanning against 10,000 names fast.
"""

from __future__ import annotations

import re
import unicodedata
from functools import lru_cache
from importlib import resources
from pathlib import Path

from securedep.analysis.base import AnalysisContext
from securedep.models import Ecosystem

#: Names within this edit distance of a popular name are reported.
MAX_EDIT_DISTANCE = 2
#: Very short names produce false positives at distance 2 (``six`` vs `` six``
#: neighbours), so require an exact-ish match for them.
SHORT_NAME_LENGTH = 5

QWERTY_ROWS = (
    "`1234567890-=",
    " qwertyuiop[]\\",
    " asdfghjkl;'",
    " zxcvbnm,./",
)

COMMON_PREFIXES = ("python-", "python3-", "py", "node-", "js-", "npm-", "lib", "the")
COMMON_SUFFIXES = ("-js", ".js", "-py", "-python", "-node", "2", "3", "-cli", "-core", "-lib")

DIGIT_LETTER_SWAPS = {"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b"}


@lru_cache(maxsize=1)
def _keyboard_neighbours() -> dict[str, set[str]]:
    positions: dict[str, tuple[int, int]] = {}
    for r, row in enumerate(QWERTY_ROWS):
        for c, key in enumerate(row):
            if key != " ":
                positions[key] = (r, c)

    neighbours: dict[str, set[str]] = {}
    for key, (r, c) in positions.items():
        near = set()
        for other, (r2, c2) in positions.items():
            if other != key and abs(r - r2) <= 1 and abs(c - c2) <= 1:
                near.add(other)
        neighbours[key] = near
    return neighbours


def are_adjacent(a: str, b: str) -> bool:
    return b in _keyboard_neighbours().get(a, set())


def levenshtein(a: str, b: str, max_distance: int | None = None) -> int:
    """Edit distance between ``a`` and ``b``.

    Standard dynamic-programming formulation using a single rolling row. When
    ``max_distance`` is given, the computation abandons as soon as every value
    in the current row exceeds it and returns ``max_distance + 1`` - the caller
    only cares whether the names are close, not how far apart distant ones are.
    """
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)

    if max_distance is not None and abs(len(a) - len(b)) > max_distance:
        return max_distance + 1

    previous = list(range(len(b) + 1))

    for i, ca in enumerate(a, start=1):
        current = [i]
        for j, cb in enumerate(b, start=1):
            current.append(
                min(
                    previous[j] + 1,  # deletion
                    current[j - 1] + 1,  # insertion
                    previous[j - 1] + (ca != cb),  # substitution
                )
            )
        if max_distance is not None and min(current) > max_distance:
            return max_distance + 1
        previous = current

    return previous[-1]


def normalise(name: str, ecosystem: Ecosystem) -> str:
    """Canonical form for comparison.

    PyPI treats runs of ``-``, ``_`` and ``.`` as equivalent and is
    case-insensitive (PEP 503). npm names are already lowercase but may carry a
    scope, which is not part of the squattable name.
    """
    name = name.strip().lower()
    if ecosystem is Ecosystem.PYPI:
        return re.sub(r"[-_.]+", "-", name)
    if name.startswith("@") and "/" in name:
        return name.split("/", 1)[1]
    return name


def find_homoglyphs(name: str) -> list[tuple[str, str]]:
    """Non-ASCII characters that render like ASCII ones."""
    found: list[tuple[str, str]] = []
    for char in name:
        if char.isascii():
            continue
        decomposed = unicodedata.normalize("NFKD", char)
        ascii_form = "".join(c for c in decomposed if c.isascii() and c.isalnum())
        if ascii_form:
            found.append((char, ascii_form))
        else:
            # Cyrillic/Greek look-alikes do not decompose to ASCII, so compare
            # the character name instead: CYRILLIC SMALL LETTER A -> "a".
            try:
                unicode_name = unicodedata.name(char)
            except ValueError:
                continue
            match = re.search(r"\b(?:SMALL|CAPITAL) LETTER ([A-Z])\b", unicode_name)
            if match:
                found.append((char, match.group(1).lower()))
    return found


def structural_variants(name: str) -> set[str]:
    """Names this one could be a decorated form of."""
    variants: set[str] = set()

    collapsed = re.sub(r"[-_.]+", "", name)
    variants.add(collapsed)
    variants.add(re.sub(r"[-_.]+", "-", name))

    for prefix in COMMON_PREFIXES:
        if name.startswith(prefix) and len(name) > len(prefix) + 2:
            variants.add(name[len(prefix) :].lstrip("-_."))
    for suffix in COMMON_SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix) + 2:
            variants.add(name[: -len(suffix)].rstrip("-_."))

    # digit-for-letter substitution, e.g. cr0ss-env -> cross-env
    swapped = "".join(DIGIT_LETTER_SWAPS.get(c, c) for c in name)
    if swapped != name:
        variants.add(swapped)

    variants.discard(name)
    return {v for v in variants if len(v) > 2}


def load_popular(ecosystem: Ecosystem) -> set[str]:
    """Load the bundled popular-name list for an ecosystem."""
    filename = f"popular_{ecosystem.value}.txt"
    try:
        text = resources.files("securedep.data").joinpath(filename).read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError):
        local = Path(__file__).resolve().parent.parent / "data" / filename
        if not local.is_file():
            return set()
        text = local.read_text(encoding="utf-8")

    return {
        normalise(line, ecosystem)
        for line in text.splitlines()
        if line.strip() and not line.startswith("#")
    }


class TyposquattingAnalyzer:
    name = "typosquatting"

    def __init__(self, popular: set[str] | None = None) -> None:
        self._override = popular

    def run(self, ctx: AnalysisContext) -> None:
        ecosystem = ctx.package.ref.ecosystem
        raw_name = ctx.package.ref.name
        candidate = normalise(raw_name, ecosystem)

        popular = self._override if self._override is not None else load_popular(ecosystem)
        if not popular:
            ctx.warn(
                f"no popular-name list for {ecosystem.value}; typosquatting checks were skipped. "
                "Run scripts/fetch_popular_names.py to populate it."
            )
            return

        for char, looks_like in find_homoglyphs(raw_name):
            ctx.flag(
                "typosquat.homoglyph",
                path="<package name>",
                snippet=f"{raw_name!r} contains {unicodedata.name(char, f'U+{ord(char):04X}')} "
                f"which renders like {looks_like!r}",
                character=char,
                looks_like=looks_like,
            )

        # The package IS the popular one - nothing to compare against.
        if candidate in popular:
            return

        # Popular names indexed by their separator-free form, so that
        # "crossenv" is recognised as a variation of "cross-env" - the
        # separator is invisible to a hurried reader, which is the point.
        collapsed_popular: dict[str, str] = {}
        for known in popular:
            collapsed_popular.setdefault(re.sub(r"[-_.]+", "", known), known)

        structural_match: str | None = None
        collapsed_candidate = re.sub(r"[-_.]+", "", candidate)

        if collapsed_candidate in collapsed_popular:
            structural_match = collapsed_popular[collapsed_candidate]
        else:
            for variant in structural_variants(candidate):
                if variant in popular:
                    structural_match = variant
                    break
                collapsed_variant = re.sub(r"[-_.]+", "", variant)
                if collapsed_variant in collapsed_popular:
                    structural_match = collapsed_popular[collapsed_variant]
                    break

        if structural_match:
            ctx.flag(
                "typosquat.structural_variation",
                path="<package name>",
                snippet=f"{raw_name!r} is a structural variation of {structural_match!r}",
                imitates=structural_match,
            )

        best: tuple[int, str] | None = None
        for known in popular:
            distance = levenshtein(candidate, known, max_distance=MAX_EDIT_DISTANCE)
            if distance > MAX_EDIT_DISTANCE or distance == 0:
                continue
            if len(known) <= SHORT_NAME_LENGTH and distance > 1:
                continue
            if best is None or distance < best[0]:
                best = (distance, known)
            if distance == 1:
                break

        if best is None:
            return

        distance, imitated = best

        # Already reported as a structural variation of the same package -
        # counting it a second time would inflate the score for one imitation.
        if structural_match == imitated:
            return
        ctx.flag(
            "typosquat.near_popular_name",
            path="<package name>",
            snippet=f"{raw_name!r} is {distance} edit(s) from the popular package {imitated!r}",
            imitates=imitated,
            edit_distance=distance,
        )

        if distance == 1 and len(candidate) == len(imitated):
            for a, b in zip(candidate, imitated, strict=False):
                if a != b and are_adjacent(a, b):
                    ctx.flag(
                        "typosquat.keyboard_adjacent",
                        path="<package name>",
                        snippet=f"{a!r} and {b!r} are adjacent keys on a QWERTY keyboard",
                        substitution=[a, b],
                        imitates=imitated,
                    )
                    break
