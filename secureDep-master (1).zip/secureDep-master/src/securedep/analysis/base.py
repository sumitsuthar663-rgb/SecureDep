"""Shared plumbing for analysers (Stage 2).

Every analyser receives an :class:`AnalysisContext` and reports findings
through it. Analysers never compute scores and never decide a verdict - they
only observe behaviour. Scoring happens once, afterwards, in
``securedep.scoring.model``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from securedep.models import Evidence, ExtractedPackage, Finding

#: Files above this size are skipped by the source analysers. Real source files
#: are far smaller; anything larger is generated data or a bundled asset.
MAX_SOURCE_BYTES = 4 * 1024 * 1024

#: Cap the evidence retained per indicator. A minified file can produce
#: thousands of hits, which would bloat the report without adding information.
MAX_EVIDENCE_PER_INDICATOR = 25

#: Directories whose contents are shipped in the archive but are not the
#: package's runtime code. Source distributions routinely include test suites,
#: documentation builds and example servers, and those legitimately open
#: sockets, spawn processes and hardcode IP addresses. Scoring them like
#: installed code made urllib3 and requests look critical - the single largest
#: source of false positives observed while building this.
#:
#: They are still analysed, because malicious code does hide in a test
#: directory. Their findings are marked auxiliary, contribute a reduced weight,
#: and do not satisfy combination rules on their own.
AUXILIARY_DIRECTORIES = frozenset(
    {
        "test",
        "tests",
        "testing",
        "_test",
        "_tests",
        "spec",
        "specs",
        "docs",
        "doc",
        "documentation",
        "example",
        "examples",
        "sample",
        "samples",
        "demo",
        "demos",
        "benchmark",
        "benchmarks",
        "bench",
        "fixtures",
        "testdata",
        "dummyserver",
        "e2e",
        "integration_tests",
        "__tests__",
    }
)

#: Bundled third-party code. It is not the package's own logic, and vendored
#: build tooling routinely does things that look alarming out of context -
#: numpy ships a copy of meson whose dev-environment helper writes to .bashrc.
AUXILIARY_DIRECTORY_PREFIXES = ("vendor", "_vendor", "third_party", "3rdparty", "node_modules")

AUXILIARY_FILENAMES = frozenset({"conftest.py", "noxfile.py", "tox.ini", "setup.cfg"})


def is_auxiliary(relpath: str) -> bool:
    """True if a path is test, documentation, example or vendored code."""
    parts = relpath.replace("\\", "/").split("/")
    for part in parts[:-1]:
        lowered = part.lower()
        if lowered in AUXILIARY_DIRECTORIES:
            return True
        if lowered.startswith(AUXILIARY_DIRECTORY_PREFIXES):
            return True

    filename = parts[-1]
    if filename in AUXILIARY_FILENAMES:
        return True
    stem = filename.rsplit(".", 1)[0].lower()
    return stem.startswith("test_") or stem.endswith("_test") or stem.endswith(".test")


class AnalysisContext:
    def __init__(self, package: ExtractedPackage) -> None:
        self.package = package
        self._findings: dict[str, Finding] = {}
        self.warnings: list[str] = []
        #: Scratch space for analysers that need to pass information along the
        #: pipeline - e.g. the install-script detector recording which files
        #: run at install time, so the AST analyser can weight them.
        self.shared: dict[str, Any] = {}

    # -- reporting ---------------------------------------------------------

    def flag(
        self,
        indicator: str,
        *,
        path: str | Path | None = None,
        line: int | None = None,
        snippet: str = "",
        decoded: bool = False,
        **context: Any,
    ) -> Finding:
        finding = self._findings.get(indicator)
        if finding is None:
            finding = Finding(indicator=indicator)
            self._findings[indicator] = finding

        if context:
            finding.context.update(context)

        if path is not None:
            # Track the scope of *all* evidence, including evidence dropped by
            # the cap - otherwise a finding with 25 auxiliary hits followed by
            # one runtime hit would be misclassified.
            counts = finding.context.setdefault("evidence_counts", {"runtime": 0, "auxiliary": 0})
            key = "auxiliary" if is_auxiliary(str(path)) else "runtime"
            counts[key] += 1
            finding.context["evidence_scope"] = (
                "runtime"
                if counts["auxiliary"] == 0
                else "auxiliary"
                if counts["runtime"] == 0
                else "mixed"
            )

            if len(finding.evidence) < MAX_EVIDENCE_PER_INDICATOR:
                finding.add(
                    Evidence(
                        path=str(path),
                        line=line,
                        snippet=_trim(snippet),
                        decoded=decoded,
                    )
                )
        return finding

    def warn(self, message: str) -> None:
        if message not in self.warnings:
            self.warnings.append(message)

    @property
    def findings(self) -> list[Finding]:
        return list(self._findings.values())

    def fired(self, indicator: str) -> bool:
        return indicator in self._findings

    # -- file access -------------------------------------------------------

    def read_text(self, path: Path) -> str | None:
        """Read a source file, or None if it is unreadable or too large."""
        try:
            if path.stat().st_size > MAX_SOURCE_BYTES:
                self.warn(f"{self.package.relpath(path)} skipped: larger than analysis limit")
                return None
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            self.warn(f"{self.package.relpath(path)} unreadable: {exc}")
            return None

    def relpath(self, path: Path) -> str:
        return self.package.relpath(path)


@runtime_checkable
class Analyzer(Protocol):
    name: str

    def run(self, ctx: AnalysisContext) -> None: ...


def _trim(text: str, limit: int = 200) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def line_of(source: str, offset: int) -> int:
    return source.count("\n", 0, offset) + 1


def snippet_at(source: str, line: int) -> str:
    lines = source.splitlines()
    if 1 <= line <= len(lines):
        return _trim(lines[line - 1])
    return ""
