"""Python AST analyser (section 7.4).

Uses the standard library ``ast`` module rather than text search. The
difference matters: a package that writes ``getattr(os, 'sys' + 'tem')`` or
splits ``"ev" "al"`` across concatenation defeats grep, but the call structure
is still visible in the tree. Import aliases are resolved so that
``import subprocess as sp; sp.run(...)`` is recognised as subprocess use.

The analyser reports *behaviour*. It never decides whether that behaviour is
malicious - only the scoring model, working over combinations, does that.
"""

from __future__ import annotations

import ast
from pathlib import Path

from securedep.analysis import patterns
from securedep.analysis.base import AnalysisContext

# Fully-qualified names, after alias resolution.
DYNAMIC_EXEC = {
    "eval",
    "exec",
    "compile",
    "builtins.eval",
    "builtins.exec",
    "builtins.compile",
    "__import__",
    "builtins.__import__",
}

PROCESS_EXEC = {
    "os.system",
    "os.popen",
    "os.execv",
    "os.execve",
    "os.execvp",
    "os.execvpe",
    "os.execl",
    "os.execlp",
    "os.execle",
    "os.spawnv",
    "os.spawnve",
    "os.spawnl",
    "os.spawnlp",
    "os.startfile",
    "pty.spawn",
    "commands.getoutput",
    "commands.getstatusoutput",
    "popen2.popen2",
}

#: Any attribute access on these modules counts as process execution.
PROCESS_MODULES = {"subprocess"}

NETWORK_CALLS = {
    "urllib.request.urlopen",
    "urllib.request.urlretrieve",
    "urllib.urlopen",
    "urllib.urlretrieve",
    "webbrowser.open",
}

NETWORK_MODULES = {
    "requests",
    "httpx",
    "aiohttp",
    "urllib3",
    "http.client",
    "httplib",
    "ftplib",
    "smtplib",
    "telnetlib",
    "paramiko",
    "pycurl",
}

SOCKET_MODULES = {"socket"}

ENV_READS = {
    "os.environ",
    "os.getenv",
    "os.environ.get",
    "os.environb",
    "posix.environ",
}

BASE64_DECODE = {
    "base64.b64decode",
    "base64.standard_b64decode",
    "base64.urlsafe_b64decode",
    "base64.b32decode",
    "base64.b85decode",
    "base64.a85decode",
    "base64.decodebytes",
    "base64.decodestring",
}

HEX_DECODE = {
    "binascii.unhexlify",
    "binascii.a2b_hex",
    "binascii.a2b_base64",
    "bytes.fromhex",
    "bytearray.fromhex",
    "codecs.decode",
}

RECON_CALLS = {
    "socket.gethostname",
    "socket.getfqdn",
    "os.uname",
    "os.getlogin",
    "os.getuid",
    "os.geteuid",
    "getpass.getuser",
    "platform.node",
    "platform.system",
    "platform.release",
    "platform.platform",
    "platform.machine",
    "platform.processor",
    "platform.uname",
    "getmac.get_mac_address",
    "uuid.getnode",
}

WRITE_MODES = {"w", "wb", "a", "ab", "w+", "wb+", "a+", "ab+", "x", "xb"}


def _qualname(node: ast.AST) -> str | None:
    """Dotted name for a Name/Attribute chain, or None if it is not one."""
    parts: list[str] = []
    current = node
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if isinstance(current, ast.Name):
        parts.append(current.id)
        return ".".join(reversed(parts))
    return None


def _literal_str(node: ast.AST, constants: dict[str, str] | None = None) -> str | None:
    """Best-effort static value of a string expression.

    Folds concatenation and ``str.join`` of literals and resolves references to
    module-level string constants, so the common ``"ev" + "al"``,
    ``"".join(["o","s"])`` and ``PAYLOAD = "..."; b64decode(PAYLOAD)`` tricks do
    not hide the value.
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name) and constants:
        return constants.get(node.id)
    if isinstance(node, ast.JoinedStr):
        out = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                out.append(value.value)
        return "".join(out) if out else None
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _literal_str(node.left, constants)
        right = _literal_str(node.right, constants)
        if left is not None and right is not None:
            return left + right
    if isinstance(node, ast.Call):
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr == "join":
            sep = _literal_str(func.value, constants)
            if sep is not None and len(node.args) == 1:
                items = node.args[0]
                if isinstance(items, (ast.List, ast.Tuple)):
                    values = [_literal_str(e, constants) for e in items.elts]
                    if all(v is not None for v in values):
                        return sep.join(v for v in values if v is not None)
    return None


def _docstring_nodes(tree: ast.Module) -> set[int]:
    """Identify docstring literals so they are not analysed as data.

    A docstring is documentation, not a value the code acts on. Scanning them
    alongside real literals meant that prose such as "extract the cookies from
    the response" registered as credential access - a false positive on
    perfectly ordinary libraries.
    """
    nodes: set[int] = set()
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = getattr(node, "body", None)
        if not body:
            continue
        first = body[0]
        if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant):
            if isinstance(first.value.value, str):
                nodes.add(id(first.value))
    return nodes


def _collect_constants(tree: ast.Module) -> dict[str, str]:
    """Module-level ``NAME = "literal"`` assignments.

    Hoisting a payload into a constant and decoding it further down is one of
    the most common concealment patterns, and it defeats a purely local reading
    of the decode call's arguments.
    """
    constants: dict[str, str] = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        value = _literal_str(node.value)
        if value is None:
            continue
        for target in node.targets:
            if isinstance(target, ast.Name):
                constants[target.id] = value
    return constants


class _Visitor(ast.NodeVisitor):
    def __init__(
        self,
        ctx: AnalysisContext,
        path: Path,
        source: str,
        install_time: bool,
        constants: dict[str, str] | None = None,
        docstrings: set[int] | None = None,
    ) -> None:
        self.ctx = ctx
        self.path = ctx.relpath(path)
        self.source = source
        #: Split once. Re-splitting per finding made the analyser quadratic in
        #: file size, which stalled scans of large packages such as ansible.
        self.lines = source.splitlines()
        self.install_time = install_time
        #: local alias -> fully qualified module/attribute path
        self.aliases: dict[str, str] = {}
        #: module-level string constants, for resolving hoisted payloads
        self.constants: dict[str, str] = constants or {}
        #: ids of Constant nodes that are docstrings, skipped as documentation
        self.docstrings: set[int] = docstrings or set()
        #: Recorded for the deobfuscation module's second pass.
        self.encoded_literals: list[tuple[int, str]] = []

    # -- helpers -----------------------------------------------------------

    def _flag(self, indicator: str, node: ast.AST, **context) -> None:
        line = getattr(node, "lineno", None)
        snippet = ""
        if line and 0 < line <= len(self.lines):
            snippet = self.lines[line - 1].strip()
        if self.install_time:
            context.setdefault("install_time", True)
        self.ctx.flag(indicator, path=self.path, line=line, snippet=snippet, **context)

    def _resolve(self, dotted: str) -> str:
        head, _, rest = dotted.partition(".")
        if head in self.aliases:
            target = self.aliases[head]
            return f"{target}.{rest}" if rest else target
        return dotted

    def _root_module(self, dotted: str) -> str:
        resolved = self._resolve(dotted)
        for module in PROCESS_MODULES | NETWORK_MODULES | SOCKET_MODULES:
            if resolved == module or resolved.startswith(module + "."):
                return module
        return resolved.split(".", 1)[0]

    # -- imports -----------------------------------------------------------

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            if alias.asname:
                # `import os.path as p` binds `p` to os.path.
                self.aliases[alias.asname] = alias.name
            else:
                # `import urllib.request` binds only `urllib`, and it refers to
                # `urllib` - not to `urllib.request`. Mapping it to the full
                # dotted path would rewrite `urllib.request.urlopen` into
                # `urllib.request.request.urlopen` and miss the call entirely.
                head = alias.name.split(".")[0]
                self.aliases[head] = head
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        for alias in node.names:
            if alias.name == "*":
                continue
            self.aliases[alias.asname or alias.name] = (
                f"{module}.{alias.name}" if module else alias.name
            )
        self.generic_visit(node)

    # -- calls -------------------------------------------------------------

    def visit_Call(self, node: ast.Call) -> None:
        raw = _qualname(node.func)
        if raw is not None:
            self._check_call(node, self._resolve(raw), raw)

        # getattr(os, "system")(...) - the call target is itself a getattr call.
        if isinstance(node.func, ast.Call):
            inner = _qualname(node.func.func)
            if inner and self._resolve(inner) == "getattr" and len(node.func.args) == 2:
                obj = _qualname(node.func.args[0])
                attr = _literal_str(node.func.args[1], self.constants)
                if obj and attr:
                    self._check_call(node, self._resolve(f"{obj}.{attr}"), f"{obj}.{attr}")

        self.generic_visit(node)

    def _check_call(self, node: ast.Call, resolved: str, raw: str) -> None:
        module = self._root_module(raw)

        if resolved in DYNAMIC_EXEC:
            self._flag("exec.dynamic_evaluation", node, call=resolved)

        if resolved in PROCESS_EXEC or module in PROCESS_MODULES:
            self._flag("exec.subprocess", node, call=resolved)

        for keyword in node.keywords:
            if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant):
                if keyword.value.value is True:
                    self._flag("exec.shell_true", node, call=resolved)

        if resolved in NETWORK_CALLS or module in NETWORK_MODULES:
            self._flag("network.outbound_request", node, call=resolved)
        if module in SOCKET_MODULES:
            # socket.gethostname is reconnaissance, not a connection.
            if resolved in RECON_CALLS:
                self._flag("recon.system_fingerprint", node, call=resolved)
            else:
                self._flag("network.raw_socket", node, call=resolved)
                self._flag("network.outbound_request", node, call=resolved)

        if resolved in RECON_CALLS:
            self._flag("recon.system_fingerprint", node, call=resolved)

        if resolved in ENV_READS:
            self._flag("credentials.environment_read", node, call=resolved)

        if resolved in BASE64_DECODE:
            self._flag("encoding.base64_decode", node, call=resolved)
            for arg in node.args:
                value = _literal_str(arg, self.constants)
                if value:
                    self.encoded_literals.append((getattr(node, "lineno", 0), value))

        if resolved in HEX_DECODE:
            self._flag("encoding.hex_or_charcode", node, call=resolved)

        if resolved in ("open", "builtins.open", "io.open", "codecs.open"):
            self._check_open(node)

    def _check_open(self, node: ast.Call) -> None:
        mode = None
        if len(node.args) >= 2:
            mode = _literal_str(node.args[1], self.constants)
        for keyword in node.keywords:
            if keyword.arg == "mode":
                mode = _literal_str(keyword.value, self.constants)

        target = _literal_str(node.args[0], self.constants) if node.args else None
        if mode and mode in WRITE_MODES and target:
            if target.startswith(("/", "~")) or "\\" in target:
                self._flag("persistence.file_write_outside_package", node, target=target)

    # -- attribute reads ---------------------------------------------------

    def visit_Attribute(self, node: ast.Attribute) -> None:
        dotted = _qualname(node)
        if dotted:
            resolved = self._resolve(dotted)
            if resolved in ENV_READS:
                self._flag("credentials.environment_read", node, read=resolved)
            elif resolved in RECON_CALLS:
                self._flag("recon.system_fingerprint", node, read=resolved)
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        resolved = self._resolve(node.id)
        if resolved in ENV_READS:
            self._flag("credentials.environment_read", node, read=resolved)
        self.generic_visit(node)

    # -- string literals ---------------------------------------------------

    def visit_Constant(self, node: ast.Constant) -> None:
        if not isinstance(node.value, str) or not node.value or id(node) in self.docstrings:
            self.generic_visit(node)
            return

        text = node.value

        if patterns.SENSITIVE_PATHS.search(text):
            self._flag("credentials.sensitive_path", node, value=text[:120])
        if patterns.KEYCHAIN_TOKENS.search(text):
            self._flag("credentials.keychain_access", node, value=text[:120])
        if patterns.PERSISTENCE_TARGETS.search(text):
            self._flag("persistence.startup_modification", node, value=text[:120])
        if patterns.RECON_TOKENS.search(text):
            self._flag("recon.system_fingerprint", node, value=text[:120])
        for indicator in patterns.classify_destination(text):
            self._flag(indicator, node, value=text[:120])

        self.generic_visit(node)

    # -- character-code reconstruction ------------------------------------

    def visit_List(self, node: ast.List) -> None:
        self._check_charcode_array(node, node.elts)
        self.generic_visit(node)

    def visit_Tuple(self, node: ast.Tuple) -> None:
        self._check_charcode_array(node, node.elts)
        self.generic_visit(node)

    def _check_charcode_array(self, node: ast.AST, elements: list[ast.expr]) -> None:
        if len(elements) < 12:
            return
        codes = [
            e.value
            for e in elements
            if isinstance(e, ast.Constant)
            and isinstance(e.value, int)
            and not isinstance(e.value, bool)
        ]
        if len(codes) != len(elements):
            return
        printable = sum(1 for c in codes if 32 <= c <= 126)
        if printable / len(codes) > 0.9:
            decoded = "".join(chr(c) for c in codes if 0 <= c < 0x110000)
            self._flag("obfuscation.charcode_array", node, length=len(codes))
            self.encoded_literals.append((getattr(node, "lineno", 0), decoded))


def analyse_python_source(
    ctx: AnalysisContext,
    path: Path,
    source: str,
    install_time: bool = False,
) -> list[tuple[int, str]]:
    """Analyse one Python file. Returns literals worth a deobfuscation pass."""
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        ctx.warn(f"{ctx.relpath(path)} did not parse as Python: {exc.msg} (line {exc.lineno})")
        return []
    except (ValueError, RecursionError) as exc:
        ctx.warn(f"{ctx.relpath(path)} could not be analysed: {exc}")
        return []

    visitor = _Visitor(
        ctx,
        path,
        source,
        install_time,
        constants=_collect_constants(tree),
        docstrings=_docstring_nodes(tree),
    )
    visitor.visit(tree)
    return visitor.encoded_literals


class PythonAstAnalyzer:
    name = "python-ast"

    def run(self, ctx: AnalysisContext) -> None:
        install_files: set[str] = ctx.shared.get("install_time_files", set())
        encoded: list[tuple[str, int, str]] = []

        for path in ctx.package.source_files((".py", ".pyw")):
            source = ctx.read_text(path)
            if source is None:
                continue
            rel = ctx.relpath(path)
            literals = analyse_python_source(ctx, path, source, install_time=rel in install_files)
            encoded.extend((rel, line, value) for line, value in literals)

        ctx.shared.setdefault("encoded_literals", []).extend(encoded)
