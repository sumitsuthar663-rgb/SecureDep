"""Stage 2 - the static analysis engine.

This package contains all detection logic. It is entirely deterministic and
hand-written: no model is consulted, and the same package always produces the
same findings. Stages 3 and 4 (AI explanation, MCP) sit strictly on top of it
and can be removed without affecting any verdict.
"""

from securedep.analysis.base import AnalysisContext, Analyzer
from securedep.analysis.engine import DEFAULT_ANALYZERS, Engine, scan, scan_local

__all__ = [
    "AnalysisContext",
    "Analyzer",
    "DEFAULT_ANALYZERS",
    "Engine",
    "scan",
    "scan_local",
]
