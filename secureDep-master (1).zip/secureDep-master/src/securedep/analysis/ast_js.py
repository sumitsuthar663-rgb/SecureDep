"""JavaScript AST analyser (section 7.4).

Uses tree-sitter rather than the ``esprima-python`` parser named in the
original project document. The reason is recall, and it is worth stating in
the defence: esprima-python is an unmaintained port of Esprima 4 (roughly
ES2017) and raises on syntax it does not recognise. Malicious npm packages are
disproportionately minified, obfuscated or written against newer syntax -
precisely the cases where a parse failure would mean zero indicators fire on
the most suspicious samples in the corpus.

tree-sitter is error-tolerant: it produces a usable tree even for input it
cannot fully parse, so a partially-broken file still yields findings. Files
that fail outright are recorded as warnings so a clean result is never
silently based on unanalysed code.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

from securedep.analysis import patterns
from securedep.analysis.base import AnalysisContext

DYNAMIC_EXEC_NAMES = {"eval", "Function", "execScript"}

PROCESS_MODULES = {"child_process", "node:child_process"}
PROCESS_METHODS = {"exec", "execSync", "execFile", "execFileSync", "spawn", "spawnSync", "fork"}

NETWORK_MODULES = {
    "http",
    "https",
    "node:http",
    "node:https",
    "axios",
    "node-fetch",
    "got",
    "request",
    "superagent",
    "undici",
    "needle",
    "phin",
}
SOCKET_MODULES = {"net", "node:net", "dgram", "node:dgram", "tls", "node:tls"}
FS_MODULES = {"fs", "node:fs", "fs/promises", "node:fs/promises"}
OS_MODULES = {"os", "node:os"}

GLOBAL_NETWORK = {"fetch", "XMLHttpRequest", "WebSocket"}

RECON_METHODS = {
    "hostname",
    "userInfo",
    "networkInterfaces",
    "homedir",
    "platform",
    "release",
    "arch",
    "type",
    "cpus",
    "totalmem",
}

READ_METHODS = {"readFile", "readFileSync", "createReadStream", "readdir", "readdirSync"}
WRITE_METHODS = {"writeFile", "writeFileSync", "appendFile", "appendFileSync", "createWriteStream"}

SUFFIXES = (".js", ".cjs", ".mjs", ".jsx", ".ts", ".tsx")


class ParserUnavailable(RuntimeError):
    pass


@lru_cache(maxsize=1)
def _parser() -> Any:
    try:
        import tree_sitter_javascript as ts_javascript
        from tree_sitter import Language, Parser
    except ImportError as exc:  # pragma: no cover - dependency missing
        raise ParserUnavailable(
            "tree-sitter and tree-sitter-javascript are required for JavaScript analysis"
        ) from exc

    language = Language(ts_javascript.language())
    try:
        return Parser(language)
    except TypeError:  # pragma: no cover - older tree-sitter API
        parser = Parser()
        parser.language = language
        return parser


def _text(node: Any, source: bytes) -> str:
    return source[node.start_byte : node.end_byte].decode("utf-8", errors="replace")


def _dotted(node: Any, source: bytes) -> str | None:
    """Dotted name for an identifier or member_expression chain."""
    if node.type == "identifier":
        return _text(node, source)
    if node.type == "member_expression":
        obj = node.child_by_field_name("object")
        prop = node.child_by_field_name("property")
        if obj is None or prop is None:
            return None
        base = _dotted(obj, source)
        if base is None:
            return None
        return f"{base}.{_text(prop, source)}"
    return None


def _string_value(node: Any, source: bytes) -> str | None:
    if node.type in ("string", "template_string"):
        raw = _text(node, source)
        return raw[1:-1] if len(raw) >= 2 else ""
    return None


class _Walker:
    def __init__(self, ctx: AnalysisContext, path: Path, source: str, install_time: bool) -> None:
        self.ctx = ctx
        self.path = ctx.relpath(path)
        self.source = source
        #: Split once - see the note in ast_python._Visitor.
        self.lines = source.splitlines()
        self.data = source.encode("utf-8")
        self.install_time = install_time
        #: local binding -> module name, from require() and import statements
        self.modules: dict[str, str] = {}
        self.encoded_literals: list[tuple[int, str]] = []

    def _flag(self, indicator: str, node: Any, **context) -> None:
        line = node.start_point[0] + 1
        snippet = self.lines[line - 1].strip() if 0 < line <= len(self.lines) else ""
        if self.install_time:
            context.setdefault("install_time", True)
        self.ctx.flag(indicator, path=self.path, line=line, snippet=snippet, **context)

    def _module_of(self, dotted: str) -> str | None:
        head = dotted.split(".", 1)[0]
        return self.modules.get(head)

    # -- module bindings ---------------------------------------------------

    def _record_require(self, node: Any) -> None:
        """const cp = require('child_process')  /  const {exec} = require(...)"""
        func = node.child_by_field_name("function")
        if func is None or _text(func, self.data) != "require":
            return
        args = node.child_by_field_name("arguments")
        if args is None:
            return
        module = next(
            (
                _string_value(c, self.data)
                for c in args.named_children
                if _string_value(c, self.data)
            ),
            None,
        )
        if module is None:
            return

        declarator = node.parent
        while declarator is not None and declarator.type not in (
            "variable_declarator",
            "assignment_expression",
        ):
            declarator = declarator.parent
        if declarator is None:
            return

        name_node = declarator.child_by_field_name("name") or declarator.child_by_field_name("left")
        if name_node is None:
            return

        if name_node.type == "identifier":
            self.modules[_text(name_node, self.data)] = module
        elif name_node.type == "object_pattern":
            # Destructured: bind each name directly to the module so that a
            # call to the bare name still resolves.
            for child in name_node.named_children:
                target = child.child_by_field_name("value") or child
                if target.type in ("identifier", "shorthand_property_identifier_pattern"):
                    self.modules[_text(target, self.data)] = module

    def _record_import(self, node: Any) -> None:
        source_node = node.child_by_field_name("source")
        if source_node is None:
            return
        module = _string_value(source_node, self.data)
        if module is None:
            return
        for child in node.named_children:
            if child.type != "import_clause":
                continue
            for binding in child.named_children:
                if binding.type == "identifier":
                    self.modules[_text(binding, self.data)] = module
                elif binding.type in ("named_imports", "namespace_import"):
                    for spec in binding.named_children:
                        target = spec.child_by_field_name("alias") or spec
                        if target.type == "identifier":
                            self.modules[_text(target, self.data)] = module

    # -- walking -----------------------------------------------------------

    def walk(self, node: Any) -> None:
        handler = getattr(self, f"_on_{node.type}", None)
        if handler is not None:
            handler(node)
        for child in node.children:
            self.walk(child)

    def _on_import_statement(self, node: Any) -> None:
        self._record_import(node)

    def _on_call_expression(self, node: Any) -> None:
        self._record_require(node)

        func = node.child_by_field_name("function")
        if func is None:
            return
        dotted = _dotted(func, self.data)
        if dotted is None:
            return

        leaf = dotted.rsplit(".", 1)[-1]
        module = self._module_of(dotted)

        if dotted in DYNAMIC_EXEC_NAMES or leaf in DYNAMIC_EXEC_NAMES:
            self._flag("exec.dynamic_evaluation", node, call=dotted)

        # setTimeout("code string", n) evaluates the string.
        if leaf in ("setTimeout", "setInterval"):
            args = node.child_by_field_name("arguments")
            if args and args.named_children and _string_value(args.named_children[0], self.data):
                self._flag("exec.dynamic_evaluation", node, call=f"{leaf}(string)")

        if module in PROCESS_MODULES or (module in PROCESS_MODULES and leaf in PROCESS_METHODS):
            self._flag("exec.subprocess", node, call=dotted)
            if leaf in ("exec", "execSync"):
                self._flag("exec.shell_true", node, call=dotted)

        if module in NETWORK_MODULES or dotted in GLOBAL_NETWORK or leaf in GLOBAL_NETWORK:
            self._flag("network.outbound_request", node, call=dotted)
        if module in SOCKET_MODULES:
            self._flag("network.raw_socket", node, call=dotted)
            self._flag("network.outbound_request", node, call=dotted)

        if module in OS_MODULES and leaf in RECON_METHODS:
            self._flag("recon.system_fingerprint", node, call=dotted)

        if module in FS_MODULES and leaf in READ_METHODS:
            args = node.child_by_field_name("arguments")
            if args:
                for child in args.named_children:
                    value = _string_value(child, self.data)
                    if value and patterns.SENSITIVE_PATHS.search(value):
                        self._flag("credentials.sensitive_path", node, target=value[:120])

        if module in FS_MODULES and leaf in WRITE_METHODS:
            args = node.child_by_field_name("arguments")
            if args:
                for child in args.named_children:
                    value = _string_value(child, self.data)
                    if value and patterns.PERSISTENCE_TARGETS.search(value):
                        self._flag("persistence.startup_modification", node, target=value[:120])
                    elif value and (value.startswith(("/", "~")) or "\\" in value):
                        self._flag(
                            "persistence.file_write_outside_package", node, target=value[:120]
                        )

        if dotted in ("Buffer.from", "atob") or leaf == "atob":
            args = node.child_by_field_name("arguments")
            encoding = None
            literal = None
            if args:
                values = [_string_value(c, self.data) for c in args.named_children]
                literal = values[0] if values else None
                encoding = values[1] if len(values) > 1 else None
            if leaf == "atob" or encoding == "base64":
                self._flag("encoding.base64_decode", node, call=dotted)
                if literal:
                    self.encoded_literals.append((node.start_point[0] + 1, literal))

        if dotted == "String.fromCharCode" or leaf == "fromCharCode":
            self._flag("encoding.hex_or_charcode", node, call=dotted)

        if leaf in ("unescape", "decodeURIComponent") and dotted in (
            "unescape",
            "decodeURIComponent",
        ):
            self._flag("encoding.hex_or_charcode", node, call=dotted)

    def _on_new_expression(self, node: Any) -> None:
        constructor = node.child_by_field_name("constructor")
        if constructor is None:
            return
        name = _dotted(constructor, self.data)
        if name in DYNAMIC_EXEC_NAMES:
            self._flag("exec.dynamic_evaluation", node, call=f"new {name}")
        if name in GLOBAL_NETWORK:
            self._flag("network.outbound_request", node, call=f"new {name}")

    def _on_member_expression(self, node: Any) -> None:
        dotted = _dotted(node, self.data)
        if dotted is None:
            return
        if dotted.startswith("process.env"):
            self._flag("credentials.environment_read", node, read=dotted)
        elif dotted in ("process.platform", "process.arch", "process.version", "process.cwd"):
            self._flag("recon.system_fingerprint", node, read=dotted)

        module = self._module_of(dotted)
        leaf = dotted.rsplit(".", 1)[-1]
        if module in OS_MODULES and leaf in RECON_METHODS:
            self._flag("recon.system_fingerprint", node, read=dotted)

    def _on_string(self, node: Any) -> None:
        self._check_literal(node)

    def _on_template_string(self, node: Any) -> None:
        self._check_literal(node)

    def _check_literal(self, node: Any) -> None:
        value = _string_value(node, self.data)
        if not value:
            return
        if patterns.SENSITIVE_PATHS.search(value):
            self._flag("credentials.sensitive_path", node, value=value[:120])
        if patterns.KEYCHAIN_TOKENS.search(value):
            self._flag("credentials.keychain_access", node, value=value[:120])
        if patterns.PERSISTENCE_TARGETS.search(value):
            self._flag("persistence.startup_modification", node, value=value[:120])
        if patterns.RECON_TOKENS.search(value):
            self._flag("recon.system_fingerprint", node, value=value[:120])
        for indicator in patterns.classify_destination(value):
            self._flag(indicator, node, value=value[:120])


def analyse_javascript_source(
    ctx: AnalysisContext,
    path: Path,
    source: str,
    install_time: bool = False,
) -> list[tuple[int, str]]:
    try:
        parser = _parser()
    except ParserUnavailable as exc:
        ctx.warn(str(exc))
        return []

    tree = parser.parse(source.encode("utf-8"))
    if tree.root_node.has_error:
        # Not fatal - tree-sitter still produced a tree, and this is exactly
        # the case where a strict parser would have given up entirely.
        ctx.warn(f"{ctx.relpath(path)} contains syntax tree-sitter could not fully parse")

    walker = _Walker(ctx, path, source, install_time)
    walker.walk(tree.root_node)
    return walker.encoded_literals


class JavaScriptAstAnalyzer:
    name = "javascript-ast"

    def run(self, ctx: AnalysisContext) -> None:
        install_files: set[str] = ctx.shared.get("install_time_files", set())
        encoded: list[tuple[str, int, str]] = []

        for path in ctx.package.source_files(SUFFIXES):
            source = ctx.read_text(path)
            if source is None:
                continue
            rel = ctx.relpath(path)
            literals = analyse_javascript_source(
                ctx, path, source, install_time=rel in install_files
            )
            encoded.extend((rel, line, value) for line, value in literals)

        ctx.shared.setdefault("encoded_literals", []).extend(encoded)
