"""Metadata analyser (section 7.2).

Malicious packages are typically newly created, have a single version, lack a
genuine repository link, and contain very little legitimate functionality.
None of these is damning on its own - a brand new, honest, single-version
utility looks identical - which is exactly why every indicator here is marked
`contextual` and carries a low weight. Their value is as corroboration inside
the combination rules.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from securedep.acquisition.registry import repository_exists
from securedep.analysis.base import AnalysisContext
from securedep.models import Ecosystem

RECENT_DAYS = 30

#: Below this many bytes of source, a package has essentially no functionality.
TRIVIAL_CODE_BYTES = 1024
SOURCE_SUFFIXES = (".py", ".js", ".cjs", ".mjs", ".ts", ".jsx", ".tsx")


def _first(manifest: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = manifest.get(key)
        if value:
            return value
    return None


def _repository_url(ctx: AnalysisContext) -> str | None:
    manifest = ctx.package.manifest

    if ctx.package.ref.ecosystem is Ecosystem.NPM:
        repository = manifest.get("repository")
        if isinstance(repository, str):
            return repository
        if isinstance(repository, dict):
            return repository.get("url")
        return _first(manifest, "homepage", "bugs")

    url = _first(manifest, "home_page", "project_url", "download_url")
    if url and url != "UNKNOWN":
        return str(url)

    info = ctx.package.registry_metadata.get("info", {})
    project_urls = info.get("project_urls") or {}
    for key, value in project_urls.items():
        if any(
            token in key.lower() for token in ("source", "repository", "github", "code", "home")
        ):
            return value
    home = info.get("home_page")
    return home if home and home != "UNKNOWN" else None


def _license(ctx: AnalysisContext) -> str | None:
    manifest = ctx.package.manifest
    if ctx.package.ref.ecosystem is Ecosystem.NPM:
        value = manifest.get("license") or manifest.get("licenses")
        return str(value) if value else None

    value = _first(manifest, "license")
    if value and value != "UNKNOWN":
        return str(value)
    info = ctx.package.registry_metadata.get("info", {})
    if info.get("license"):
        return str(info["license"])
    classifiers = info.get("classifiers") or []
    if any(c.startswith("License ::") for c in classifiers):
        return "declared via classifier"
    if any(
        (ctx.package.root / n).is_file()
        for n in ("LICENSE", "LICENSE.txt", "LICENSE.md", "COPYING")
    ):
        return "licence file present"
    return None


class MetadataAnalyzer:
    name = "metadata"

    def __init__(self, check_repository: bool = False) -> None:
        #: Verifying that a declared repository actually resolves costs one
        #: network request per scan, so it is opt-in.
        self.check_repository = check_repository

    def run(self, ctx: AnalysisContext) -> None:
        release = ctx.shared.get("release")
        now = datetime.now(timezone.utc)

        if release is not None:
            if release.version_count <= 1:
                ctx.flag(
                    "metadata.single_version",
                    path="<registry metadata>",
                    snippet=f"{release.version_count} published version",
                    version_count=release.version_count,
                )

            first = release.first_published
            if first is not None and now - first < timedelta(days=RECENT_DAYS):
                age = (now - first).days
                ctx.flag(
                    "metadata.recently_published",
                    path="<registry metadata>",
                    snippet=f"first published {age} day(s) ago",
                    age_days=age,
                )
        else:
            ctx.warn(
                "no registry metadata available; age and version indicators were not evaluated"
            )

        repository = _repository_url(ctx)
        if not repository:
            ctx.flag(
                "metadata.no_repository",
                path="<package manifest>",
                snippet="no repository or homepage URL declared",
            )
        elif self.check_repository and not repository_exists(str(repository)):
            ctx.flag(
                "metadata.no_repository",
                path="<package manifest>",
                snippet=f"declared repository does not resolve: {repository}",
                declared=str(repository),
                resolves=False,
            )

        if not _license(ctx):
            ctx.flag(
                "metadata.no_license",
                path="<package manifest>",
                snippet="no licence declared",
            )

        code_bytes = 0
        code_files = 0
        for path in ctx.package.source_files(SOURCE_SUFFIXES):
            if path.name == "setup.py":
                continue
            try:
                code_bytes += path.stat().st_size
                code_files += 1
            except OSError:
                continue

        if code_bytes < TRIVIAL_CODE_BYTES:
            ctx.flag(
                "metadata.trivial_codebase",
                path="<package contents>",
                snippet=f"{code_files} source file(s), {code_bytes} bytes of code",
                code_bytes=code_bytes,
                code_files=code_files,
            )

        ctx.shared["code_bytes"] = code_bytes
