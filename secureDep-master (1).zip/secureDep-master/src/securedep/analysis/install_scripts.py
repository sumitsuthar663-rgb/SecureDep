"""Install hook detection (section 7.3).

The strongest single indicator available. Legitimate pure-Python and
pure-JavaScript packages have almost no reason to execute anything during
installation, while the great majority of malicious packages depend on it -
that is how the payload runs before the developer has used the package at all.

For npm this is a declarative read of ``package.json``. For PyPI it requires
analysing ``setup.py`` as source, because setup.py *is* executable code and
must never be run to find out what it does.
"""

from __future__ import annotations

import ast
from pathlib import Path

from securedep.analysis.base import AnalysisContext
from securedep.models import Ecosystem

NPM_INSTALL_HOOKS = ("preinstall", "install", "postinstall")
#: Hooks that also run automatically, though later than install.
NPM_SECONDARY_HOOKS = ("prepare", "prepublish", "prepack", "postpack")

#: setuptools commands whose override runs during a normal install.
INSTALL_COMMANDS = {
    "install",
    "develop",
    "egg_info",
    "build_py",
    "build_ext",
    "bdist_wheel",
    "sdist",
}

#: Shell/interpreter invocations inside a hook, indicating it does more than
#: compile a native component.
EXTERNAL_COMMAND_TOKENS = (
    "curl ",
    "wget ",
    "bash ",
    "sh -c",
    "powershell",
    "cmd /c",
    "cmd.exe",
    "certutil",
    "nc ",
    "python -c",
    "python3 -c",
    "node -e",
    "node -p",
    "eval ",
    "|sh",
    "| sh",
    "|bash",
    "| bash",
    "base64 -d",
    "chmod +x",
    "&&",
    ";",
)


def _npm(ctx: AnalysisContext) -> set[str]:
    manifest = ctx.package.manifest
    scripts = manifest.get("scripts")
    if not isinstance(scripts, dict):
        return set()

    install_time: set[str] = set()

    for hook in NPM_INSTALL_HOOKS + NPM_SECONDARY_HOOKS:
        command = scripts.get(hook)
        if not isinstance(command, str) or not command.strip():
            continue

        primary = hook in NPM_INSTALL_HOOKS
        if primary:
            ctx.flag(
                "install.hook_present",
                install_time=True,
                path="package.json",
                snippet=f'"{hook}": "{command}"',
                hook=hook,
                command=command,
            )

        lowered = command.lower()
        if any(token in lowered for token in EXTERNAL_COMMAND_TOKENS):
            ctx.flag(
                "install.hook_runs_external_command",
                install_time=True,
                path="package.json",
                snippet=f'"{hook}": "{command}"',
                hook=hook,
            )

        # `node foo.js` / `sh ./bar.sh` - the referenced file runs at install
        # time, so the AST analyser should treat it as install-time code.
        for token in command.replace("&&", " ").replace(";", " ").split():
            candidate = token.strip("\"'")
            if candidate.endswith((".js", ".cjs", ".mjs", ".py", ".sh")):
                candidate = candidate.lstrip("./")
                if (ctx.package.root / candidate).is_file():
                    install_time.add(candidate)

    return install_time


def _analyse_setup_py(ctx: AnalysisContext, path: Path, source: str) -> None:
    """Find executable logic in setup.py without executing it."""
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        ctx.warn(f"setup.py did not parse: {exc.msg} (line {exc.lineno})")
        # A setup.py that will not parse is itself worth noting: it still runs
        # under the installing interpreter, which may accept what we cannot.
        ctx.flag(
            "install.hook_present",
            install_time=True,
            path=ctx.relpath(path),
            snippet="setup.py (unparseable)",
        )
        return

    rel = ctx.relpath(path)
    has_side_effects = False

    for node in tree.body:
        # Imports, constants, function/class definitions and the setup() call
        # itself are the normal contents of a setup.py.
        if isinstance(
            node, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.ClassDef, ast.Assign)
        ):
            continue
        if isinstance(node, ast.If):
            # `if __name__ == "__main__": setup(...)` is idiomatic.
            continue
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            func = node.value.func
            name = getattr(func, "id", None) or getattr(func, "attr", None)
            if name in ("setup", "setuptools.setup"):
                continue
            has_side_effects = True
            ctx.flag(
                "install.hook_present",
                install_time=True,
                path=rel,
                line=node.lineno,
                snippet=f"top-level call to {name}() in setup.py",
                reason="top-level call",
            )

    # cmdclass={"install": MyInstall} overrides installation behaviour.
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        for keyword in node.keywords:
            if keyword.arg != "cmdclass":
                continue
            overridden = []
            if isinstance(keyword.value, ast.Dict):
                for key in keyword.value.keys:
                    if isinstance(key, ast.Constant) and isinstance(key.value, str):
                        overridden.append(key.value)
            relevant = [c for c in overridden if c in INSTALL_COMMANDS]
            if relevant:
                ctx.flag(
                    "install.custom_command_class",
                    install_time=True,
                    path=rel,
                    line=node.lineno,
                    snippet=f"cmdclass overrides {', '.join(sorted(relevant))}",
                    commands=sorted(relevant),
                )
                ctx.flag(
                    "install.hook_present",
                    install_time=True,
                    path=rel,
                    line=node.lineno,
                    reason="cmdclass",
                )
                has_side_effects = True

    # A custom command class whose run() does more than call super().
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        for item in node.body:
            if isinstance(item, ast.FunctionDef) and item.name in ("run", "finalize_options"):
                for inner in ast.walk(item):
                    if isinstance(inner, ast.Call):
                        callee = getattr(inner.func, "attr", None) or getattr(
                            inner.func, "id", None
                        )
                        if callee in ("run", "__init__", "super"):
                            continue
                        ctx.flag(
                            "install.hook_present",
                            install_time=True,
                            path=rel,
                            line=item.lineno,
                            snippet=f"{node.name}.{item.name}() performs additional work",
                            reason="custom command class body",
                        )
                        has_side_effects = True
                        break

    if not has_side_effects:
        return


def _pypi(ctx: AnalysisContext) -> set[str]:
    install_time: set[str] = set()

    setup_py = ctx.package.root / "setup.py"
    if setup_py.is_file():
        source = ctx.read_text(setup_py)
        if source is not None:
            install_time.add("setup.py")
            _analyse_setup_py(ctx, setup_py, source)

    # PEP 517 in-tree build backends also execute at install time.
    for name in ("build.py", "_build.py", "conftest.py"):
        candidate = ctx.package.root / name
        if candidate.is_file() and name != "conftest.py":
            install_time.add(name)

    return install_time


class InstallScriptAnalyzer:
    name = "install-scripts"

    def run(self, ctx: AnalysisContext) -> None:
        if ctx.package.ref.ecosystem is Ecosystem.NPM:
            install_time = _npm(ctx)
        else:
            install_time = _pypi(ctx)

        # Consumed by the AST analysers so that behaviour found in install-time
        # code can be weighted through the combination rules.
        ctx.shared["install_time_files"] = install_time
