"""Report rendering.

Two formats: a human-readable terminal report and structured JSON. The JSON
form is what the evaluation harness and the MCP interface consume, so it is
the canonical output; the text form is a rendering of the same data.
"""

from securedep.reporting.json_report import to_json
from securedep.reporting.text_report import render_text

__all__ = ["render_text", "to_json"]
