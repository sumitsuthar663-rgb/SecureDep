"""Human-readable terminal report.

The report always lists which indicators fired and why. A score on its own is
not actionable, and interpretability is a stated objective of the project.
"""

from __future__ import annotations

import os
import sys

from securedep.models import RiskBand, ScanResult
from securedep.scoring.indicators import COMBINATIONS, INDICATORS
from securedep.scoring.model import ScoreBreakdown

BAND_LABEL = {
    RiskBand.LOW: "LOW",
    RiskBand.MEDIUM: "MEDIUM",
    RiskBand.HIGH: "HIGH",
    RiskBand.CRITICAL: "CRITICAL",
}

_ANSI = {
    RiskBand.LOW: "\033[32m",
    RiskBand.MEDIUM: "\033[33m",
    RiskBand.HIGH: "\033[31m",
    RiskBand.CRITICAL: "\033[1;37;41m",
}
_RESET = "\033[0m"
_DIM = "\033[2m"
_BOLD = "\033[1m"


def _use_colour(stream) -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return hasattr(stream, "isatty") and stream.isatty()


def render_text(
    result: ScanResult,
    breakdown: list[ScoreBreakdown] | None = None,
    *,
    verbose: bool = False,
    stream=None,
) -> str:
    colour = _use_colour(stream if stream is not None else sys.stdout)

    def c(text: str, code: str) -> str:
        return f"{code}{text}{_RESET}" if colour else text

    combos = {rule.id: rule for rule in COMBINATIONS}
    lines: list[str] = []

    header = f"SecureDep scan - {result.ref}"
    lines.append(c(header, _BOLD))
    lines.append("=" * len(header))
    lines.append("")

    band = BAND_LABEL[result.band]
    lines.append(f"  Risk: {c(band, _ANSI[result.band])}   Score: {result.score:.1f}")
    lines.append("")

    if not result.findings:
        lines.append("  No indicators fired.")
    else:
        # Combination findings first: they are the engine's actual reasoning.
        combo_findings = [f for f in result.findings if f.indicator in combos]
        plain = [f for f in result.findings if f.indicator not in combos]
        plain.sort(
            key=lambda f: -(INDICATORS[f.indicator].weight if f.indicator in INDICATORS else 0.0)
        )

        if combo_findings:
            lines.append(c("  Behaviour combinations", _BOLD))
            for finding in combo_findings:
                rule = combos[finding.indicator]
                lines.append(f"    [!] {rule.title}  (+{rule.bonus:g})")
                for wrapped in _wrap(rule.description, 72):
                    lines.append(f"        {c(wrapped, _DIM)}")
                triggered = finding.context.get("triggered_by") or []
                if triggered:
                    lines.append(f"        {c('from: ' + ', '.join(triggered), _DIM)}")
                lines.append("")

        lines.append(c("  Indicators", _BOLD))
        for finding in plain:
            spec = INDICATORS.get(finding.indicator)
            title = spec.title if spec else finding.indicator
            weight = f"+{spec.weight:g}" if spec else ""
            marker = "-" if spec and spec.contextual else "*"
            lines.append(f"    {marker} {title}  ({finding.indicator}, {weight})")

            shown = finding.evidence if verbose else finding.evidence[:2]
            for evidence in shown:
                where = f"{evidence.path}:{evidence.line}" if evidence.line else evidence.path
                tag = c(" [decoded]", _DIM) if evidence.decoded else ""
                lines.append(f"        {c(where, _DIM)}{tag}")
                if evidence.snippet:
                    lines.append(f"          {evidence.snippet}")
            hidden = len(finding.evidence) - len(shown)
            if hidden > 0:
                lines.append(f"        {c(f'... and {hidden} more', _DIM)}")
        lines.append("")

    if breakdown and verbose:
        lines.append(c("  Score breakdown", _BOLD))
        for item in breakdown:
            lines.append(
                f"    {item.contribution:6.2f}  {item.indicator}"
                f"  ({item.weight:g} x {item.evidence_count or 1} evidence)"
            )
        lines.append(f"    {'-' * 40}")
        lines.append(f"    {result.score:6.2f}  total")
        lines.append("")

    if result.explanation:
        lines.append(c("  Explanation (AI-generated, not part of the verdict)", _BOLD))
        for wrapped in _wrap(result.explanation, 72):
            lines.append(f"    {wrapped}")
        lines.append("")

    if result.warnings:
        lines.append(c("  Warnings", _BOLD))
        for warning in result.warnings:
            lines.append(f"    ! {warning}")
        lines.append("")

    lines.append(
        c(
            "  Detection is deterministic. Findings are indicators of risk, "
            "not proof of malice - review the evidence above.",
            _DIM,
        )
    )
    return "\n".join(lines)


def _wrap(text: str, width: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current: list[str] = []
    length = 0
    for word in words:
        if length + len(word) + len(current) > width and current:
            lines.append(" ".join(current))
            current, length = [], 0
        current.append(word)
        length += len(word)
    if current:
        lines.append(" ".join(current))
    return lines
