"""Structured JSON output - the canonical machine-readable report.

The evaluation harness and the MCP interface both consume this shape, so it is
versioned: ``schema`` changes only when the structure changes incompatibly.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import Any

from securedep.models import ScanResult
from securedep.scoring.indicators import COMBINATIONS, INDICATORS
from securedep.scoring.model import THRESHOLDS, ScoreBreakdown

SCHEMA_VERSION = "1.0"


def to_dict(result: ScanResult, breakdown: list[ScoreBreakdown] | None = None) -> dict[str, Any]:
    combo_titles = {rule.id: rule for rule in COMBINATIONS}

    findings: list[dict[str, Any]] = []
    for finding in result.findings:
        spec = INDICATORS.get(finding.indicator)
        rule = combo_titles.get(finding.indicator)

        findings.append(
            {
                "indicator": finding.indicator,
                "kind": "combination" if rule else "indicator",
                "category": spec.category.value if spec else "combination",
                "title": spec.title if spec else (rule.title if rule else finding.indicator),
                "description": (spec.description if spec else (rule.description if rule else "")),
                "weight": spec.weight if spec else (rule.bonus if rule else 0.0),
                "contextual": spec.contextual if spec else False,
                "evidence": [asdict(e) for e in finding.evidence],
                "context": finding.context,
            }
        )

    # Highest-weight findings first so a reader sees what mattered.
    findings.sort(key=lambda f: (-f["weight"], f["indicator"]))

    payload: dict[str, Any] = {
        "schema": SCHEMA_VERSION,
        "package": {
            "name": result.ref.name,
            "ecosystem": result.ref.ecosystem.value,
            "version": result.ref.version,
        },
        "verdict": {
            "score": round(result.score, 2),
            "band": result.band.value,
            "thresholds": {band.value: value for band, value in THRESHOLDS.items()},
        },
        "findings": findings,
        "warnings": result.warnings,
    }

    if breakdown is not None:
        payload["score_breakdown"] = [asdict(b) for b in breakdown]
    if result.explanation is not None:
        payload["explanation"] = result.explanation

    return payload


def to_json(
    result: ScanResult,
    breakdown: list[ScoreBreakdown] | None = None,
    indent: int = 2,
) -> str:
    return json.dumps(to_dict(result, breakdown), indent=indent, default=str)
