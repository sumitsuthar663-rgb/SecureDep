# SecureDep — working notes

Static analyser for malicious npm/PyPI packages. Final year project.
Read `README.md` first; this file covers conventions and the traps.

## Non-negotiables

1. **Never execute an analysed package.** Not `pip install`, not `npm install`,
   not `import`, not `eval`, not `exec` — including on content recovered by the
   deobfuscation module. Everything is read as text. This is the property that
   makes the tool safe to run on real malware, and it is the first thing an
   examiner will probe.
2. **The AI layer never decides a verdict.** Stages 3 and 4 explain and expose;
   `securedep.analysis` and `securedep.scoring` decide. If you find yourself
   passing a model's output into scoring, stop.
3. **Never present provisional numbers as measured.** Weights, thresholds and
   entropy cut-offs are currently judgement calls, and every one of them says so
   in a comment. When they are calibrated, update the comment too.
4. **Real samples never enter version control.** `samples/` is gitignored. See
   `docs/SAFETY.md`.

## Layout

```
src/securedep/
  models.py              shared types; no analysis logic
  acquisition/           Stage 1 — registry clients, hardened extraction
  analysis/              Stage 2 — the engine (all detection lives here)
    base.py              AnalysisContext, auxiliary-path classification
    patterns.py          language-independent pattern tables
    engine.py            analyser ordering + public scan entry points
  scoring/
    indicators.py        THE indicator catalogue — every weight lives here
    model.py             weighted sum, combination scopes, risk bands
  reporting/             JSON (canonical) and terminal renderings
  cli.py
scripts/                 name-list fetch, evaluation harness, calibration
docs/adr/                architecture decision records
```

## Adding an indicator

1. Add an `IndicatorSpec` to `scoring/indicators.py` with a weight and a
   description written for a reader who is not a security specialist.
2. Raise it from an analyser via `ctx.flag(...)`, **always with evidence** —
   a path, a line, and a snippet. A finding without evidence is not actionable
   and `tests/test_engine.py` asserts against it.
3. Add a case to the fixtures if it needs end-to-end coverage.
4. If it is common in benign packages, mark it `contextual=True`. Contextual
   indicators carry low weight and are capped in aggregate.

## Adding a combination rule

Pick the `scope` honestly:

- `install` — the behaviours must occur in code that runs at install time.
  Default, and correct for anything carrying a large bonus.
- `file` — the behaviours must occur in one file.
- `package` — anywhere. Only for package-level facts such as the name.

Do not widen a scope to make a sample score higher. Read
`docs/adr/0002-combination-scope.md` first — package-wide matching is what made
`setuptools` and `requests` look critical.

## Traps already hit (don't reintroduce)

- **`import urllib.request` binds `urllib`, not `urllib.request`.** Mapping the
  alias to the full dotted path rewrote `urllib.request.urlopen` into
  `urllib.request.request.urlopen` and missed every such call.
- **Docstrings are not data.** Scanning them for credential paths made
  "extract the cookies from the response" register as credential access.
- **Entropy alone does not mean "encoded".** Emoji and CJK text score as high as
  base64. `looks_encoded()` requires the restricted-alphabet shape first, and
  excludes charset definitions (nearly all characters distinct).
- **Test, docs, example and vendored code is not the package's code.** It
  legitimately opens sockets and hardcodes IPs. It is analysed, but marked
  auxiliary.
- **Don't recompute `source.splitlines()` per finding.** It made the analysers
  quadratic in file size; `ansible` took >120s to scan. Both visitors cache it,
  and the obfuscation module uses a bisect line index.
- **`from securedep.acquisition import extract`** gets the *function*, shadowing
  the submodule. Import the module by path if you need the constants.

## Testing

```bash
pytest                    # fast; no network
ruff check src/ tests/
```

Fixtures under `tests/fixtures/` are synthetic and inert — reserved
documentation domains, never published, never run. Live-registry checks are
manual (`securedep scan <name>`) and deliberately not in the suite, so the
tests stay offline and deterministic.

## Priorities

The project document's sequencing is right and should be respected: **finish
the measured evaluation (Phase 5) before building the AI and MCP layers (Phase
6).** Having measured results in hand guarantees a defensible project even if
the later phases run short of time. Building an impressive demo with nothing
underneath it is the common failure mode.
